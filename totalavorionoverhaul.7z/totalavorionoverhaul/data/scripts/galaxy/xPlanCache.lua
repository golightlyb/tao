package.path = package.path .. ";data/scripts/lib/?.lua"

-- namespace PlanCache
PlanCache = {}

local PlanGenerator = include ("plangenerator")

local _cachedFilePlans = {}
local _cachedGeneratedPlans = {}
local _hits   = 0
local _misses = 0
local _errors = 0

function PlanCache.initialize()
    print("Total Avorion Overhaul: Plan Cache enabled")
end

function PlanCache.FromFile(path)
    local plan = _cachedFilePlans[path]
    
    if plan == nil then
        _misses = _misses + 1
        plan = LoadPlanFromFile(path)
        if plan == nil then
            _cachedFilePlans[path] = "error"
            eprint("PlanCache: error loading plan: "..path)
            _errors = _errors + 1
            return nil
        end
        _cachedFilePlans[path] = plan
    elseif plan == "error" then
        eprint("PlanCache: ignoring plan due to previous error: "..path)
        return nil
    else
        _hits = _hits + 1
    end
    
    -- PlanCache.PrintStats()
    return copy(plan)
end

local function countTable(t)
    local i = 0
    for _ in pairs(t) do i = i + 1 end
    return i
end

local function genStation(faction, volume, styleName, material)
    local p, _, _, _ = PlanGenerator.makeStationPlan(faction, styleName, nil, volume, material)
    return p
end

function PlanCache.PrintStats()
    local sum = countTable(_cachedFilePlans) + countTable(_cachedGeneratedPlans)
    print("Plan Cache: %i hits, %i misses, %i errors, %i entries.", _hits, _misses, _errors, sum)
end

function PlanCache.Generated(planType, faction, volume, styleName, material)
    local genPlan
    if planType == "Freighter" then
        genPlan = PlanGenerator.makeFreighterPlan
        styleName = styleName or PlanGenerator.getFreighterStyleDefaultName()
    elseif planType == "Miner" then
        genPlan = PlanGenerator.makeMinerPlan
        styleName = styleName or PlanGenerator.getMinerStyleDefaultName()
    elseif planType == "Ship" then
        genPlan = PlanGenerator.makeShipPlan
        styleName = styleName or PlanGenerator.getShipStyleDefaultName()
    elseif planType == "Station" then
        genPlan = genStation
    else
        -- "Carrier", "Fighter", or other...
        eprint("PlanCache: invalid planType")
        return
    end
    
    -- buckets that grow when the next volume is 50% greater
    -- log_b(a) = log_c(a) / log_c(b)
    -- log_10(a) = log(a) / log(10)
    -- log_(1.5)(a) = log(a) / log(1.5) = log(a) / 0.17609125905 = log(a) * 5.67887358727
    local volumeBucket = math.ceil(math.log(volume) * 5.67887358727)
    
    local key = "(PT"..planType..")(FI"..faction.index..")(VB"..volumeBucket..")(SN"..styleName..")(MV"..(material.value or "")..")"
    -- print("PlanCache: volume "..volume.. " -> bucket "..volumeBucket..", key: "..key)
    
    local plan = _cachedGeneratedPlans[key]
    
    if plan == nil then
        _misses = _misses + 1
        plan = genPlan(faction, volume, styleName, material)
        if plan == nil then
            _cachedGeneratedPlans[key] = "error"
            eprint("PlanCache: error generating plan: "..key)
            _errors = _errors + 1
            return nil
        end
        -- print("PlanCache: new generated plan "..key)
        _cachedGeneratedPlans[key] = plan
    elseif plan == "error" then
        eprint("PlanCache: ignoring generated plan due to previous error: "..key)
        return nil
    else
        _hits = _hits + 1
    end
    
    -- PlanCache.PrintStats()
    return copy(plan)
end


