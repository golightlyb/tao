
Galaxy():removeScript("internal/dlc/blackmarket/galaxy/convoyevent.lua")
Galaxy():addScriptOnce("xPlanCache.lua")