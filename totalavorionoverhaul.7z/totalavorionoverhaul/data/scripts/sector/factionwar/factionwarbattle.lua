local ShipUtility = include("shiputility")
local Placer = include("placer")
local XSectorGenerator = include("xSectorGenerator")
include("randomext")

function FactionWarBattle.spawnShips(faction)
    print("spawning faction war ships")
    
    local sector = Sector()
    local x, y = sector:getCoordinates()
    local sectorGenerator = XSectorGenerator(x, y, sector, faction, false, random)
    
    local ships = {}
    local function post(ship)
        ship:removeScript("entity/antismuggle.lua")
        ship:addScriptOnce("data/scripts/sector/factionwar/temporarydefender.lua")
        ship.title = "Assault " .. ShipUtility.getMilitaryNameByVolume(ship.volume)
        table.insert(ships, ship)
    end
    
    sectorGenerator:createContents({
        x = {
            noSector = true,
            shapes = {
                {
                    variant   = "arc",
                    params = {radius=200, span=1.0, thickness=100, depth=20},
                    offset = vec3(getFloat(-1000, 1000), getFloat(-100, 100), getFloat(-1000, 1000)),
                    ships  = {
                        {variant="garrison", number=6, post=post},
                    },
                },
            },
        },
    })
    
    Placer.resolveIntersections(ships)
    
    wavesSpawned = wavesSpawned + 1
end