

if onServer() then

    -- TODO

    function RebuildStations.spawnConstructionSite(faction, type)
        return
    end

end