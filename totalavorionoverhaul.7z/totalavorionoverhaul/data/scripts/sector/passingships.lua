local ShipUtility = include("shiputility")
local Placer = include("placer")
local XSectorGenerator = include("xSectorGenerator")

-- TODO
-- trader or trader convoy - fly through sector without docking then despawn
function PassingShips.createPassingTrader(faction)
    local sector = Sector()
    local x, y = sector:getCoordinates()

    -- this is the position where the trader spawns
    local dir = random():getDirection()
    local pos = dir * 1500

    -- this is the position where the trader will jump into hyperspace
    local destination = -pos + vec3(math.random(), math.random(), math.random()) * 1000
    destination = normalize(destination) * 1500

    numFreighters = getInt(1, 3)
    numTraders = getInt(1, 3)
    
    local ships = {}
    local post = function(ship)
        if random():test(0.8) then
            local addIllegalCargo = random():test(0.05)
            if addIllegalCargo then
                ShipUtility.addIllegalCargoToCraft(ship)
            else
                ShipUtility.addCargoToCraft(ship)
            end
            -- add control option for player
            ship:addScriptOnce("entity/playercontrol.lua")
        end
        ship:addScriptOnce("ai/passsector.lua", destination)
        ship:setValue("passing_ship", true)
        table.insert(ships, ship)
    end

    local generator = XSectorGenerator(x, y, sector, faction, true, random)
    generator:createContents({
        x = {
            noSector = true,
            shapes = {
                {
                    variant   = "arc",
                    params = {radius=100, span=0.3, thickness=10, depth=10},
                    offset = pos,
                    ships  = {
                        {variant="freighter", number=numFreighters, post=post},
                        {variant="trader",   number=numTraders,     post=post},
                    },
                },
            },
        },
    })

    Placer.resolveIntersections(ships)
end