WeaponSounds = {
    sounds = {
        "weapon/pdc1",
        "weapon/pdc2",
        "weapon/pdc3",
        "weapon/pdc4",
        "weapon/pdc5",
    },
    range = 400,
    volume = 0.3,
}
