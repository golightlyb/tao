
productions = {}
productionsByGood = {}
productionIndexByName = {}

--[[
OreProcessor: 1000 xOre -> 100 XMetal + 10 xMetalPrecous + 250 XScrapMetal
TerrestrialTrader: -> 100 XCarbs, 100 XWorker, 5 XSoldier, 20 XPrisoner
Consumer Goods Manufacturer: 100 XWater, 100 XProtein, 100 XCarbs -> 100 XCivilNormal
Consumer Goods Manufacturer: 100 XWater, 10 XChemicals -> 100 XCivilNormal
Consumer Goods Manufacturer: 100 XMetal -> 100 XCivilNormal
Consumer Goods Manufacturer: 10 XMetal, 10 XElectronics -> 10 XCivilNormal 
Luxury Consumer Goods Manufacturer: 1 XMetalPrecious, 1XElectronics, 1 XMetal -> 10 XCivilLuxury
Luxury Consumer Goods Manufacturer: 1 XMetalPrecious -> 1 XCivilLuxury
Biofactory: 100 XWater, 1 XChemicals -> 100 XProtein
Chemcial Plant: 100 XGas, 100 XWater -> 100 XChemicals, 10 XWasteToxic
Ore Mine: -> 100 XOre, 1 XUraniumOre
Gas Collector: -> 1000 XGas
Condenser: 1000 XGas -> 200 XWater
Ice Mine: -> 100 XWater
Uranium Refinery: 100 XUraniumOre, 10 XChemicals -> 10 XUraniumRefined, 100 XWasteToxic
Uranium Enricher: 100 XUraniumRefined, 10 XChemicals -> 10 XUraniumEnriched, 100 XWasteRadioactive
Munitions factory: 10 XWasteRadioactive, 10 XMetal, 10 XAmmunition
Armor forge: 10 XWasteRadioactive, 10 XMetal, 2 XArmor
Warhead factory: 10 XUraniumEnriched -> 1 XWarhead
Military Robot Foundry: 10 XElectronics, 1 XSystem, 1 XLens, 10 XMetal, 1 XArmor -> 1 XBattleRobot
Robot Upgrade Factory: 1 XRobot, 1XArmor -> 1 XBattleRobot
Robot Foundry: 10 XElectronics, 1 XSystem, 1 XLens, 10 XMetal -> 1 XRobot
Vehicle Factory: 1 XElectronics, 10 XMetal -> 1 XVehicle
Electronics Factory: 1 XMetalPrecious, 10 XChemicals -> 10 XElectronics
Systems Factory: 10 XMetal, 5 XMetalPrecious, 1 XMetalAdvanced, 1 XElectronics -> 1 "XSystem"
Pharmaceuticals Factory: 100 XChemicals, 10 XProtein -> 10 XMedical, 100 XWasteToxic
Advanced Metal Foundry: 1 XUraniumEnriched, 10 XMetalPrecious -> 10 XMetalAdvanced, 100 XWasteRadioactive
Lens Fabricator: 10 XChemicals -> 10 XLens
--]]

local function cleanName(s)
    -- e.g. "Luxury Electronics Manufacturer ${size}", -> "Luxury Electronics Manufacturer",
    if string.ends(s, " ${size}") then
        return string.sub(s, 1, -8)
    else
        return s
    end
end

-- Initial special orderings for certain special factories --
productionIndexOreProcessor = 1
table.insert(productions, {
    factory="Ore Processor ${size}",
    factoryStyle="Factory", -- ignored
    noauto=true,
    ingredients={
        {name="XOre", amount=1000, optional=0},
    },
    results={
        {name="XMetal",         amount=100},
        {name="XMetalPrecious", amount= 10},
    },
    garbages={
        {name="XScrapMetal", amount=250},
    },
})

productionIndexTerrestrial = 2
table.insert(productions, {
    factory="Terrestrial Trader ${size}",
    factoryStyle="Factory", -- ignored
    noauto=true,
    ingredients={},
    results={
        {name="XCarbs",    amount=100},
        {name="XWorker",   amount=100},
        {name="XSoldier",  amount=  5},
        {name="XPrisoner", amount= 20},
    },
    garbages={},
})

productionIndexMiningColony = 3
table.insert(productions, {
    factory="Mining Colony ${size}",
    factoryStyle="Factory", -- ignored
    noauto=true,
    ingredients={
        {name="XCarbs",   amount=5},
        {name="XProtein", amount=5},
        {name="XWater",   amount=5},
    },
    results={
        {name="XOre",     amount=500},
    },
    garbages={
        {name="XWasteToxic", amount=5},
    },
})

productionIndexGasCollector = 4
table.insert(productions, {
    factory="Gas Collector ${size}",
    factoryStyle="Collector",
    noauto=true,
    ingredients={},
    results={
        {name="XGas",   amount=1000},
    },
    garbages={},
})

-- normal factories follow --
table.insert(productions, {
    factory="Consumer Food Manufacturer ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XWater",   amount=100, optional=0},
        {name="XProtein", amount=100, optional=0},
        {name="XCarbs",   amount=100, optional=0},
    },
    results={
        {name="XCivilNormal", amount=100},
    },
    garbages={},
})

table.insert(productions, {
    factory="Consumer Beauty Manufacturer ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XWater",     amount=100, optional=0},
        {name="XChemicals", amount=10, optional=0},
    },
    results={
        {name="XCivilNormal", amount=100},
    },
    garbages={},
})

table.insert(productions, {
    factory="Consumer Furniture Manufacturer ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XMetal",       amount=100, optional=0},
    },
    results={
        {name="XCivilNormal", amount=100},
    },
    garbages={},
})

table.insert(productions, {
    factory="Consumer Electronics Manufacturer ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XMetal",       amount=10, optional=0},
        {name="XElectronics", amount=10, optional=0},
    },
    results={
        {name="XCivilNormal", amount=10},
    },
    garbages={},
})

table.insert(productions, {
    factory="Luxury Electronics Manufacturer ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XMetalPrecious",   amount=1, optional=0},
        {name="XElectronics",     amount=1, optional=0},
        {name="XMetal",           amount=1, optional=0},
    },
    results={
        {name="XCivilLuxury",     amount=10},
    },
    garbages={},
})

table.insert(productions, {
    factory="Luxury Crafts Manufacturer ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XMetalPrecious",   amount=1, optional=0},
    },
    results={
        {name="XCivilLuxury",     amount=1},
    },
    garbages={},
})

table.insert(productions, {
    factory="Biofactory ${size}",
    factoryStyle="Farm",
    ingredients={
        {name="XWater",     amount=100, optional=0},
        {name="XChemicals", amount=  1, optional=0},
    },
    results={
        {name="XProtein", amount=100},
    },
    garbages={},
})

table.insert(productions, {
    factory="Ore Mine ${size}",
    factoryStyle="Mine",
    mine=true,
    ingredients={},
    results={
        {name="XOre",       amount=100},
        {name="XUraniumOre",  amount=1},
    },
    garbages={},
})

table.insert(productions, {
    factory="Condenser ${size}",
    factoryStyle="Collector",
    ingredients={
        {name="XGas", amount=1000, optional=0},
    },
    results={
        {name="XWater", amount=200},
    },
    garbages={},
})

table.insert(productions, {
    factory="Ice Mine ${size}",
    factoryStyle="Mine",
    mine=true,
    ingredients={},
    results={
        {name="XWater", amount=100},
    },
    garbages={},
})

table.insert(productions, {
    factory="Uranium Refinery ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XUraniumOre", amount=100, optional=0},
        {name="XChemicals",  amount=10,  optional=0},
    },
    results={
        {name="XUraniumRefined", amount=10},
    },
    garbages={
        {name="XWasteToxic", amount=100},
    },
})

table.insert(productions, {
    factory="Uranium Enricher ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XUraniumRefined", amount=100, optional=0},
        {name="XChemicals",  amount=10,  optional=0},
    },
    results={
        {name="XUraniumEnriched", amount=10},
    },
    garbages={
        {name="XWasteRadioactive", amount=100},
    },
})

table.insert(productions, {
    factory="Munitions factory ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XWasteRadioactive", amount=10, optional=0},
        {name="XMetal",            amount=10,  optional=0},
    },
    results={
        {name="XAmmunition",       amount=10},
    },
    garbages={},
})

table.insert(productions, {
    factory="Armor forge ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XWasteRadioactive", amount=10, optional=0},
        {name="XMetal",            amount=10,  optional=0},
    },
    results={
        {name="XArmor",            amount=2},
    },
    garbages={},
})

table.insert(productions, {
    factory="Warhead factory ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XUraniumEnriched",  amount=10, optional=0},
    },
    results={
        {name="XWarhead",          amount=1},
    },
    garbages={},
})

table.insert(productions, {
    factory="Military Robot Foundry ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XElectronics",       amount=10, optional=0},
        {name="XSystem",            amount= 1, optional=0},
        {name="XLens",              amount= 1, optional=0},
        {name="XMetal",             amount=10, optional=0},
        {name="XArmor",             amount= 1, optional=0},
    },
    results={
        {name="XBattleRobot",       amount=1},
    },
    garbages={},
})

table.insert(productions, {
    factory="Robot Upgrade Factory ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XRobot",             amount= 1, optional=0},
        {name="XArmor",             amount= 1, optional=0},
    },
    results={
        {name="XBattleRobot",       amount=1},
    },
    garbages={},
})

table.insert(productions, {
    factory="Robot Foundry ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XElectronics",       amount=10, optional=0},
        {name="XSystem",            amount= 1, optional=0},
        {name="XLens",              amount= 1, optional=0},
        {name="XMetal",             amount=10, optional=0},
    },
    results={
        {name="XRobot",             amount=1},
    },
    garbages={},
})

table.insert(productions, {
    factory="Vehicle Factory ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XElectronics",       amount= 1, optional=0},
        {name="XMetal",             amount=10, optional=0},
    },
    results={
        {name="XVehicle",           amount=1},
    },
    garbages={},
})

table.insert(productions, {
    factory="Electronics Factory ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XMetalPrecious",     amount=1,  optional=0},
        {name="XChemicals",         amount=10, optional=0},
    },
    results={
        {name="XElectronics",       amount=10, optional=0},
    },
    garbages={},
})

table.insert(productions, {
    factory="Systems Factory ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XMetal",             amount=10, optional=0},
        {name="XMetalPrecious",     amount= 5, optional=0},
        {name="XMetalAdvanced",     amount= 1, optional=0},
        {name="XElectronics",       amount= 1, optional=0},
    },
    results={
        {name="XSystem",            amount= 1, optional=0},
    },
    garbages={},
})

table.insert(productions, {
    factory="Chemcial Plant ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XGas",               amount=100, optional=0},
        {name="XWater",             amount=100, optional=0},
    },
    results={
        {name="XChemicals",         amount=100, optional=0},
    },
    garbages={
        {name="XWasteToxic",        amount=10},
    },
})

table.insert(productions, {
    factory="Pharmaceuticals Factory ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XChemicals",         amount=100, optional=0},
        {name="XProtein",           amount= 10, optional=0},
    },
    results={
        {name="XMedical",           amount=10, optional=0},
    },
    garbages={
        {name="XWasteToxic",        amount=100},
    },
})

table.insert(productions, {
    factory="Advanced Metal Foundry ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XUraniumEnriched",   amount=1, optional=0},
        {name="XMetalPrecious",     amount=10, optional=0},
    },
    results={
        {name="XMetalAdvanced",     amount=10, optional=0},
    },
    garbages={
        {name="XWasteRadioactive",  amount=100},
    },
})

table.insert(productions, {
    factory="Lens Fabricator ${size}",
    factoryStyle="Factory",
    ingredients={
        {name="XChemicals",         amount=10, optional=0},
    },
    results={
        {name="XLens",              amount=10, optional=0},
    },
    garbages={},
})



for i, production in pairs(productions) do
    production.index = i

    productionIndexByName[cleanName(production.factory)] = i
    
    for _, result in pairs(production.results) do
        local collection = productionsByGood[result.name]

        if not collection then
            collection = {}
            productionsByGood[result.name] = collection
        end

        table.insert(collection, production)
    end
end

-- printTable(productionsByGood)


