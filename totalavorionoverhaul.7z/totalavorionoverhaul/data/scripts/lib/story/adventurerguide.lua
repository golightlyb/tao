
function AdventurerGuide.spawn1(player)
    return
end

function AdventurerGuide.canSpawn()
    return false
end

function AdventurerGuide.spawnOrFindMissionAdventurer(player, dontAllowInteraction, dontImmediatelyStartDialog)
    return
end

function AdventurerGuide.spawnProgressionWarningAdventurer(player)
    return
end


