
function Xsotan.createCarrier(position, volumeFactor, fighters)
    return Xsotan.createShip(position, volumeFactor)
end

function infectAsteroids()
    return
end


