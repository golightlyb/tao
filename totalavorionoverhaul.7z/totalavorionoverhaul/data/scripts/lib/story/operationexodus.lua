
function OperationExodus.tryGenerateBeacon(generator)
    return
end

function OperationExodus.generateBeacon(generator)
    return
end