

function Scientist.spawn()
    return
end
