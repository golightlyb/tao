

turretsInCenter = 10 -- we have fewer, but bigger guns

-- these control what appears in shops or drops;
-- overhaul enemy ships have theirs picked precisely.

weaponProbabilities[WeaponType.ChainGun] =             {p = 0.0}
weaponProbabilities[WeaponType.PointDefenseChainGun] = {p = 0.0}
weaponProbabilities[WeaponType.MiningLaser] =          {p = 0.0}
weaponProbabilities[WeaponType.RawMiningLaser] =       {p = 0.0}
weaponProbabilities[WeaponType.SalvagingLaser] =       {p = 0.0}
weaponProbabilities[WeaponType.RawSalvagingLaser] =    {p = 0.0}
weaponProbabilities[WeaponType.Bolter] =               {p = 0.0}
weaponProbabilities[WeaponType.ForceGun] =             {p = 0.0}
weaponProbabilities[WeaponType.Laser] =                {p = 0.0}
weaponProbabilities[WeaponType.PointDefenseLaser] =    {p = 0.0}
weaponProbabilities[WeaponType.PlasmaGun] =            {p = 0.0}
weaponProbabilities[WeaponType.PulseCannon] =          {p = 0.0}
weaponProbabilities[WeaponType.AntiFighter] =          {p = 0.0}
weaponProbabilities[WeaponType.Cannon] =               {p = 0.0}
weaponProbabilities[WeaponType.RepairBeam] =           {p = 0.0}
weaponProbabilities[WeaponType.RocketLauncher] =       {p = 0.0}
weaponProbabilities[WeaponType.RailGun] =              {p = 0.0}
weaponProbabilities[WeaponType.LightningGun] =         {p = 0.0}
weaponProbabilities[WeaponType.TeslaGun] =             {p = 0.0}


-- NPCs only
weaponProbabilities[WeaponType.XMining] =              {p = 0.5} -- turret

-- Player only
weaponProbabilities[WeaponType.XCutting] =             {p = 0.25} -- coaxial

-- Player only for now
weaponProbabilities[WeaponType.XLance] =               {p = 0.25} -- coaxial
weaponProbabilities[WeaponType.XGun] =                 {p = 1.0} -- coaxial
weaponProbabilities[WeaponType.XDisruptor] =           {p = 0.5} -- coaxial
weaponProbabilities[WeaponType.XMissile] =             {p = 0.5} -- coaxial

-- NPC and player
weaponProbabilities[WeaponType.XCannon] =              {p = 1.0} -- turret




--weaponProbabilities[WeaponType.XLaser] =               {p = 1.0}
--weaponProbabilities[WeaponType.XPDLaser] =             {p = 1.0}
--weaponProbabilities[WeaponType.XPDFlak] =              {p = 1.0}



