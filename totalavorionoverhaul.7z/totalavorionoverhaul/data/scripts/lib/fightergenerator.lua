
function FighterGenerator.addWeapons(rand, type, dps, rarity, fighter, tech, material)
    return
end
