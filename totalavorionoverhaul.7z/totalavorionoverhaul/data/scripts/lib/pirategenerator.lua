function PirateGenerator.createScaledRavager(position)
    --if random():test(0.2) then
    --    return generator.createScaledCarrier(position)
    --end

    local scaling = PirateGenerator.getScaling()
    return PirateGenerator.create(position, 6.0 * scaling, "Ravager"%_T)
end

function PirateGenerator.createRavager(position)
    --if random():test(0.2) then
    --    return PirateGenerator.createCarrier(position)
    --end

    return PirateGenerator.create(position, 6.0, "Ravager"%_T)
end


-- customised drops
function PirateGenerator.addPirateEquipment(craft, title)

    local dropsTurrets  = 0
    local dropsUpgrades = 0

    local x, y = Sector():getCoordinates()

    local turretGenerator = SectorTurretGenerator()
    local turretRarities = turretGenerator:getSectorRarityDistribution(x, y)

    local upgradeGenerator = UpgradeGenerator()
    local upgradeRarities = upgradeGenerator:getSectorRarityDistribution(x, y)

    craft:setDropsLoot(false)
    
    if title == "Outlaw" then
        ShipUtility.addMilitaryEquipment(craft, 0.25, 0)
        if random():test(0.3) then craft:addScriptOnce("utility/fleeondamaged.lua") end
    elseif title == "Bandit" then
        ShipUtility.addMilitaryEquipment(craft, 0.5, 0)
        if random():test(0.3) then craft:addScriptOnce("utility/fleeondamaged.lua") end
    elseif title == "Pirate" then
        ShipUtility.addMilitaryEquipment(craft, 0.75, 0)
        if random():test(0.2) then craft:addScriptOnce("utility/fleeondamaged.lua") end
    elseif title == "Marauder" then
        local type = random():getInt(1, 3)
        if type == 1 then
            ShipUtility.addDisruptorEquipment(craft)
        elseif type == 2 then
            ShipUtility.addArtilleryEquipment(craft)
        elseif type == 3 then
            ShipUtility.addCIWSEquipment(craft)
        end
    elseif title == "Disruptor" then
        local type = random():getInt(1, 2)
        if type == 1 then
            ShipUtility.addDisruptorEquipment(craft)
        elseif type == 2 then
            ShipUtility.addCIWSEquipment(craft)
        end
    elseif title == "Raider" then
        local type = random():getInt(1, 3)
        if type == 1 then
            ShipUtility.addDisruptorEquipment(craft)
        elseif type == 2 then
            ShipUtility.addPersecutorEquipment(craft)
        elseif type == 3 then
            ShipUtility.addTorpedoBoatEquipment(craft)
        end
    elseif title == "Ravager" or title == "Pirate Carrier" then
        local type = random():getInt(1, 2)
        if type == 1 then
            ShipUtility.addArtilleryEquipment(craft)
        elseif type == 2 then
            ShipUtility.addPersecutorEquipment(craft)
        end
    elseif title == "Pirate Mothership" then
        --local type = random():getInt(1, 2)
        --if type == 1 then
            --ShipUtility.addCarrierEquipment(craft)
        --elseif type == 2 then
            ShipUtility.addFlagShipEquipment(craft)
        --end
        ShipUtility.addBossAntiTorpedoEquipment(craft)

        dropsTurrets  = 1
        dropsUpgrades = 1
        
        turretRarities[-1] = 0 -- no petty turrets
        turretRarities[0] = 0 -- no common turrets
        turretRarities[1] = 0 -- no uncommon turrets

        upgradeRarities[-1] = 0 -- no petty upgrades
        upgradeRarities[0] = 0 -- no common upgrades
        upgradeRarities[1] = 0 -- no uncommon upgrades

        craft:setDropsLoot(true)
        -- add fighters for carriers
    elseif title == "Pirate Loot Transporter" then
        craft:addScriptOnce("data/scripts/entity/enemies/lootgoon.lua")
    else
        ShipUtility.addMilitaryEquipment(craft, 1, 0)
    end

    if craft.numTurrets == 0 then
        ShipUtility.addMilitaryEquipment(craft, 1, 0)
    end

    turretGenerator.rarities = turretRarities
    for i = 1, dropsTurrets do
        Loot(craft):insert(InventoryTurret(turretGenerator:generate(x, y)))
    end
    for i = 1, dropsUpgrades do
        Loot(craft):insert(upgradeGenerator:generateSectorSystem(x, y, nil, upgradeRarities)) 
    end
    ShipUtility.addIllegalCargoToCraft(craft)

    ShipAI(craft.index):setAggressive()
    craft:setTitle("${toughness}${title}", {toughness = "", title = title})
    craft.shieldDurability = craft.shieldMaxDurability

    craft:setValue("is_pirate", true)
end
