
function SectorFighterGenerator:generateArmed(x, y, offset_in, rarity_in, material_in) -- server
    return
end
