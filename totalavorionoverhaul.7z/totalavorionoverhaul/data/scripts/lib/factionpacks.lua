include ("xUtil")


-- TODO not sure how the cache would work with multiple faction packs

--[[
function FactionPacks.getPlan(plansTable, volume, material)
    if not plansTable then return end
    if #plansTable == 0 then return end

    local path = plansTable[random():getInt(1, #plansTable)]
    if not path then return end

--    print("load path: " .. path)
    local plan = xPlanCache_FromFile(Galaxy(), path)
    if not valid(plan) then
        printlog("failed to load plan from faction pack: " .. path .. "'")
        return
    end

    -- change material
    plan:setMaterialTier(material)

    -- scale
    if volume then
        local factor = math.pow(volume / plan.volume, 1 / 3)
        plan:scale(vec3(factor))
    end

    return plan
end
--]]