package.path = package.path .. ";data/scripts/systems/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"
include ("basesystem")
include ("utility")
include ("randomext")

-- optimization so that energy requirement doesn't have to be read every frame
FixedEnergyRequirement = true
PermanentInstallationOnly = true

--[[
function invokeOnChange(entity)
    if not entity then return end

    local ok, _ = entity:invokeFunction("entity/xResistance.lua", "onChanged")
    if not ok then
        eprint("xarmor system: could not invoke xResistance onChanged")
        return nil
    end
    return plan
end
--]]

local getResistanceBonuses = include ("xarmor_resistance")

function getBonuses(seed, rarity, permanent)
    local bonuses = {}
    if parmanent == false then return bonuses end
    local r = rarity.value + 1 -- 0 to 6 (p, c, uc, r, exc, exo, leg)
    
    bonuses[StatsBonuses.Acceleration]     = math.pow(0.95,  6-r)
    
    return bonuses
end

function onInstalled(seed, rarity, permanent)
    local entity = Entity()
    local bonuses = getBonuses(seed, rarity, permanent)

    print(bonuses[StatsBonuses.Acceleration])
    addMultiplier(StatsBonuses.Acceleration, bonuses[StatsBonuses.Acceleration])
end

function onUninstalled(seed, rarity, permanent)
end

function getName(seed, rarity)
    return "Armor Module MK ${mark} /* ex: Armor Module MK IV */"%_t % {mark = toRomanLiterals(rarity.value + 2)}
end

function getBasicName()
    return "Armor Module"%_t
end

function getIcon(seed, rarity)
    return "data/textures/icons/shield.png"
end

function getEnergy(seed, rarity, permanent)
    return 0
end

function getPrice(seed, rarity)
    local r = rarity.value + 1 -- 0 to 6
    return 15625 * math.pow(4, r)
        
    -- 250,000 * 4^r
    -- petty:       c     15,625
    -- common:      c     62,500
    -- uncommon:    c    250,000
    -- rare:        c  1,000,000
    -- exceptional: c  4,000,000
    -- exotic:      c 16,000,000
    -- legendary:   c 64,000,000
end

function getDescriptionLines(seed, rarity, permanent)
    local texts = {}
    table.insert(texts, {ltext = "Reconfigures the ship with extra armor. Multiple installations stack."%_t})
    return texts
end

local function both(targets, permanent, tooltip)
    table.insert(targets.bonuses, tooltip)
    if permanent then
      table.insert(targets.texts, tooltip)
    end
end

function getTooltipLines(seed, rarity, permanent)
    local tables = {texts={}, bonuses={}}
    local bonus = getBonuses(seed, rarity, permanent)
    local resist = getResistanceBonuses(seed, rarity, permanent)

    both(tables, permanent, {
        ltext = "Anti-matter damage recieved"%_t,
        rtext = string.format("x%.2f", resist.durability.antimatter),
        icon  = "data/textures/icons/shield.png",
        boosted = permanent
    })
    both(tables, permanent, {
        ltext = "Physical damage recieved"%_t,
        rtext = string.format("x%.2f", resist.durability.physical),
        icon  = "data/textures/icons/shield.png",
        boosted = permanent
    })

    both(tables, permanent, {
        ltext = "Acceleration"%_t,
        rtext = string.format("x%.2f", bonus[StatsBonuses.Acceleration]),
        rcolor = ColorRGB(1.0, 0.3, 0.3), -- doesnt work?
        icon  = "data/textures/icons/acceleration.png",
        boosted = false,
    })

    return tables.texts, tables.bonuses
end
