package.path = package.path .. ";data/scripts/systems/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"
include ("basesystem")
include ("utility")
include ("randomext")

-- optimization so that energy requirement doesn't have to be read every frame
FixedEnergyRequirement = true
Unique = true

function getBonuses(seed, rarity, permanent)
    local bonuses = {}
    if parmanent == false then return bonuses end
    local r = rarity.value + 1 -- 0 to 6
    
    bonuses[StatsBonuses.Velocity]      = 0.33 -- relative
    bonuses[StatsBonuses.Acceleration]  = math.min(4.0, math.pow(1.5, (1 + r)/2)) -- relative: 1.22, 1.5, 1.83, 2.25, 2.75, 3.375, 4
    
    return bonuses
end

function onInstalled(seed, rarity, permanent)
    local bonuses = getBonuses(seed, rarity, permanent)

    addMultiplier(StatsBonuses.Velocity,     bonuses[StatsBonuses.Velocity])
    addMultiplier(StatsBonuses.Acceleration, bonuses[StatsBonuses.Acceleration])
end

function onUninstalled(seed, rarity, permanent)
end

function getName(seed, rarity)
    return "Towing Configuration MK ${mark} /* ex: Towing Congifuration MK IV */"%_t % {mark = toRomanLiterals(rarity.value + 2)}
end

function getBasicName()
    return "Towing Configuration"%_t
end

function getIcon(seed, rarity)
    return "data/textures/icons/rocket-thruster.png"
end
function getEnergy(seed, rarity, permanent)
    return 0
end

function getPrice(seed, rarity)
    local r = rarity.value + 1 -- 0 to 6
    return 15625 * math.pow(4, r)
        
    -- 250,000 * 4^r
    -- petty:       c     15,625
    -- common:      c     62,500
    -- uncommon:    c    250,000
    -- rare:        c  1,000,000
    -- exceptional: c  4,000,000
    -- exotic:      c 16,000,000
    -- legendary:   c 64,000,000
end

function getDescriptionLines(seed, rarity, permanent)
    local texts = {}
    table.insert(texts, {ltext = "Reconfigures engines for power, not speed or efficiency."%_t})
    return texts
end

function both(targets, permanent, tooltip)
    table.insert(targets.bonuses, tooltip)
    if permanent then
      table.insert(targets.texts, tooltip)
    end
end

function getTooltipLines(seed, rarity, permanent)
    local tables = {texts={}, bonuses={}}
    local bonus = getBonuses(seed, rarity, permanent)

    both(tables, permanent, {
        ltext = "Velocity"%_t,
        rtext = string.format("%.2f", bonus[StatsBonuses.Velocity]),
        icon  = "data/textures/icons/speedometer.png",
        boosted = permanent
    })
    both(tables, permanent, {
        ltext = "Acceleration"%_t,
        rtext = string.format("%.2f", bonus[StatsBonuses.Acceleration]),
        icon  = "data/textures/icons/acceleration.png",
        boosted = permanent
    })

    return tables.texts, tables.bonuses
end