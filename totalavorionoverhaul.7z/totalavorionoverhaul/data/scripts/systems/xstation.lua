package.path = package.path .. ";data/scripts/systems/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"
include ("basesystem")
include ("utility")
include ("randomext")

local name
local isShipVariant = nil
local stationFounderTooltipName = "Found a new station"%_t
local errStationCoreOnly = "Only a ship equipped with a Station Core can found stations."%_t

-- optimization so that energy requirement doesn't have to be read every frame
FixedEnergyRequirement = true
PermanentInstallationOnly = true
Unique = true

function onInstalled(seed, rarity, permanent)
    if not permanent then return end

    addAbsoluteBias  (StatsBonuses.ArmedTurrets,            1000)
    addAbsoluteBias  (StatsBonuses.UnarmedTurrets,          1000)
    addAbsoluteBias  (StatsBonuses.PointDefenseTurrets,     1000)
    addAbsoluteBias  (StatsBonuses.AutomaticTurrets,        1000)
    addAbsoluteBias  (StatsBonuses.DefenseWeapons,            32)
    addMultiplier(StatsBonuses.Velocity,                     0.1)
    addMultiplier(StatsBonuses.Acceleration,                 0.1)
    addAbsoluteBias(StatsBonuses.MinersPerTurret,        -100000)
    addAbsoluteBias(StatsBonuses.MechanicsPerTurret,     -100000)
    addAbsoluteBias(StatsBonuses.GunnersPerTurret,       -100000)
end

function getName(seed, rarity)
    return "Station Core MK ${mark} /* ex: Station Core System MK IV */"%_t % {mark = toRomanLiterals(rarity.value + 2)}
end

function getBasicName()
    return "Station Core"%_t
end

function getIcon(seed, rarity)
    return "data/textures/icons/station.png"
end

function getEnergy(seed, rarity, permanent)
    return 0
end

function getPrice(seed, rarity)
    return 15625
end

function getDescriptionLines(seed, rarity, permanent)
    local texts = {}
    table.insert(texts, {ltext = "The heart of every station!"%_t})
    return texts
end

function getTooltipLines(seed, rarity, permanent)
    return {}, {}
end
