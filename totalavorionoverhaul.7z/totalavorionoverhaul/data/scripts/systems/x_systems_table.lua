
local order = {
    "core",
    "station",
    "tradingOverview",
    "valuablesDetector",
    "tow",
    "armor",
}
return order, {
    -- some entries here duplicate the names and descriptions given in the
    -- system files as an optimisation to prevent having to instantiate each
    -- system to get its name.
    core = {
        name   = "Ship Core System",
        desc   = "The heart of every ship!",
        script = "data/scripts/systems/xcore.lua",
        unique = true,
        ingredients = {
            {"XSystem",      1},
        },
    },
    station = {
        script = "data/scripts/systems/xstation.lua",
        hidden = true,
        unique = true,
    },
    tradingOverview = {
        name   = "Trading Subsystem",
        desc   = "Collects prices of goods in a sector.",
        script = "data/scripts/systems/xtradingoverview.lua",
        unique = true,
        ingredients = {
            {"XElectronics", 4},
        },
    },
    valuablesDetector = {
        name   = "Anomalous Object Detector",
        desc   = "Detects valuable and dangerous objects.",
        script = "data/scripts/systems/xvaluablesdetector.lua",
        unique = true,
        ingredients = {
            {"XElectronics", 1},
            {"XLens",        2},
        },
    },
    tow = {
        name   = "Towing Configuration",
        desc   = "Reconfigures engines for power, not speed or efficiency.",
        script = "data/scripts/systems/xtow.lua",
        unique = true,
        ingredients = {
            {"XSystem",     0.25},
        },
    },
    armor = {
        name   = "Armor Module",
        desc   = "Reduces damage at the cost of acceleration. Multiple installations stack.",
        script = "data/scripts/systems/xarmor.lua",
        unique = false,
        ingredients = {
            {"XArmor",      1},
        },
    },
}
