local ShipUtility = include("shiputility")
local Placer = include("placer")
local XSectorGenerator = include("xSectorGenerator")

function Backup.onDamaged(selfIndex, amount, inflictor)

    damageTaken = damageTaken + amount

    if damageTaken > damageUntilBackup and timeUntilBackup == 0 then
        local station = Sector():getEntity(selfIndex)
        local faction = Faction(station.factionIndex)

        if faction and faction.isAIFaction and not FactionEradicationUtility.isFactionEradicated(faction.index) then
            print("calling backup")

            -- let the backup spawn behind the station
            local stationPos = station.translationf
            
            -- while not async, generation should be very quick using the plan cache
            local x, y = Sector():getCoordinates()
            local generator = XSectorGenerator(x, y, Sector(), faction, true, random)

            local ships = {}
            local function post(ship)
                ship.title = "Interceptor " .. ShipUtility.getMilitaryNameByVolume(ship.volume)
                table.insert(ships, ship)
            end
            
            generator:createContents({
                x = {
                    noSector = true,
                    shapes = {
                        {
                            variant   = "arc",
                            params = {radius=200, span=1.0, thickness=100, depth=20},
                            offset = stationPos + vec3(0, -200, 0),
                            ships  = {
                                {variant="garrison", number=7, post=post},
                            },
                        },
                    },
                },
            })
            
            Placer.resolveIntersections(ships)

            timeUntilBackup = 30 * 60 -- only every 30 minutes can a station call for backup
            
            xPlanCache_PrintStats(Galaxy())
        end
    end

end



