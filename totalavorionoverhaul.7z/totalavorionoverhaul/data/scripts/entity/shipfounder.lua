


function ShipFounder.foundShip(faction, player, name, tutorialActive)

    local limit = faction.maxNumShips

    if limit and limit >= 0 and faction.numShips >= limit then
        player:sendChatMessage("", 1, "Maximum ship limit for this faction (%s) of this server reached!"%_t, limit)
        return
    end

    if faction:ownsShip(name) then
        player:sendChatMessage("", 1, "You already have a ship called '%s'."%_t, name)
        return
    end

    local cost = ShipFounding.getNextShipCosts(faction)

    local ok, msg, args = faction:canPayMoney(resources)
    if not ok then
        player:sendChatMessage("", 1, msg, unpack(args))
        return
    end
    
    local args = {}
    local material = Material(0)

    faction:pay("Paid %1% Credits to found a ship."%_T, cost)

    local self = Entity()

    local plan = BlockPlan()
    plan:addBlock(vec3(0, 0, 0), vec3(2, 2, 2), -1, -1, material.blockColor, material, Matrix(), BlockType.Hull)

    local ship = Sector():createShip(faction, name, plan, self.position)

    -- add base scripts
    AddDefaultShipScripts(ship)
    SetBoardingDefenseLevel(ship)
    
    -- add base crew
    if tutorialActive ~= true then
        local baseCrewAmount = ShipFounder.getBaseCrewAmount()
        ship:addCrew(baseCrewAmount, CrewMan(CrewProfession(CrewProfessionType.None), false, 1))
    end

    player.craft = ship

    local settings = GameSettings()
    if settings.difficulty <= Difficulty.Veteran and GameSettings().reconstructionAllowed then
        local kit = createReconstructionKit(ship)
        faction:getInventory():addOrDrop(kit, true)
    end

    return ship
end

function ShipFounder.refreshUI()
    local resources
    local ships = 0

    local alliance = Player().alliance
    local faction
    if allianceCheckBox.checked and alliance then
        faction = alliance
    else
        faction = Player()
    end
    
    local ships = ShipFounding.xNumShips(faction)
    local cost  = ShipFounding.getCosts(ships)

    local material = Material(0)

    feeLabel.caption = "${cost} Credits"%_t % {cost = cost}
    feeLabel.color = material.color

    local baseCrewAmount = ShipFounder.getBaseCrewAmount()

    includedCrewAmountLabel.caption = "${amount}"%_t % {amount = baseCrewAmount}

    window.caption = "Founding Ship #${number}"%_t % {number = ships + 1}

    includedCrewAmountLabel.tooltip = "Don't forget to hire more crew members from the station!"%_t

    if ships + 1 >= 25 then
        warningPicture:show()
    else
        warningPicture:hide()
    end

end


function ShipFounder.getBaseCrewAmount()
    return 4 -- always
end

