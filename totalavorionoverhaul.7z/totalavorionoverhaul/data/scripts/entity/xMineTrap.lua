package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include ("utility")
include ("randomext")
include ("callable")
Dialog = include("dialogutility")

local data = {}
data.state = 0

function interactionPossible(playerIndex, option)
    local self = Entity()
    
    if data.state > 0 then return false end
    
    local player = Player(playerIndex)

    local craft = player.craft
    if craft == nil then return false end

    local dist = craft:getNearestDistance(self)

    if dist <= math.max(craft.transporterRange, 20.0) then
        return true
    end

    return false
end

function initialize()
    local e = Entity()
    
    if onClient() then
        invokeServerFunction("syncToClient")
        
--        e:registerCallback("onCollision" ,      "onCollision")
        e:registerCallback("onDamaged" ,        "onDamaged")
        e:registerCallback("onBlockDamaged" ,   "onBlockDamaged")
    else
        if not _restoring then
            setArmed(e)
        end
    end
end

function syncToClient()
    invokeClientFunction(Player(callingPlayer), "restore", data)
end
callable(nil, "syncToClient")

function syncToClients(data)
    if onServer() then
        broadcastInvokeClientFunction("restore", data)
    end
end

function initUI()
    local res = getResolution()
    local size = vec2(800, 600)

    local menu = ScriptUI()
    window = menu:createWindow(Rect(vec2(0, 0), vec2(0, 0)))

    menu:registerWindow(window, "[Disarm]"%_t, 5)
end

function onShowWindow()
    disarm()
    invokeServerFunction("disarm")
    ScriptUI():stopInteraction()
end

function setArmed(e)
    e.title = "Mine /* as in e.g. a proximity mine */"
    e:setValue("dangerous_object", true)
    data.state = 0
end

function setDisarmed(e)
    if onClient() then 
        e.title = "Mine (disarmed)"
        e:setValue("dangerous_object", nil)
    end
    data.state = 1
end

function setDetonated(e)
    e.title = "Mine (detonated)"
    e:setValue("dangerous_object", nil)
    data.state = 2
end

function disarm()
    local e = Entity()
    setDisarmed(e)
    -- syncToClients(data)
end
callable(nil, "disarm")

function secure()
    return data
end

function restore(data_in)
    data = (data_in or {})    
    local e = Entity()
    state = data.state or 0
    setState(e, state)
end

function setState(e, state)
    --local needsSync = (data.state ~= state)
    
    if state == 0 then
        setArmed(e)
    elseif state == 1 then
        setDisarmed(e)
    elseif state == 2 then
        setDetonated(e)
    end
    
    --if needsSync then
        --syncToClients(data)
    --end
end

function onDamaged(objectIndex, amount, inflictor, damageSource, damageType)
    if onClient() then -- always true
        local id = Entity().id
        boom(id)
        invokeServerFunction("boom", id)
    end
end

function onBlockDamaged(selfIndex, amount, inflictor)
    if onClient() then -- always true
        local id = Entity().id
        boom(id)
        invokeServerFunction("boom", id)
    end
end

--[[
function onCollision(objectIndexA, objectIndexB, damageA, damageB, steererA, steererB)
    if onServer() then -- always true
        boom()
        broadcastInvokeClientFunction("boom")
    end
end
--]]

function effect(self, others)
    local effectRange = 200 -- 2km
    
    local impactExplosions = (onClient())
    local registerDamage = (onServer())
    
    local selfPos = self.translationf
    for i = 1, #others do
        local e = others[i]
        if e.id == self.id then goto continue end
        
        local pos = e.translationf
        local radius = (e.radius or 0)
        local edge2 = ((radius + effectRange) * (radius + effectRange))
        local d = distance2(selfPos, pos) - edge2
        
        if d > 0 then goto continue end
        d = -d
        d = math.min(d, edge2) / edge2
        d = math.sqrt(d) -- inverse square law
        
        -- TODO if EMP...
        local shieldDmg = (e.shieldMaxDurability or 0) * 0.5
        local hullDmg  =  (e.maxDurability or 0) * 0.33
        -- hullDmg = math.max(hullDmg, 200) * d -- fatal even to very small craft
        hullDmg = hullDmg * d
        shieldDmg = shieldDmg  * d
        
        --print("hit: "..(e.title or "N/A")..", hullDmg "..hullDmg..", shieldDmg "..shieldDmg)
        
        if e:hasComponent(ComponentType.EnergySystem) then
            local es = EnergySystem(e)
            --print("energy capacity: "..es.capacity)
            -- es:removeEnergy(es.capacity	* d * 0.5)
            es:removeEnergy(es.capacity	* d)
        end
        
        if registerDamage then
            if shieldDmg > 1.0 then
                e:damageShield(shieldDmg, selfPos, self.id, DamageSource.Collision, DamageType.Physical)
            end
            if hullDmg > 1.0 then
                -- registerDamage doesn't work
                -- TODO need to get a block index properly!!!
                e:inflictDamage(hullDmg, DamageSource.Weaponry, DamageType.Physical, 0, vec3(0, 0, 0), self.id)
            end
        end
        
        if impactExplosions and (shieldDmg + hullDmg > 1.0) then
            local s = Sector()
            s:createExplosion(pos, 10.0, false)
        end
        
        --
        ::continue::
    end
end

function boom(id)
    if onServer() then
        --print("boom on server")
    else
        --print("boom on client")
    end
    
    local s = Sector()
    
    if data.state > 0 then return false end
    local self = s:getEntity(id)
    if self == nil then
        eprint("nil self")
        return
    end
    
    setDetonated(self)
    
    local pos = self.translationf
    

    if onClient() then
        s:createShockwave(pos, 200.0, 1.5, vec3(0.5, 0.5, 1.0))
        s:createExplosion(pos, 25.0, false)
    end
    
    effect(self, {s:getEntitiesByType(EntityType.Ship)})
    effect(self, {s:getEntitiesByType(EntityType.Station)})
    effect(self, {s:getEntitiesByType(EntityType.Container)})
    effect(self, {s:getEntitiesByType(EntityType.Wreckage)})
    effect(self, {s:getEntitiesByType(0)})
end
callable(nil, "boom")



