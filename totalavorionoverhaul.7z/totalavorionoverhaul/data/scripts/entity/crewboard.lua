package.path = package.path .. ";data/scripts/?.lua"
include ("xSectorUtil")

-- this function gets called on creation of the entity the script is attached to, on client and server
function CrewBoard.initialize()
    if not onServer() then return end

    local scaling = 1
    if Server().infiniteResources then
        scaling = 50
    else
        local x, y = Sector():getCoordinates()

        local d = length(vec2(x, y))
        scaling = 1 + ((1 - (d / 450)) * 5)
    end

    scaling = math.max(1, scaling)

    local probabilities = {}
    local station = Entity()

    if MinimumPopulation and not MinimumPopulation.isFulfilled() then
        table.insert(probabilities, {profession = CrewProfessionType.None, probability = 1.0, number = math.floor(random():getInt(35, 40))})
    else
        chances = xSectorUtil_CrewBoardChances(station)
    
        -- pick up to any six
        table.insert(probabilities, {profession = CrewProfessionType.None,     probability = 1, number = math.floor(random():getInt(chances.noneMin     or 0, chances.noneMax     or 0) * scaling)})
        table.insert(probabilities, {profession = CrewProfessionType.Engine,   probability = 1, number = math.floor(random():getInt(chances.engineMin   or 0, chances.engineMax   or 0) * scaling)})
        table.insert(probabilities, {profession = CrewProfessionType.Repair,   probability = 1, number = math.floor(random():getInt(chances.repairMin   or 0, chances.repairMax   or 0) * scaling)})
        table.insert(probabilities, {profession = CrewProfessionType.Gunner,   probability = 1, number = math.floor(random():getInt(chances.gunnerMin   or 0, chances.gunnerMax   or 0) * scaling)})
        table.insert(probabilities, {profession = CrewProfessionType.Miner,    probability = 1, number = math.floor(random():getInt(chances.minerMin    or 0, chances.minerMax    or 0) * scaling)})
        table.insert(probabilities, {profession = CrewProfessionType.Pilot,    probability = 1, number = math.floor(random():getInt(chances.pilotMin    or 0, chances.pilotMax    or 0) * scaling)})
        table.insert(probabilities, {profession = CrewProfessionType.Security, probability = 1, number = math.floor(random():getInt(chances.securityMin or 0, chances.securityMax or 0) * scaling)})
        table.insert(probabilities, {profession = CrewProfessionType.Attacker, probability = 1, number = math.floor(random():getInt(chances.attackerMin or 0, chances.attackerMax or 0) * scaling)})
    end

    -- first insert all with probability >= 1
    for _, crew in pairs(probabilities) do
        if crew.probability >= 1.0 and crew.number >= 0 and #availableCrew < 6 then
            table.insert(availableCrew, crew)
        end
    end

    for _, crew in pairs(probabilities) do
        if crew.probability < 1.0 and random():test(crew.probability) and #availableCrew < 6 then
            table.insert(availableCrew, crew)
        end
    end

    -- generate a captain
    availableCaptain = nil
    -- removed by overhaul for now
end

