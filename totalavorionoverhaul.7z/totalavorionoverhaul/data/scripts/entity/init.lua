if onServer() then

    local entity = Entity()

    if entity.type == EntityType.Station or entity.type == EntityType.Ship then
        entity:addScriptOnce("entity/xNoAccumulatingBlockHealth.lua")
        entity:addScriptOnce("entity/xResistance.lua")
    end

    entity:removeScript("entity/regrowdocks.lua")
    entity:removeScript("entity/utility/transportmode.lua")
    
end
