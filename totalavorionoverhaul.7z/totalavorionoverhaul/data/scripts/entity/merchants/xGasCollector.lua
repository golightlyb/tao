package.path = package.path .. ";data/scripts/lib/?.lua"
include ("utility")
include ("randomext")
include ("faction")
include ("goods")
include ("productions")
local ConsumerGoods = include ("consumergoods")
-- local ShopAPI = include ("shop")
local Dialog = include("dialogutility")
--local BuildingKnowledgeUT = include("buildingknowledgeutility")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XGasCollector
XGasCollector = {}

-- The GasCollector is basically a mine, but we want it to have a specific
-- identity rather than be chosen at random as another mine or factory.
-- it also has no consumergoods on purpose.

function XGasCollector.interactionPossible(playerIndex, option)
    return CheckFactionInteraction(playerIndex, -10000)
end

function XGasCollector.initialize()
    local station = Entity()
    if station.title == "" then
        station.title = "Gas Collector"%_t
    end

    if onServer() then
        local production = productions[productionIndexGasCollector]
        station:addScriptOnce("data/scripts/entity/merchants/factory.lua", production, nil, 0)
    end
    
    -- XRefinery.shop:initialize(station.translatedTitle)

    if onClient() and EntityIcon().icon == "" then
        EntityIcon().icon = "data/textures/icons/pixel/farm.png"
        InteractionText(station.index).text = Dialog.generateStationInteractionText(station, random())
    end
end

