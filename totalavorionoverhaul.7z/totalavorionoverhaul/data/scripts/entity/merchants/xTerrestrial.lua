package.path = package.path .. ";data/scripts/lib/?.lua"
include ("utility")
include ("randomext")
include ("faction")
include ("goods")
include ("productions")
local TradingAPI = include ("tradingmanager")
local ConsumerGoods = include ("consumergoods")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XTerrestrial
XTerrestrial = {}
XTerrestrial = TradingAPI:CreateNamespace()

-- The Terestrial trader is just a factory with a trader appearance and
-- consumer goods, but should only appear when there's a background planet.

function XTerrestrial.interactionPossible(playerIndex, option)
    return CheckFactionInteraction(playerIndex, -10000)
end

function XTerrestrial.generateInteractionText(random)
    local greet = "Welcome. This is the automated trading system of the Terrestrial Imports & Exports station ${name_string}. "%_t % {name_string = nameStr}
    
    local suffixes = {
        "Sponsored by Galatrans, for all your interplanetary transport solutions."%_t,
        "Please note, due to the ongoing Organophage pandemic, all xenograin imports are subject to enchanced quarantine proceedures."%_t,
        "Please respectfully observe all local hygiene customs."%_t,
        "",
        "",
    }
    
    return greet .. suffixes[random:getInt(1, #suffixes)]
end

function XTerrestrial.initialize()
    local station = Entity()
    if station.title == "" then
        station.title = "Terrestrial Trader"%_t
    end

    if onServer() then
        local production = productions[productionIndexTerrestrial]
        station:addScriptOnce("data/scripts/entity/merchants/consumer.lua", "Terrestrial Trader"%_t, unpack(ConsumerGoods.XTerrestrial()))
        station:addScriptOnce("data/scripts/entity/merchants/factory.lua", production, nil, 0)
        
        -- local goods = {"XPassenger", "XPassengerLuxury"}
        -- station:addScriptOnce("data/scripts/entity/merchants/tradingpost.lua", goods, goods)
    end
    
    -- XRefinery.shop:initialize(station.translatedTitle)

    if onClient() then -- always override
        EntityIcon().icon = "data/textures/icons/pixel/biotope.png"
        
        
        -- AVORION BUG - THIS NEVER WORKS
        InteractionText().text = XTerrestrial.generateInteractionText(random())
    end
end

