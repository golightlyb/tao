package.path = package.path .. ";data/scripts/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"
include ("randomext")
include ("galaxy")
include ("utility")
include ("stringutility")
include ("faction")
include ("player")
include ("relations")
include ("merchantutility")
include ("callable")
local Dialog = include("dialogutility")
local systemsTableOrder, systemsTable = include("systems/x_systems_table")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XSystemInstaller
XSystemInstaller = {}
XSystemInstaller.interactionThreshold = 10000

local restrictedTypes = {} -- map
local helpText -- helpText is a tuple {text, tooltip}

local minSelectedRarity = -1 -- petty
local maxSelectedRarity =  4 -- exotic
local selectedRarity    =  0 -- (0; common) to (5; legendary)

function XSystemInstaller.restrict(variantHelpText, minRarity, maxRarity, typeList)
    -- variantHelpText is a tuple {text, tooltip}
    if variantHelpText then
        helpText = variantHelpText
    end
    minSelectedRarity = (minRarity or -1)
    maxSelectedRarity = (maxRarity or 5) -- legendary
    -- e.g. {"xarmor"}
    typeList = typeList or {}
    for i = 1,#typeList do
        restrictedTypes[typeList[i]] = true
    end
end

function XSystemInstaller.interactionPossible(playerIndex, option)
    return CheckFactionInteraction(playerIndex, XSystemInstaller.interactionThreshold)
end

function XSystemInstaller._defaultHelpText()
    return  {
        "Spacedocks carry out general, but limited system installations."%_T,
            "For Armor upgrades up to Legendary, find an Armor Forge."%_T.."\n"..
            "For System upgrades up to Legendary, find a Systems Factory."%_T
    }
end

function XSystemInstaller.initialize()
    helpText = XSystemInstaller._defaultHelpText()
    local station = Entity()
    if station.title == "" then
        station.title = "System Installer"%_t
    end
end

function XSystemInstaller._visitSystemsTable(visit)
    for i = 1, #systemsTableOrder do
        local id = systemsTableOrder[i]
        local system = systemsTable[id]
        if system and (not system.hidden) then visit(id, system) end
    end
end

local mainWindow

function XSystemInstaller.initUI()
    local res = getResolution()
    local size = vec2(800, 480)

    local menu = ScriptUI()
    window = menu:createWindow(Rect(res * 0.5 - size * 0.5, res * 0.5 + size * 0.5))
    menu:registerWindow(window, "Install Systems  /* Interaction Title*/"%_t, 8)
    mainWindow = window
    
    local station = Entity()
    window.caption = "Install Systems  /* Window Title*/"%_t
    window.showCloseButton = 1
    window.moveable = 1
    
    -- create a padded inner window
    XSystemInstaller.buildGui(window:createTabbedWindow(Rect(vec2(10, 10), size - 10)))
end

local playerStock = {} -- k,v in pairs {good id, quantity}
local playerSystems = {} -- k,v in pairs {system id ":" rarity, quantity}
local playerInstalledSystems = {}
local maxIngredientTypesPerSystem = 3

local comboboxSystemType
local ingredientFrames = {}
local ingredientNameLabels  = {}
local ingredientRequiredLabels = {}
local ingredientStockLabels = {}
local ownedMarkLabels = {}
local ownedQuantityLabels = {}
local checkboxInstall
local picturePreview
local tooltipPreview
local borderPreview
local labelMark
local labelPreviousLevelInventoryMix
local labelBuy
local buttonBuy

local currentPreview       = nil
local previousSelectedType = nil

function XSystemInstaller._doNothing()
end

function XSystemInstaller.buildGui(window)
    
    ---[Top Bar]----------------------------------------------------------------
    local label = window:createLabel(vec2(10, 5), "[?] "..helpText[1], 14)
    label.tooltip = helpText[2]
    label.color = ColorRGB(0.5, 1.0, 1.0)
    
    ---[System Info]------------------------------------------------------------
    local x = 10
    local y = 55
    comboboxSystemType = window:createValueComboBox(Rect(x, y, x+190, y+20), "_updateSelection")
    XSystemInstaller._visitSystemsTable(function(id, system)
        comboboxSystemType:addEntry(id, system.name, ColorRGB(1.0, 1.0, 1.0))
    end)
    
    y = y + 35
    borderPreview  = window:createRect            (Rect(x,   y,   x+190, y+190), ColorRGB(1.0, 1.0, 1.0))
    picturePreview = window:createPicture         (Rect(x+4, y+4, x+186, y+186), "data/textures/icons/minus.png")
    tooltipPreview = window:createTooltipDisplayer(Rect(x,   y,   x+190, y+190))

    y = y + 205
    local button = window:createButton(Rect(x, y, x+60, y+30), "-", "_decreaseRarity")
    button.icon = "data/textures/icons/minus.png"
    local button = window:createButton(Rect(x+130, y, x+190, y+30), "+", "_increaseRarity")
    button.icon = "data/textures/icons/plus.png"

    labelMark = window:createLabel(vec2(0, y+5), "", 14)
    labelMark.font = FontType.SciFi
    
    ---[Dividers]---------------------------------------------------------------
    window:createLine(vec2(220,  50), vec2(220, 340))
    window:createLine(vec2( 10, 350), vec2(770, 350))
    window:createLine(vec2(220, 365), vec2(220, 460))
    
    ---[Ingredients]------------------------------------------------------------
    local x = 240
    -- local y = 35
    labelName = window:createLabel(vec2(250, 500), "", 16)
    labelName.font = FontType.SciFi
    
    local nameX       = x + 10
    local requiredX   = x + 290
    local stockX      = x + 420
    
    local y = 50
    window:createLabel(vec2(nameX,     y), "Cost"%_T, 20)
    
    local y = 90
    window:createLabel(vec2(nameX,     y), "Ingredient"%_T,     15)
    window:createLabel(vec2(requiredX, y), "Required"%_T,       15)
    window:createLabel(vec2(stockX,    y), "You Have"%_T,       15)
    
    y = y + 25
    for i = 1, maxIngredientTypesPerSystem + 2 do
        -- loop is plus one for cash
        --     and plus one for an item of previous system level
        local yText = y + 6

        local frame         = window:createFrame(Rect(x, y, 770, 30 + y))
        local nameLabel     = window:createLabel(vec2(nameX,     yText), "", 15)
        local requiredLabel = window:createLabel(vec2(requiredX, yText), "", 15)
        local stockLabel    = window:createLabel(vec2(stockX,    yText), "", 15)

        table.insert(ingredientFrames,         frame)
        table.insert(ingredientNameLabels,     nameLabel)
        table.insert(ingredientRequiredLabels, requiredLabel)
        table.insert(ingredientStockLabels,    stockLabel)

        y = y + 35
    end
    
    labelPreviousLevelInventoryMix = window:createLabel(vec2(x + 10, y + 15), "", 15)
    
    ---[Bottom bar, left]-------------------------------------------------------
    local y = 360
    labelBuy = window:createLabel(Rect(10, y, 780, y+20), "Frobbulator System", 15)
    labelBuy.color = ColorRGB(0.5, 0.5, 0.5)
    
    y = y + 35
    checkboxInstall = window:createCheckBox(Rect(10, y, 200, y+20), "Install directly", "_doNothing")
    checkboxInstall:setCheckedNoCallback(true)
    checkboxInstall.tooltip = "If checked, may replace an installed weaker system and return it to your inventory.\n\nIf unchecked, or if you have no free system slots, sends the system to your inventory instead."%_t
    
    y = y + 35
    buttonBuy = window:createButton(Rect(10, y, 200, y+20), "Pay & Install", "_doNothing")
    
    
    ---[Bottom bar, right]------------------------------------------------------
    x = 240
    y = 360
    
    y = y + 25
    local width = (780 - x) / 7
    for i = 0, 6 do
        local rarity = Rarity(i-1)
        local label = window:createLabel(vec2(x + (width * i), y), "MK "..toRomanLiterals(i+1), 15)
        label.font = FontType.SciFi
        label.color = rarity.color
        label.tooltip = "You own this many of this rarity."%_t
        table.insert(ownedMarkLabels, label)
        
        local label = window:createLabel(vec2(x + (width * i), y + 30), "-", 15)
        label.tooltip = "You own this many of this rarity."%_t
        table.insert(ownedQuantityLabels, label)
    end
end

local function possibleIngredient(goodId)
    local possible = {
        XArmor       = true,
        XElectronics = true,
        XLens        = true,
        XSystem      = true,
    }
    return possible[goodId] or false
end

local function readPlayerCargo(player)
    for k, _ in pairs(playerStock) do
        playerStock[k] = 0
    end
    
    local player = player or Player()
    if not player then end
    
    local craft = player.craft
    if not craft then return end
    
    local cargoBay = CargoBay(craft)
    if not cargoBay then return end
    
    local cargo = cargoBay:getCargos()
    if not cargo then return end
    
    for good, quantity in pairs(cargo) do
        if good.stolen then goto continue end
        local id = GetGoodID(good.name)
        if not possibleIngredient(id) then goto continue end
        playerStock[id] = quantity
        ::continue::
    end
    
    playerStock["cash"] = (player.money or 0)
end

local function readPlayerSystems(player)
    for k, _ in pairs(playerSystems) do
        playerSystems[k] = 0
    end

    local player = player or Player()
    if not player then end
    
    local inventory = player:getInventory()
    if not inventory then return end
    
    items = inventory:getItemsByType(InventoryItemType.SystemUpgrade) 
    if not items then return end

    for _, v in pairs(items) do
        local item = v.item
        local n = v.amount
        
        -- TODO optimise; this is O(kn) for k = number of system types, but
        -- k is small.
        XSystemInstaller._visitSystemsTable(function(id, system)
            if system.script == item.script then
                local key = id .. ":" .. item.rarity.value
                playerSystems[key] = (playerSystems[key] or 0) + n
            end
        end)
    end
end

local function readPlayerInstalledSystems(player)
    for k, _ in pairs(playerInstalledSystems) do
        playerInstalledSystems[k] = 0
    end

    local player = player or Player()
    if not player then end
    
    local craft = player.craft or none
    if not craft then end
    
    local shipSystem = ShipSystem(craft)
    if not shipSystem then return end
    
    local systems = shipSystem:getUpgrades()
    if not systems then return end
    
    for item, installed in pairs(systems) do
        -- if not installed then goto continue end
        
        -- TODO optimise; this is O(kn) for k = number of system types, but
        -- k is small.
        XSystemInstaller._visitSystemsTable(function(id, system)
            if system.script == item.script then
                local key = id .. ":" .. item.rarity.value
                playerInstalledSystems[key] = (playerInstalledSystems[key] or 0) + 1
            end
        end)
    end
end

function XSystemInstaller.onShowWindow()
    XSystemInstaller.forceRefresh()
end

function XSystemInstaller._updateSelection()
    selectedRarity = 0
    XSystemInstaller.refresh()
end

function XSystemInstaller._decreaseRarity()
    selectedRarity = math.max(minSelectedRarity, selectedRarity - 1)
    XSystemInstaller.forceRefresh()
end

function XSystemInstaller._increaseRarity()
    selectedRarity = math.min(maxSelectedRarity, selectedRarity + 1)
    XSystemInstaller.forceRefresh()
end

function XSystemInstaller.forceRefresh()
    previousSelectedType = nil
    XSystemInstaller.refresh()
end

function XSystemInstaller.refresh()
    local selectedType = comboboxSystemType.selectedValue
    
    if (selectedType ~= previousSelectedType) and selectedType then
        local player = Player()
        readPlayerCargo(player)
        readPlayerSystems(player)
        readPlayerInstalledSystems(player)
        
        ---[update labels and preview]------------------------------------------
        labelBuy.caption = systemsTable[selectedType].name
        labelBuy.color = Rarity(selectedRarity).color
        
        -- relative to 120, 325 (including 10 for window padding)
        labelMark.caption = "MK " .. toRomanLiterals(selectedRarity + 2)
        local width = labelMark.textWidth
        labelMark.position = vec2(mainWindow.position.x + 115 - (width/2), labelMark.position.y)

        previousSelectedType = selectedType
        currentPreview = SystemUpgradeTemplate(systemsTable[selectedType].script, Rarity(selectedRarity), Seed("0"))
        picturePreview:fadeTo(currentPreview.icon, 0)
        tooltipPreview:setTooltip(currentPreview.tooltip)
        borderPreview.color = Rarity(selectedRarity).color
        
        ---[update ingredients]------------------------------------------------
        for i = 1, maxIngredientTypesPerSystem + 2 do
            ingredientFrames[i].tooltip         = nil
            ingredientNameLabels[i].caption     = ""
            ingredientRequiredLabels[i].caption = ""
            ingredientStockLabels[i].caption    = ""
        end
        
        local offset = 1
        if selectedRarity >= 0 then
            local ingredients = systemsTable[selectedType].ingredients or {}
            for i = 1, #ingredients do
                local ing = ingredients[i]
                local id, quantity = ing[1], ing[2]
                local good = goods[id]
                if i > maxIngredientTypesPerSystem then goto continue end
                local levelQuantity = math.ceil(quantity * math.pow(2, (selectedRarity + 1)))
                
                ingredientFrames[i].tooltip         = "[TRADING GOOD]\n\n" .. good.description .. "\n\n".."Typically "..createMonetaryString(good.price).." Cr. each"
                ingredientNameLabels[i].caption     = good.name
                ingredientRequiredLabels[i].caption = levelQuantity
                ingredientStockLabels[i].caption    = (playerStock[id] or 0)
                
                ::continue::
            end
            offset = offset + #ingredients
        end
        
        ingredientNameLabels[offset].caption     = "Cash"
        ingredientRequiredLabels[offset].caption = createMonetaryString(currentPreview.price).." Cr."
        ingredientStockLabels[offset].caption    = playerStock["cash"] or 0
        offset = offset + 1
        
        if selectedRarity >= 2 then -- rare+
            -- requires a previous rarity to upgrade
            local fromInventory = (playerSystems         [selectedType .. ":" .. selectedRarity - 1] or 0)
            local fromInstalled = (playerInstalledSystems[selectedType .. ":" .. selectedRarity - 1] or 0)
            
            ingredientNameLabels[offset].caption     = systemsTable[selectedType].name ..  " MK " .. toRomanLiterals(selectedRarity + 1)
            ingredientRequiredLabels[offset].caption = "" .. 2 
            ingredientStockLabels[offset].caption    =  (fromInventory + fromInstalled) .. " *"
            
            ingredientNameLabels[offset].color = Rarity(selectedRarity - 1).color
            
            labelPreviousLevelInventoryMix.caption = "* " .. fromInventory .. " from inventory and " .. fromInstalled .. " installed."
        else
            labelPreviousLevelInventoryMix.caption = ""
        end
        
        -- update owned --
        x = 280
        local width = (800 - x) / 7
        for i = 0, 6 do
            local rarity = Rarity(i-1)
            local label = ownedMarkLabels[i+1]
            local w = label.textWidth
            label.position = vec2(mainWindow.position.x + x + (width * i) - (w/2), label.position.y)
            
            local label = ownedQuantityLabels[i+1]
            local fromInventory = (playerSystems         [selectedType .. ":" .. i - 1] or 0)
            local fromInstalled = (playerInstalledSystems[selectedType .. ":" .. i - 1] or 0)
            label.caption = fromInstalled + fromInventory
            local w = label.textWidth
            label.position = vec2(mainWindow.position.x + x + (width * i) - (w/2), label.position.y)
        end
    end
    
    -- local s = 
    -- local upgrade 
    -- player:getInventory():add(upgrade, true)
end
callable(XSystemInstaller, "refresh")

function XSystemInstaller.onInstallButtonPressed(button)
    --[[
    local material = 0

    for i = 1, NumMaterials() do
        if depositGoodButtons[i].index == button.index then
            material = i
        end
    end

    local amount = depositGoodTextBoxes[material].text
    if amount == "" then
        amount = 0
    else
        amount = tonumber(amount)
    end
    
    amount = math.min(amount, depositCargoStock[material])
    if amount == 0 then return end

    invokeServerFunction("deposit", material, amount, depositGoodType)
    --]]
end

function XSystemInstaller.install(material, amount, goodType)
    invokeClientFunction(player, "refresh")
end
callable(XSystemInstaller, "install")



