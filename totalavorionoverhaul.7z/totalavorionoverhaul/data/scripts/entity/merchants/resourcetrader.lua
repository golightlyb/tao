local depositGoodNameLabels = {}
local depositGoodStockLabels = {}
local depositGoodTextBoxes = {}
local depositGoodButtons = {}
local depositCargoStock = {}
local depositGoodTaxLabel
local depositGoodType -- "Ore" or "Scrap"

function ResourceDepot.setCanDepositOre()
    depositGoodType = "Ore"
end

function ResourceDepot.setCanDepositScrap()
    depositGoodType = "Scrap"
end

function ResourceDepot.initialize()
    
    local station = Entity()
    if station.title == "" then
        station.title = "Resource Trader"%_t
    end

    for i = 1, NumMaterials() do
        sellPrice[i] = 10 * Material(i - 1).costFactor
        buyPrice[i] = 10 * Material(i - 1).costFactor
    end

    if onServer() then
        math.randomseed(Sector().seed + Sector().numEntities)

        -- best buy price: 1 iron for 10 credits
        -- best sell price: 1 iron for 10 credits        
        stock = ResourceDepot.getInitialResources()

        -- resource shortage
        shortageTimer = -random():getInt(15 * 60, 60 * 60)

        math.randomseed(appTimeMs())

        local faction = Faction()
        if faction and faction.isAIFaction then
            Sector():registerCallback("onRestoredFromDisk", "onRestoredFromDisk")
        end
    end

    if onClient() and EntityIcon().icon == "" then
        EntityIcon().icon = "data/textures/icons/pixel/resources.png"
        InteractionText(station.index).text = Dialog.generateStationInteractionText(station, random())
    end

    if station.type == EntityType.Station then
        -- station:addScriptOnce("data/scripts/entity/merchants/refinery.lua") -- removed
    end

    -- station:addScriptOnce("data/scripts/entity/merchants/resourcedepotbuildingknowledgemerchant.lua") -- removed
end

function ResourceDepot.initUI()
    local res = getResolution()
    local size = vec2(700, 335)

    local menu = ScriptUI()
    window = menu:createWindow(Rect(res * 0.5 - size * 0.5, res * 0.5 + size * 0.5));
    menu:registerWindow(window, "Trade Resources"%_t, 10);

    local station = Entity()
    window.caption = station.translatedTitle
    window.showCloseButton = 1
    window.moveable = 1

    -- create a tabbed window inside the main window
    local tabbedWindow = window:createTabbedWindow(Rect(vec2(10, 10), size - 10))

    -- create buy tab
    local buyTab = tabbedWindow:createTab("Buy"%_t, "data/textures/icons/bag.png", "Buy from station"%_t)
    ResourceDepot.buildBuyGui(buyTab)

    -- create sell tab
    local sellTab = tabbedWindow:createTab("Sell"%_t, "data/textures/icons/sell.png", "Sell to station"%_t)
    ResourceDepot.buildSellGui(sellTab)
    
    -- create deposit tab
    if depositGoodType == "Ore" then
        local depositTab = tabbedWindow:createTab("Deposit"%_t, "data/textures/icons/rock.png", "Deposit raw ores"%_t)
        ResourceDepot.buildDepositGui(depositTab)
    elseif depositGoodType == "Scrap" then
        local depositTab = tabbedWindow:createTab("Deposit"%_t, "data/textures/icons/scrap-metal.png", "Deposit raw scrap"%_t)
        ResourceDepot.buildDepositGui(depositTab)
    end

    ResourceDepot.retrieveData()
    guiInitialized = true
end

function ResourceDepot.buildDepositGui(window)
    local buttonCaption = "Deposit"%_t
    local buttonCallback = "onDepositButtonPressed"
    local textCallback = "onDepositTextEntered"

    local nameX = 10
    local stockX = 340
    local textBoxX = 480
    local buttonX = 550
    
    depositGoodTaxLabel = window:createLabel(vec2(buttonX, 0), "TAX"%_t, 15)
    depositGoodStockLabel = window:createLabel(vec2(stockX, 0), "Your Inventory"%_T, 15)

    local y = 25
    for i = 1, NumMaterials() do

        local yText = y + 6

        local frame = window:createFrame(Rect(0, y, textBoxX - 10, 30 + y))

        local nameLabel = window:createLabel(vec2(nameX, yText), "", 15)
        local stockLabel = window:createLabel(vec2(stockX, yText), "", 15)
        local numberTextBox = window:createTextBox(Rect(textBoxX, yText - 6, 60 + textBoxX, 30 + yText - 6), textCallback)
        local button = window:createButton(Rect(buttonX, yText - 6, window.size.x, 30 + yText - 6), buttonCaption, buttonCallback)

        button.maxTextSize = 16

        numberTextBox.text = "0"
        numberTextBox.allowedCharacters = "0123456789"
        numberTextBox.clearOnClick = 1

        table.insert(depositGoodNameLabels,  nameLabel)
        table.insert(depositGoodStockLabels, stockLabel)
        table.insert(depositGoodTextBoxes,   numberTextBox)
        table.insert(depositGoodButtons,     button)

        nameLabel.caption = Material(i - 1).name .. " " .. depositGoodType
        nameLabel.color = Material(i - 1).color

        y = y + 35
    end
end

local function getDepositTax(player) -- 0 (all) to 1 (none)
    if player == nil then player = Player() end
    if not player then return 0 end
    
    local entity = Entity(player.craftIndex)
    if not entity then return 0 end

    local interactingFaction = Faction(entity.factionIndex)
    if not interactingFaction then return 0 end
    
    local stationFaction = Faction(Entity().factionIndex)
    if not stationFaction then return 0 end
    
    return getMaterialSellingPriceFactor(stationFaction, interactingFaction)
end

local function goodTagsToMatrialIndex(tags, goodType)
    if (goodType == "Ore" and tags.ore) or (goodType == "Scrap" and tags.scrap) then
        if tags.iron     then return 1 end
        if tags.titanium then return 2 end
        if tags.naonite  then return 3 end
        if tags.trinium  then return 4 end
        if tags.xanion   then return 5 end
        if tags.ogonite  then return 6 end
        if tags.avorion  then return 7 end
    end
    return 0
end

local function readPlayerCargo()
    for material = 1, NumMaterials() do
        depositCargoStock[material] = 0
    end
    
    local craft = Player().craft
    if not craft then return end
    
    local cargoBay = CargoBay(craft)
    if not cargoBay then return end
    
    local cargo = cargoBay:getCargos()
    if not cargo then return end
    -- local cargo = Player():getShipCargos(craft.name)
    -- if not cargo then return end
    
    for good, quantity in pairs(cargo) do
         local spec = GetGood(good.name)
         local idx = goodTagsToMatrialIndex(spec.tags, depositGoodType)
         if idx > 0 then
            depositCargoStock[idx] = quantity
         end
    end
end

local old_ResourceDepot_onShowWindow = ResourceDepot.onShowWindow
function ResourceDepot.onShowWindow(optionIndex, material)
    if depositGoodType then
        readPlayerCargo()
    end
    
    old_ResourceDepot_onShowWindow(optionIndex, material)
    
    if depositGoodType then
        depositTax = getDepositTax()
        depositGoodTaxLabel.caption = "TAX: "..tostring(100 * (1.0 - depositTax)).."%"
    end
end

local old_ResourceDepot_updateLine = ResourceDepot.updateLine
function ResourceDepot.updateLine(material, interactingFaction)
    old_ResourceDepot_updateLine(material, interactingFaction)
    
    if depositGoodType then
        depositGoodStockLabels[material].caption = createMonetaryString(depositCargoStock[material] or 0) -- TODO
        depositGoodTextBoxes[material]:show()
    end
end

function ResourceDepot.onDepositTextEntered()
end

function ResourceDepot.onDepositButtonPressed(button)

    local material = 0

    for i = 1, NumMaterials() do
        if depositGoodButtons[i].index == button.index then
            material = i
        end
    end

    local amount = depositGoodTextBoxes[material].text
    if amount == "" then
        amount = 0
    else
        amount = tonumber(amount)
    end
    
    amount = math.min(amount, depositCargoStock[material])
    if amount == 0 then return end

    invokeServerFunction("deposit", material, amount, depositGoodType)
end

function ResourceDepot.deposit(material, amount, goodType)
    if not material then return end

    amount = amount or 0
    if amount <= 0 then return end

    local seller, ship, player = getInteractingFaction(callingPlayer, AlliancePrivilege.SpendResources)
    if not seller then return end

    local station = Entity()

    local numTraded = amount
    
    local tax = getDepositTax(player)

    local errors = {}
    errors[EntityType.Station] = "You must be docked to the station to trade."%_T
    errors[EntityType.Ship] = "You must be closer to the ship to trade."%_T
    if not CheckPlayerDocked(player, station, errors) then
        return
    end

    -- remove player cargo --
    local craft = player.craft
    if not craft then return end
    
    local cargoBay = CargoBay(craft)
    if not cargoBay then return end
    
    local cargo = cargoBay:getCargos()
    if not cargo then return end
    
    local numRemoved = 0
    
    for good, quantity in pairs(cargo) do
        local spec = GetGood(good.name)
        local idx = goodTagsToMatrialIndex(spec.tags, goodType)
        if idx == material then
            local toRemove = math.min(quantity, numTraded - numRemoved)
            cargoBay:removeCargo(good, toRemove)
            numRemoved = numRemoved + toRemove
        end
        if numRemoved >= numTraded then break end
    end
    
    receiveTransactionTax(station, (1.0 - tax) * numRemoved * Material(material-1).value)
    seller:receiveResource("", Material(material - 1), math.ceil(numRemoved * tax))
    ResourceDepot.improveRelations(numRemoved, ship, seller, RelationChangeType.ResourceTrade)
    
    invokeClientFunction(player, "refresh")
end
callable(ResourceDepot, "deposit")

function ResourceDepot.refresh()
    ResourceDepot.onShowWindow()
end
callable(ResourceDepot, "refresh")



