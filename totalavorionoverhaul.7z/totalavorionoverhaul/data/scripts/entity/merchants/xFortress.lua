package.path = package.path .. ";data/scripts/lib/?.lua"
include ("utility")
include ("randomext")
include ("faction")
include ("goods")
include ("productions")
local TradingAPI = include ("tradingmanager")
local ConsumerGoods = include ("consumergoods")
local Dialog = include("dialogutility")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XFortress
XFortress = {}
XFortress = TradingAPI:CreateNamespace()

-- The Terestrial trader is just a factory with a trader appearance and
-- consumer goods, but should only appear when there's a background planet.

function XFortress.interactionPossible(playerIndex, option)
    return CheckFactionInteraction(playerIndex, 10000)
end

function XFortress.initialize()
    local station = Entity()
    if station.title == "" then
        station.title = "Fortress"%_t
    end

    if onServer() then
        station:addScriptOnce("data/scripts/entity/merchants/consumer.lua", "Fortress"%_t, unpack(ConsumerGoods.XFortress()))
        
        -- local goods = {"XPassenger", "XPassengerLuxury"}
        -- station:addScriptOnce("data/scripts/entity/merchants/tradingpost.lua", goods, goods)
    end
    
    -- XRefinery.shop:initialize(station.translatedTitle)

    if onClient() then -- always override
        EntityIcon().icon = "data/textures/icons/pixel/skull-detailed.png"
        InteractionText(station.index).text = Dialog.generateStationInteractionText(station, random())
    end
end

