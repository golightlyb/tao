package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include ("utility")
include ("callable")

local function ends_with(str, ending)
   return ending == "" or str:sub(-#ending) == ending
end

local bonusScripts = {
    "systems/xarmor",
}

local getBonus = {}
for i = 1, #bonusScripts do
    getBonus[i] = include(bonusScripts[i].."_resistance")
end

-- implements a way to recalculate resistances based on ship components

function initialize()
    if onClient() then
        Entity():registerCallback("onSystemsChanged", "onSystemsChanged")
    end
end

function onSystemsChanged()
    invokeServerFunction("onChanged")
end

function onChanged()
    if onClient() then
        invokeServerFunction("onChanged")
        return
    end
    
    local entity = Entity()
    local shipSystem = ShipSystem(entity)
    if not shipSystem then return end
    
    if entity:getValue("xResistance") then
        resetResistance(entity)
    end
    
    local systems = shipSystem:getUpgrades() --player:getShipSystems(shipName)
    if not systems then return end
    
    local totalBonuses = {
        durability = {
            antimatter = 1.0,
            physical   = 1.0,
        },
        updated = false,
    }
    
    for system, installed in pairs(systems) do
        if not installed then goto continue end
        
        for i = 1, #bonusScripts do
            if ends_with(system.script, bonusScripts[i]..".lua") then
                bonuses = getBonus[i](system.seed, system.rarity, installed)
                if bonuses.durability then
                    totalBonuses.durability.antimatter = totalBonuses.durability.antimatter * (bonuses.durability.antimatter or 1.0)
                    totalBonuses.durability.physical   = totalBonuses.durability.physical   * (bonuses.durability.physical   or 1.0)
                    totalBonuses.updated = true
                end
            end
        end
        ::continue::
    end
    
    if totalBonuses.updated then
        applyResistance(entity, totalBonuses)
    end
end
callable(nil, "onChanged")

function resetResistance(entity)
    local dur = Durability(entity)
    if not dur then return end
    
    entity:setValue("xResistance", nil)
    dur:resetWeakness()
end

function applyResistance(entity, bonuses)
    local dur = Durability(entity)
    if not dur then return end
    
    entity:setValue("xResistance", true)
    
    dur:setWeakness(DamageType.AntiMatter, -1.0 + bonuses.durability.antimatter)
    dur:setWeakness(DamageType.Physical,   -1.0 + bonuses.durability.physical)
end


