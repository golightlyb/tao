
-- ships
table.insert(CraftIcons, "data/textures/icons/pixel/shield.png")

-- stations
table.insert(CraftIcons, "data/textures/icons/pixel/gaurd.png")
table.insert(CraftIcons, "data/textures/icons/pixel/mine.png")
table.insert(CraftIcons, "data/textures/icons/pixel/skull-detailed.png")
table.insert(CraftIcons, "data/textures/icons/pixel/asteroid.png")
table.insert(CraftIcons, "data/textures/icons/pixel/scrapyard_fat.png")

