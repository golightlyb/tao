package.path = package.path .. ";data/scripts/lib/?.lua"

include ("stringutility")

-- namespace XResistance
XResistance = {}

function XResistance.initialize()
    if onClient() then
        local player = Player()
        player:registerCallback("onShipChanged", "onShipChanged")
        player:registerCallback("onCraftChanged", "onChanged")
    end
end

function XResistance.onShipChanged(playerId, craftId)
    local entity = Sector():getEntity(craftId)
    
    local ok, _ = entity:invokeFunction("entity/xResistance.lua", "onChanged")
    if not ok then
        eprint("player/xResistance: could not invoke xResistance onChanged")
        return nil
    end
end

function XResistance.onCraftChanged(current, previous)
    local entity1 = Sector():getEntity(current)
    local entity2 = Sector():getEntity(previous)
    
    local ok, _ = entity1:invokeFunction("entity/xResistance.lua", "onChanged")
    if not ok then
        eprint("player/xResistance: could not invoke xResistance onChanged on entity1")
        return nil
    end
    
    local ok, _ = entity2:invokeFunction("entity/xResistance.lua", "onChanged")
    if not ok then
        eprint("player/xResistance: could not invoke xResistance onChanged on entity2")
        return nil
    end
end