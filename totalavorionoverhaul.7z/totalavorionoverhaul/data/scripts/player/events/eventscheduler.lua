
events = {}


if onServer() then

function EventScheduler.secure()
end

function EventScheduler.restore(times)
end


end
