
local old_create = create
function create(item, rarity, material, playerIndex)
    local item = old_create(item, rarity, material, playerIndex)
    if item then item:setValue("unsellable", nil) end
    return item
end
