package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

local FactionEradicationUtility = include("factioneradicationutility")
local Placer = include("placer")
local ShipUtility = include ("shiputility")
include("stringutility")
include("galaxy")

function create(item, rarity, factionIndex, hx, hy, x, y)

    item.stackable = true
    item.depleteOnUse = true
    item.icon = "data/textures/icons/security.png"
    item.rarity = rarity
    item:setValue("subtype", "XReinforcementSignal")
    item:setValue("factionIndex", factionIndex)
    
    item.name = "Reinforcements Signal Transmitter"%_t

    local price = 0
    if rarity.value >= RarityType.Exotic then
        price = 500 * 1000
    elseif rarity.value >= RarityType.Exceptional then
        price = 250 *1000
    elseif rarity.value >= RarityType.Rare then
        price = 100 * 1000
    else
        price = 50 * 1000
    end
    
    item.price = price * Balancing_GetSectorRichnessFactor(hx, hy)

    local tooltip = Tooltip()
    tooltip.icon = item.icon
    tooltip.rarity = rarity

    local title = item.name

    local headLineSize = 25
    local headLineFontSize = 15
    local line = TooltipLine(headLineSize, headLineFontSize)
    line.ctext = title
    line.ccolor = rarity.tooltipFontColor
    tooltip:addLine(line)

    -- empty line
    tooltip:addLine(TooltipLine(14, 14))

    local line = TooltipLine(18, 14)
    line.ltext = "Faction"%_t
    line.rtext = "${faction:"..factionIndex.."}"
    line.icon = "data/textures/icons/flying-flag.png"
    line.iconColor = ColorRGB(0.8, 0.8, 0.8)
    tooltip:addLine(line)

    

    -- empty line
    tooltip:addLine(TooltipLine(14, 14))

    local line = TooltipLine(20, 15)
    line.ltext = "Depleted on Use"%_t
    line.lcolor = ColorRGB(1.0, 1.0, 0.3)
    tooltip:addLine(line)


    -- empty line
    tooltip:addLine(TooltipLine(14, 14))

    local line = TooltipLine(18, 14)
    line.ltext = "Can be activated by the player to summon"%_t
    tooltip:addLine(line)
    line.ltext = "reinforcements from an allied faction."%_t
    tooltip:addLine(line)

    tooltip:addLine(TooltipLine(14, 14))
    local line = TooltipLine(18, 14)
    if rarity.value >= RarityType.Exotic then
        line.ltext = "Warps in a fortress and a large escort."%_t
    elseif rarity.value >= RarityType.Exceptional then
        line.ltext = "Warps in a defense platform and an escort."%_t
    elseif rarity.value >= RarityType.Rare then
        line.ltext = "Warps in several ships."%_t
    else
        line.ltext = "Warps in several small ships."%_t
    end
    tooltip:addLine(line)

    item:setTooltip(tooltip)

    return item
end

local messages = {
    "The cavalry has arrived!"%_T,
    "This is the Rightous Wrath responding to an emergency distress signal."%_T,
    "Backup is here. Woe to our enemies!"%_T,
}

function run(playerIndex, factionIndex, rarity)
    local player = Player(playerIndex)
    if not player then return end
    local faction = Faction(factionIndex)
    if not faction then return end
    
    local ships = {}
    local stations = {}
    
    local generatedShips = {}
    local function post(ship)
        ship.title = "Allied " .. ShipUtility.getMilitaryNameByVolume(ship.volume)
        table.insert(generatedShips, ship)
    end
    
    if rarity.value >= RarityType.Exotic then
        ships = {
            {variant="garrison", number=5, faction=faction, post=post},
        }
        stations = {
            {variant="fortress", faction=faction},
        }
    elseif rarity.value >= RarityType.Exceptional then
        ships = {
            {variant="garrison", number=3, faction=faction, post=post},
        }
        stations = {
            {variant="defensePlatform", faction=faction},
        }
    elseif rarity.value >= RarityType.Rare then
        ships = {
            {variant="garrison", number=1, faction=faction, post=post},
            {variant="antipirate", number=3, faction=faction, post=post},
        }
    else
        ships = {
            {variant="antipirate", number=3, faction=faction, post=post},
        }
    end
    
    local playerFaction = player
    if playerFaction.isAlliance then playerFaction = Alliance(playerIndex) end
     
    local position = vec3(0, 0, 0)
    if player.craft then
        position = player.craft.translationf
    end
    
    if not faction.isAIFaction then
        Player():sendChatMessage("", ChatMessageType.Information, "No response."%_T)
        return false
    end

    if FactionEradicationUtility.isFactionEradicated(faction.index) then
        Player():sendChatMessage("", ChatMessageType.Information, "No response."%_T)
        return false
    end

    local sender = NamedFormat("${faction} Headquarters"%_T, {faction = faction.baseName})
    
    local XSectorGenerator = include("xSectorGenerator")
    local sector = Sector()
    local x, y = sector:getCoordinates()
    local sectorGenerator = XSectorGenerator(x, y, sector, faction, false, random)
    
    sectorGenerator:createContents({
        x = {
            noSector = true,
            shapes = {
                {
                    variant  = "arc",
                    params   = {radius=1000, span=1.0, thickness=200, depth=50},
                    offset   = position,
                    ships    = ships,
                    stations = stations,
                },
            },
        },
    })
    
    local message = messages[getInt(1, #messages)]
    
    Player():sendChatMessage(sender, ChatMessageType.Normal, message)
    
    Placer.resolveIntersections(generatedShips)
    
    return true
end

function activate(item)

    local player = Player()

    local factionIndex = item:getValue("factionIndex")
    if not factionIndex then return false end

    --invokeServerFunction(player.index, factionIndex, item.rarity)
    
    return run(player.index, factionIndex, item.rarity)
end
