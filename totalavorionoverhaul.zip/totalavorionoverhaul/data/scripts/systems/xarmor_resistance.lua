
return function(seed, rarity, permanent)
    -- NOTE!!! called by scripts/entity/xResistance.lua
    if parmanent == false then return {} end
    local r = rarity.value + 1
    return {
        durability = {
            antimatter = 0.90, --math.pow(0.95,    r),
            physical   = 0.95, --math.pow(0.975,   r),
        },
    }
end
