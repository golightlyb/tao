
package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"
include("xUtil")

-- responsible for saving the shapes used to generate a sector
-- sent by a sector remplate to xSectorGenerator

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace SectorLocations
SectorLocations = {}

local data = nil

function SectorLocations.initialize()
end

function SectorLocations.secure()
    return data
end

function SectorLocations.restore(data_in)
    data = (data_in or {})
end

function SectorLocations.syncToClient()
    invokeClientFunction(Player(callingPlayer), "restore", data)
end
callable(SectorLocations, "syncToClient")

if onServer() then
    function SectorLocations.set(locations)
        data = locations
    end
    
    function SectorLocations.get()
        return data
    end
end

if onClient() then
    function SectorLocations.get()
        if data == nil then
            invokeServerFunction("syncToClient")
        else
            return data
        end
    end
end

