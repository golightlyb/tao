if onServer() then

    function SpawnPersecutors.getUpdateInterval()
        return 60 * 60
    end

    function SpawnPersecutors.initialize()
        terminate()
    end

    function SpawnPersecutors.update()
        terminate()
    end

end
