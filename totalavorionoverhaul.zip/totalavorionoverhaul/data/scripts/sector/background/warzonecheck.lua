local ShipUtility = include("shiputility")
local Placer = include("placer")
local XSectorGenerator = include("xSectorGenerator")
include("randomext")

if onServer() then

    function WarZoneCheck.onDestroyed(destroyedId, destroyerId)

        local victim = Entity(destroyedId)
        if not victim then return end

        if victim:getValue("is_pirate") then return end
        if victim:getValue("is_xsotan") then return end
        if victim:getValue("is_persecutor") then return end
        if not victim.type == EntityType.Fighter then return end
        if not victim.type == EntityType.Drone then return end
        if not victim:hasComponent(ComponentType.Plan) then return end
        if not victim:hasComponent(ComponentType.Durability) then return end
        if victim.type == 0 then return end -- added

        local factor = 1

        -- don't overpunish players who already lost ships/stations by immediately calling out a warzone
        if victim.playerOwned or victim.allianceOwned then
            factor = 0.2
        end

        if victim.isStation then
            WarZoneCheck.increaseScore(100 * factor)
        else
            if Sector():getNumEntitiesByType(EntityType.Station) == 0 then return end

            local destroyer = Entity(destroyerId)
            if destroyer then
                -- less influence from pirates and xsotan
                if destroyer:getValue("is_pirate") then factor = math.min(factor, 0.25) end
                if destroyer:getValue("is_xsotan") then factor = math.min(factor, 0.25) end
                if destroyer:getValue("is_persecutor") then factor = math.min(factor, 0.25) end

                if destroyer.playerOwned or destroyer.allianceOwned then
                    -- weigh player factions normally
                    WarZoneCheck.increaseScore(40 * factor)
                else
                    -- weigh AI factions less for increased influence of players
                    WarZoneCheck.increaseScore(10 * factor)
                end
            end
        end

    end

    function WarZoneCheck.spawnReinforcements()

        local sector = Sector()
        -- safeguard: if there are already reinforcements for some reason, don't spawn new ones
        if sector:getEntitiesByScriptValue("war_zone_reinforcement") then return end

        
        -- to spawn reinforcements, sector must be controlled by an AI faction
        local x, y = sector:getCoordinates()
        local faction = Galaxy():getControllingFaction(x, y)
        if not faction or not faction.isAIFaction then return end

        if FactionEradicationUtility.isFactionEradicated(faction.index) then return end

        local generator = XSectorGenerator(x, y, Sector(), faction, true, random())

        local ships = {}
        local function post(ship)
            ship:removeScript("entity/antismuggle.lua")
            ship:setValue("war_zone_reinforcement", true)
            ship.title = "Reinforcement " .. ShipUtility.getMilitaryNameByVolume(ship.volume)
            table.insert(ships, ship)
        end
        
        generator:createContents({
            x = {
                noSector = true,
                shapes = {
                    {
                        variant   = "arc",
                        params = {radius=200, span=1.0, thickness=100, depth=20},
                        offset = vec3(getFloat(-1000, 1000), getFloat(-100, 100), getFloat(-1000, 1000)),
                        ships  = {
                            {variant="garrison", number=7, post=post},
                        },
                    },
                },
            },
        })

        Placer.resolveIntersections(ships)

        -- for unit tests
        WarZoneCheck.reinforcementsRequested = 7
    end

end