if onClient() then

    function CorruptedAIHealthBar.getUpdateInterval()
        return 60 * 60
    end


    function CorruptedAIHealthBar.initialize()
        terminate()
    end

    function CorruptedAIHealthBar.updateClient(timePassed)
        terminate()
    end
end



