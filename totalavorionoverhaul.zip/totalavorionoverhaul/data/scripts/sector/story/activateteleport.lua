
if onServer() then
    function ActivateTeleport.getUpdateInterval()
        return 60 * 60
    end
end

if onClient() then
    function ActivateTeleport.getUpdateInterval()
        return 60 * 60
    end
end

function ActivateTeleport.getTeleporters()
    return {}
end

if onServer() then

    function ActivateTeleport.updateServer()
        terminate()
    end

    function ActivateTeleport.activate(withEnemies)
        terminate()
    end

    function ActivateTeleport.spawnEnemies(amount, scale)
    end

end -- onServer()

if onClient() then

    function ActivateTeleport.updateClient(timeStep)
        terminate()
    end

    function ActivateTeleport.updateClientLowFq()
            terminate()
    end

end -- onClient()

