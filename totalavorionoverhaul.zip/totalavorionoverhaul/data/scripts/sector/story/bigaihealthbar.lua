if onClient() then

    function BigAIHealthBar.getUpdateInterval()
        return 60 * 60
    end

    function BigAIHealthBar.initialize()
        terminate()
    end

    function BigAIHealthBar.updateClient(timePassed)
        terminate()
    end

end
