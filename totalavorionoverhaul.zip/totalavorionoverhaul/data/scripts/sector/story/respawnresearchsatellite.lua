
if onServer() then
    function RespawnResearchSatellite.initialize()
        terminate()
    end
end
