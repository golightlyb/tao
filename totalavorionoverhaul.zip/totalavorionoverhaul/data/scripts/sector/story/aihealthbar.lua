
if onClient() then

    function AIHealthBar.getUpdateInterval()
        return 60 * 60
    end

    function AIHealthBar.initialize()
        terminate()
    end

    function AIHealthBar.updateClient(timePassed)
        terminate()
    end

end

if onServer() then

    function AIHealthBar.getUpdateInterval()
        return 60 * 60
    end

    function AIHealthBar.updateServer(timePassed)
        terminate()
    end

end

function AIHealthBar.setVisible()
end
