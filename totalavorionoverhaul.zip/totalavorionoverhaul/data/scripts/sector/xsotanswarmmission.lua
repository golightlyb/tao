mission.globalPhase.updateServer = function()
    terminate()
end
mission.globalPhase.onSectorEntered = function(x, y)
    terminate()
end

mission.phases[1] = {}
mission.phases[1].onBeginServer = function()
    terminate()
end
mission.phases[1].onBeginClient = function()
    terminate()
end
mission.phases[1].updateServer = function()
    terminate()
end
mission.phases[2].onBegin = function()
    terminate()
end
function onXsotanSwarmEndBossSpawned(x, y)
    terminate()
end

function onSectorArrivalConfirmed(playerIndex, x, y)
    terminate()
end

function showMissionMessage(message)
end
