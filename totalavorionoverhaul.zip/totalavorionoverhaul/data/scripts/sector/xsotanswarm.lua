if onServer() then

    function XsotanSwarm.getUpdateInterval()
        return 60 * 60
    end

    function XsotanSwarm.initialize()
        terminate()
    end

    function XsotanSwarm.canHappenInThisSector()
        return false
    end

    function XsotanSwarm.updateServer()
        terminate()
    end

    function XsotanSwarm.onPlayerEntered(playerIndex, sectorChangeType)
        terminate()
    end

    function XsotanSwarm.onPlayerLeft(playerIndex, sectorChangeType)
        terminate()
    end

    function XsotanSwarm.addWrapperMissionToPlayers()
    end

    function XsotanSwarm.spawnBackgroundXsotan()
    end

    function XsotanSwarm.spawnHenchmenXsotan(num)
    end

    function XsotanSwarm.spawnLevel2()
    end

    function XsotanSwarm.spawnLevel3()
    end

    function XsotanSwarm.spawnLevel4()
    end

    function XsotanSwarm.spawnLevel5()
    end

    function XsotanSwarm.spawnEndBoss(position, scale)
    end

    function XsotanSwarm.attachMax(plan, attachment, dimStr)
    end

    function XsotanSwarm.attachMin(plan, attachment, dimStr)
    end

    function XsotanSwarm.getAllSpawnedShips()
        return {}
    end

    function XsotanSwarm.generateUpgrade()
        return {}
    end

    function XsotanSwarm.countAliveXsotan()
        return 0
    end

    function XsotanSwarm.miniBossSlain()
        return true
    end

    function XsotanSwarm.onDestroyed(index)
    end

    function XsotanSwarm.onXsotanSwarmEventFailed()
    end

    function XsotanSwarm.onXsotanSwarmEventWon()
    end

    function XsotanSwarm.secure()
    end

    function XsotanSwarm.restore(data_in)
        terminate()
    end

end

if onClient() then
    function XsotanSwarm.showBossBar(entity, small)
    end
end

function XsotanSwarm.setSpawnEndBossImmediately()
end
