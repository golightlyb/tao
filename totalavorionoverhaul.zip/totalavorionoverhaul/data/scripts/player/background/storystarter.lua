-- replaced with stubs because sometimes this script is registered on a
-- player even when removed.

StoryStarter = {}

if onServer() then

function StoryStarter.updateServer(timestep)
    terminate()
end

end
