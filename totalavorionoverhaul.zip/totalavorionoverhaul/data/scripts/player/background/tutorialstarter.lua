
-- replaced with stubs because sometimes this script is registered on a
-- player even when removed.

-- NOTE: it is not allowed to merely terminate the tutorial script

if onServer() then
    function TutorialStarter.initialize()
    end

    function TutorialStarter.getUpdateInterval()
        return 60 * 60
    end

    function TutorialStarter.update()
    end

    function TutorialStarter.playerQualifiesForStoryStart()
    end

    function TutorialStarter.countAccomplishedTutorials()
    end

    function TutorialStarter.onItemAdded(index, amount, amountBefore)
    end

    function TutorialStarter.onReconstructionSiteChanged(index)
    end

    function TutorialStarter.delayedSendDeviceMail()
    end

    function TutorialStarter.onPlanModifiedByBuilding(objectIndex)
    end

    function TutorialStarter.onShipChanged(playerIndex, craftId)
    end

    function TutorialStarter.onCaptainChanged(entityId, captain)
    end

    function TutorialStarter.onSectorArrivalConfirmed(playerIndex, x, y)
    end

    function TutorialStarter.onSectorEntered(playerIndex, x, y, sectorChangeType)
    end

    function TutorialStarter.onBuildingKnowledgeUnlocked(material)
    end

    function TutorialStarter.checkDistance(x, y)
    end
end

function TutorialStarter.addTutorialMission(emergency, hireCrew)
end

function TutorialStarter.addSpawnAdventurerScript()
end

function TutorialStarter.onTutorialAccomplished(rewardPlayer)
end

function TutorialStarter.setUnTransferrable(bool_in)
end

