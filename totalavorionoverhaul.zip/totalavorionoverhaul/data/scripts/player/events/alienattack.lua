if onServer() then

    function initialize()
        terminate()
    end

    function getUpdateInterval()
        return 60
    end

    function update(timeStep)
        terminate()
    end
end

function createEnemies(volumes, attackType, message)
end
