if onServer() then

    function HeadHunter.initialize()
        terminate()
    end

    function HeadHunter.getUpdateInterval()
        return 60 * 60
    end

    function HeadHunter.update(timeStep)
        terminate()
    end

    function HeadHunter.findNearbyEnemyFaction()
        return
    end

    function HeadHunter.createEnemies(faction, useHeadhunters)
    end

    function HeadHunter.sarcasticRemark()
    end

    function HeadHunter.makeNote(player, huntingFaction)
    end

end
