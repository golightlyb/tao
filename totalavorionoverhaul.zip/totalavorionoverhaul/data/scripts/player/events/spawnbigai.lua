function BigAI.sync(data_in)
end


function BigAI.initialize()
    terminate()
end


if onClient() then

    function BigAI.onMapRenderAfterUI()
    end

    function BigAI.renderIcons()
    end

end


if onServer() then

    function getUpdateInterval()
        return 60 * 60
    end

    function BigAI.update(timestep)
        terminate()
    end

    function BigAI.checkForDefeat()
        terminate()
    end

    function BigAI.onSectorLeft(playerId, x, y, changeType)
        terminate()
    end

    function BigAI.getFaction()
    end

    function BigAI.addTurrets(boss, numTurrets)
    end


    function BigAI.spawn(x, y)
    end

    function BigAI.restore(data_in)
        terminate()
    end

end
