
function getUpdateInterval()
    if onServer() then
        return 60 * 60
    end
end

function initialize()
    terminate()
end

function updateClient(timeStep)
    terminate()
end

function updateServer()
    terminate()
end


