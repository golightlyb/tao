if onServer() then

    function initialize(firstInitialization)
        terminate()
    end

    function onSectorEntered(player, x, y)
        terminate()
    end

end

function abandon()
    if onClient() then
        invokeServerFunction("abandon")
        return
    end
    terminate()
end
callable(nil, "abandon")

if onClient() then

    function initialize()
        terminate()
    end

    function restore(data)
        terminate()
    end

end


