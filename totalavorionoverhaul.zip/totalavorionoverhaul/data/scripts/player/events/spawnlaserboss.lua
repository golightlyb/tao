function LaserBoss.initialize()
    terminate()
end

if onServer() then

    function LaserBoss.getHint()
    end

    function LaserBoss.onSectorEntered(player, x, y, changeType)
    end

    function LaserBoss.spawnBoss()
    end

    function LaserBoss.clearSector()
    end

    function LaserBoss.spawnLaserBoss()
    end

    function LaserBoss.spawnArena()
    end

    function LaserBoss.getFaction()
    end

    function LaserBoss.addTurrets(boss, numTurrets)
    end

    function LaserBoss.secure()
    end

    function LaserBoss.restore(data_in)
    end

end
