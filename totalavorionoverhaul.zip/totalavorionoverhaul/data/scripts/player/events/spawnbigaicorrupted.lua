function BigAICorrupted.initialize()
    terminate()
end

if onClient() then

    function BigAICorrupted.onMapRenderAfterUI()
    end

    function BigAICorrupted.renderIcons()
    end

end

if onServer() then

    function BigAICorrupted.getUpdateInterval()
        return 60 * 60
    end

    function BigAICorrupted.update(timestep)
        terminate()
    end

    function BigAICorrupted.checkForDefeat()
    end

    function BigAICorrupted.onSectorEntered(playerIndex, x, y, sectorChangeType)
        terminate()
    end

    function BigAICorrupted.onSectorLeft(playerId, x, y, changeType)
        terminate()
    end

    function BigAICorrupted.getFaction()
    end

    function BigAICorrupted.addTurrets(boss, numTurrets)
    end

    function BigAICorrupted.spawn(x, y)
    end

end
