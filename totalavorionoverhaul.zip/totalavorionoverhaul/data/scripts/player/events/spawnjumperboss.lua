function JumperBoss.spawnBoss(x, y)
end
