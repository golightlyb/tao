if onServer() then

    function SpawnAsteroidBoss.initialize()
        terminate()
    end

    function SpawnAsteroidBoss.onSectorEntered(player, x, y, changeType)
        terminate()
    end

    function SpawnAsteroidBoss.createBoss()
    end

    function SpawnAsteroidBoss.createShieldAsteroids()
    end

    function SpawnAsteroidBoss.getNumAsteroids()
        return 0
    end

    function SpawnAsteroidBoss.calculateNextLocation(range_in)
    end

    function SpawnAsteroidBoss.secure()
    end

    function SpawnAsteroidBoss.restore(data_in)
        terminate()
    end

end

