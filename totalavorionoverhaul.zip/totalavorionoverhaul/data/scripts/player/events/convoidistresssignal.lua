if onServer() then

    function getUpdateInterval()
        return 60*60
    end

    function restore(data)
        terminate()
    end

    function initialize(firstInitialization)
        terminate()
    end

    function updateServer(timeStep)
        terminate()
    end

    function updatePresentShips()
    end

    function onSectorLeft(player, x, y)
    end

    function onSectorEntered(player, x, y)
    end

    function sendCoordinates()
    end

end

function abandon()
    if onClient() then
        invokeServerFunction("abandon")
        return
    end

    terminate()
end
callable(nil, "abandon")

if onClient() then

    function initialize()
        terminate()
    end

end




