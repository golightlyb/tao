-- if this function returns false, the script will not be listed in the interaction window,
-- even though its UI may be registered
function interactionPossible(playerIndex)
    return false
end

function initUI()
end

function initialize(x, y)
    terminate()
end

function updateClient(timeStep)
    termiate()
end

function onRenderHud()
end

function onInspect()
end

function sync(x, y)
end

