package.path = package.path .. ";data/scripts/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"

include ("utility")
include ("stringutility")
include ("productions")
include ("xSectorUtil")

-- namespace XStationFounder
XStationFounder = {}
XStationFounder.__index = XStationFounder

local function cleanName(s)
    -- e.g. "Luxury Electronics Manufacturer ${size}", -> "Luxury Electronics Manufacturer",
    if string.ends(s, " ${size}") then
        return string.sub(s, 1, -8)
    else
        return s
    end
end

function XStationFounder.checkIfLimitReached(player)
    local settings = GameSettings()
    local limit = player.maxNumStations

    if limit and limit >= 0 and player.numStations >= limit then
        player:sendChatMessage("", 1, "Maximum station limit for this faction (%s) of this server reached!"%_t, limit)
        return true
    end

    local sector = Sector()
    if settings.maximumStationsPerSector >= 0 then
        local stations = sector:getNumEntitiesByType(EntityType.Station)
        if stations >= settings.maximumStationsPerSector then
            player:sendChatMessage("", 1, "Maximum station limit for this sector (%s) of this server reached!"%_t, settings.maximumStationsPerSector)
            return true
        end
    end
end

if onClient() then
    local productions      = productions -- from include lib/productions.lua
    local serviceStations  = xUtil_serviceStations  -- from xSectorUtil
    local militaryStations = xUtil_militaryStations -- from xSectorUtil
    local specialProducers = xUtil_specialProducers -- from xSectorUtil

    local locations
    local sectorOwner, isCentral
    
    local titleLabel
    local labelStationFee
    local labelSectorFee
    local labelTerritoryFee
    local labelRelationsFee
    local labelTotalFee
    local labelFoundingNotes
    
    local comboboxLocation, comboboxLocationInitialised
    local comboboxFactoryType, comboboxFactoryTypeInitialised, labelFactoryType
    
    local buttonFoundStation
    
    local selectedStationType
    local selectStationButton_MapIndexToVariant = {}
    
    local centralAreaTerritoryFee = 1.5
    local outerAreaTerritoryFee   = 1.25
    
    function XStationFounder._createStationTypeButtons(tab, lister, variants)
        for i = 1, #variants do
            local variant = variants[i]
            local button = tab:createButton(lister:nextRect(20), variant.shorttitle%_t, "_onStationTypeClicked")
            button.tooltip = variant.tooltip
            selectStationButton_MapIndexToVariant[button.index] = variant
        end
    end

    function XStationFounder._onStationTypeClicked(button)
        local variant = selectStationButton_MapIndexToVariant[button.index]
        selectedStationType = variant
        sectorOwner, isCentral = XStationFounder._getSectorOwner(Sector())
        XStationFounder._refreshGUI()
    end
    
    function XStationFounder._onFoundStationClicked(button)
        local player = Player()
    
        -- TODO proper error messages
        if selectedStationType == nil then eprint("no station selected"); return end
        if locations == nil then eprint("locations not yet loaded"); return end
       
        if XStationFounder.checkIfLimitReached(Player()) then return end
        
        local value = comboboxLocation.selectedValue 
        if value == nil then eprint("no selection"); return end
        local factoryType = nil
        if comboboxFactoryType and comboboxFactoryType.visible then factoryType = comboboxFactoryType.selectedValue end
        
        local location
        if value == 0 then
             location = {
                variant = "arc",
                params  = {radius=1000, span=1.0, thickness=50, depth=50},
                offset  = vec3(0, -200, 0)
            }
        else
            location = locations[value]
        end
        
        local fees = XStationFounder._getSectorFees(Sector(), player, (selectedStationType.foundingCost or 0))
        local fee = fees.totalFee
        
        local canPay, _, _ = player:canPay(fee)
        if not canPay then
            player:sendChatMessage("you can't afford this"%_T)
            return
        end
        
        if selectedStationType.variant == "mine" then
            if factoryType == nil then eprint("no factory type selection"); return end
            invokeServerFunction("spawn", location, "mines", {factoryType}, fee, factoryType)
        elseif selectedStationType.variant == "factory" then
            if factoryType == nil then eprint("no factory type selection"); return end
            invokeServerFunction("spawn", location, "factories", {factoryType}, fee, factoryType)
        else
            invokeServerFunction("spawn", location, selectedStationType.variant, nil, fee, selectedStationType.title)
        end
        
        XStationFounder._reset()
        XStationFounder._refreshGUI()
    end

    function XStationFounder._reset()
        selectedStationType = nil
        comboboxLocationInitialised = false
        comboboxFactoryTypeInitialised = false
    end
    
    function XStationFounder._onSectorEntered()
        -- send the request to the server immediately
        XStationFounder._reset()
        xSectorUtil_GetSectorLocations(Sector())
    end
    
    function XStationFounder:initialize()
        local p = Player()
        p:registerCallback("onSectorEntered", "_onSectorEntered")
    
        local tab = PlayerWindow():createTab("Station Founding"%_t, "data/textures/icons/station.png", "Found a New Station"%_t)
        tab.onShowFunction = "_onShowTab"

        local lister = UIVerticalLister(Rect(tab.size), 10, 0)
        titleLabel = tab:createLabel(lister:nextRect(30), "..."%_t, 28)
        titleLabel:setLeftAligned()

        local splitter = UIVerticalMultiSplitter(lister.rect, 10, 0, 3)

        ---[LEFT]-------------------------------------------------------------------
        local leftSplitter = UIHorizontalSplitter(splitter:partition(0), 10, 0, 0.5)

        local lister = UIVerticalLister(leftSplitter.top, 10, 10)

        tab:createLabel(lister:nextRect(20), "Service Stations"%_t, 20):setLeftAligned()
        XStationFounder._createStationTypeButtons(tab, lister, serviceStations)
        
        tab:createLabel(lister:nextRect(40), "Mines & Factories"%_t, 20):setLeftAligned()
        XStationFounder._createStationTypeButtons(tab, lister, specialProducers)
        
        tab:createLabel(lister:nextRect(40), "Military"%_t, 20):setLeftAligned()
        XStationFounder._createStationTypeButtons(tab, lister, militaryStations)
        
        ---[RIGHT]------------------------------------------------------------------
        local rightRect = Rect(splitter:partition(1).lower, splitter:partition(3).upper)

        ---[RIGHT / OPTIONS]---------------------------------------------------------
        local rect = Rect(rightRect.lower, rightRect.upper - vec2(0, 320))
        tab:createFrame(rect)
        local lister = UIVerticalLister(rect, 10, 10)
        local split = UIVerticalSplitter(lister:nextRect(20), 10, 0, 0.7)
        
        tab:createLabel(split.left, "Station Configuration"%_t, 20):setLeftAligned()
        labelFoundingNotes = tab:createLabel(lister:nextRect(20), "...", 15)
        labelFoundingNotes:setLeftAligned()
        
        local split = UIVerticalSplitter(lister:nextRect(20), 10, 0, 0.5)
        local splitLeft = UIVerticalSplitter(split.left, 10, 0, 0.5)
        
        local splitLeftAgain = UIVerticalSplitter(split.left, 10, 0, 0.3)
        local splitLeftLeftLister = UIVerticalLister(splitLeftAgain.left, 0, 0)
        local splitLeftRightLister = UIVerticalLister(splitLeftAgain.right, 0, 0)
        
        tab:createLabel(splitLeftLeftLister:nextRect(20), "Location:", 15)
        comboboxLocation = tab:createValueComboBox(splitLeftRightLister:nextRect(20), "_refreshGUI")
        
        splitLeftLeftLister:nextRect(10); splitLeftRightLister:nextRect(10)
        labelFactoryType = tab:createLabel(splitLeftLeftLister:nextRect(20), "Type:", 15)
        comboboxFactoryType = tab:createValueComboBox(splitLeftRightLister:nextRect(20), "_refreshGUI")
        
        --[RIGHT / FEE DETAILS]---------------------------------------------------------
        local rect = Rect(rightRect.lower + vec2(0, 390), rightRect.upper - vec2(0, 110))
        tab:createFrame(rect)
        local lister = UIVerticalLister(rect, 10, 10)
        local split = UIVerticalSplitter(lister:nextRect(20), 10, 0, 0.7)
        tab:createLabel(split.left, "Fee Details"%_t, 20):setLeftAligned()
        
        labelStationFee = tab:createLabel(lister:nextRect(10), "...", 15)
        labelStationFee:setLeftAligned()
        labelTerritoryFee = tab:createLabel(lister:nextRect(10), "...", 15)
        labelTerritoryFee:setLeftAligned()
        labelSectorFee = tab:createLabel(lister:nextRect(10), "...", 15)
        labelSectorFee:setLeftAligned()
        labelTotalFee = tab:createLabel(lister:nextRect(10), "...", 15)
        labelTotalFee:setLeftAligned()
        
        --[RIGHT / BOTTOM]--------------------------------------------------------------
        local rect = Rect(rightRect.lower + vec2(0, 600), rightRect.upper - vec2(0, 20))
        tab:createFrame(rect)
        local lister = UIVerticalLister(rect, 10, 10)
        buttonFoundStation = tab:createButton(lister:nextRect(50), "..."%_t, "_onFoundStationClicked")
        buttonFoundStation.visible = false
    end

    function XStationFounder._refreshGUI()
        local sector = Sector()
        locations = xSectorUtil_GetSectorLocations(sector)
        
        local player = Player()
        
        local variant = selectedStationType
        if variant and (locations ~= nil) then
            fees = XStationFounder._getSectorFees(sector, player, (variant.foundingCost or 0))
        
            titleLabel.caption             = "Found a new "..variant.title
            labelStationFee.caption        = "Station fee: "%_t ..fees.baseFeeText
            labelTerritoryFee.caption      = "Faction territory fee: "%_t .. fees.territoryFeeText
            labelSectorFee.caption         = "Sector fee: "%_t .. fees.sectorFeeText
            labelTotalFee.caption          = "Total fee: "%_t .. fees.totalFeeText
            buttonFoundStation.caption     = "Found Station ("..toReadableNumber(fees.totalFee).." Cr.)"
            if variant.foundingNotes then
                labelFoundingNotes.caption = variant.tooltip.." "..variant.foundingNotes
            else
                labelFoundingNotes.caption = ""
            end
            
            if not comboboxLocationInitialised then
                comboboxLocation:clear()
                for i = 1, #locations do
                    local location = locations[i]
                    if location.name then
                        comboboxLocationInitialised = true
                        comboboxLocation:addEntry(i, location.name, ColorRGB(1.0, 1.0, 1.0))
                    end
                end
                if not comboboxLocationInitialised then
                    comboboxLocationInitialised = true
                    comboboxLocation:addEntry(0, "Anywhere", ColorRGB(1.0, 1.0, 1.0))
                end
            end
            
            comboboxLocation:show()
            buttonFoundStation:show()
        else
            titleLabel.caption         = "Found a new station"
            labelStationFee.caption    = ""
            labelTerritoryFee.caption  = ""
            labelSectorFee.caption     = ""
            labelTotalFee.caption      = ""
            labelFoundingNotes.caption = ""
            
            comboboxLocationInitialised = false
            comboboxLocation:hide()
            buttonFoundStation:hide()
        end
        
        if variant and (locations ~= nil) and (variant.variant == "mine" or variant.variant == "factory") then
            if comboboxFactoryTypeInitialised ~= variant.variant then
                comboboxFactoryType:clear()
                for i = 1, #productions do
                    local p = productions[i]
                    
                    if p.noauto then goto continue end
                    if (selectedStationType.variant == "mine") ~= (p.mine or false) then goto continue end
                    
                    local name = cleanName(p.factory)
                    comboboxFactoryType:addEntry(name, name, ColorRGB(1.0, 1.0, 1.0))
                    
                    ::continue::
                end
            end
            comboboxFactoryTypeInitialised = variant.variant
            comboboxFactoryType:show()
            labelFactoryType:show()
        else
            comboboxFactoryTypeInitialised = nil
            comboboxFactoryType:hide()
            labelFactoryType:hide()
        end
    end

    function XStationFounder._onShowTab()
        XStationFounder._refreshGUI()
    end
    
    function XStationFounder._getSectorOwner(sector) -- returns owner, isCentralArea
        local galaxy = Galaxy()
        local x, y = sector:getCoordinates()
        local factionIndex = galaxy:getControllingFaction(x, y)
        if not factionIndex then return nil, false end
        local controllingFaction = Faction(factionIndex)
        local isCentralArea = galaxy:isCentralFactionArea(x, y, factionIndex)
        return controllingFaction, isCentralArea
    end

    function XStationFounder._getSectorFees(sector, player, baseCost)
        local fees = {
            baseFee          = baseCost,
            baseFeeText      = toReadableNumber(baseCost).." Cr.",
            territoryFee     = 1,
            territoryFeeText = "none (no man's land)"%_t,
            sectorFee        = 1,
            sectorFeeText    = "none"%_t,
            totalFee         = 0,
            totalFeeText     = "",
        }

        if sectorOwner then
            if sectorOwner.isPlayer then
                -- TODO this needs better checks for multiplayer and alliances
                fees.territoryFeeText = "x1 (player territory)"%_t
            elseif isCentral then
                fees.territoryFee     = centralAreaTerritoryFee
                fees.territoryFeeText = "x" .. fees.territoryFee .. " (faction core territory)"%_t
            else
                fees.territoryFee     = outerAreaTerritoryFee
                fees.territoryFeeText = "x" .. fees.territoryFee.. " (faction outer territory)"%_t
            end
            
            if not sectorOwner.isPlayer then
                local relations = player:getRelations(sectorOwner.index)
                local price = lerp(relations, -80000, 85000, 4.0, 1.0)
                fees.territoryFee = fees.territoryFee * price
                fees.territoryFeeText = fees.territoryFeeText .. " x" ..  string.format("%.1f", price) .. " (from faction relations)"%_t
            end
        end
        
        local stations = 0
        for _, v in pairs({sector:getEntitiesByType(EntityType.Station)}) do
            if not Faction(v.factionIndex).isPlayer then
                stations = stations + 1
            end
        end
        if stations > 0 then
            fees.sectorFee = math.pow(1.05, stations-1)
            if stations > 12 then
                fees.sectorFee = math.max(fees.sectorFee, math.pow(1.2, stations-12))
            end
            fees.sectorFeeText = "x" ..  string.format("%.1f", fees.sectorFee) .. " (from "..stations.." existing stations in sector)"
        end
        
        fees.totalFee = fees.baseFee * fees.territoryFee * fees.sectorFee
        fees.totalFee = math.ceil(fees.totalFee)
        fees.totalFeeText = toReadableNumber(fees.totalFee).." Cr."
        
        if fees.territoryFee > 1 or fees.sectorFee > 1 then
            fees.totalFeeText = fees.totalFeeText .. string.format(" (adjusted; base cost x%.2f)", fees.sectorFee * fees.territoryFee)
        end
        
        return fees
    end
end

if onServer() then
    local ShipUtility = include("shiputility")
    local Placer = include("placer")
    local XSectorGenerator = include("xSectorGenerator")

    function XStationFounder.spawn(location, variant, productions, fee, title)
        local player = Player(callingPlayer)
        local sector = Sector()
        local x, y = sector:getCoordinates()
        local sectorGenerator = XSectorGenerator(x, y, sector, faction, false, random)
    
        local canPay, _, _ = player:canPayMoney(fee)
        if not canPay then
            player:sendChatMessage("Station Founder"%_t, 1, "you can't afford this"%_T)
            return
        else
            player:pay("Paid %1% Credits to found a "%_T .. title, fee)
        end
    
        local placed = {}
        local function post(station)
            table.insert(placed, station)
        end
        
        local contents = {
            x = {
                noSector = true,
                shapes = {
                    {
                        variant   = location.variant,
                        params    = location.params,
                        offset    = location.offset,
                        stations  = {
                            {variant=variant, faction=player, addCoreSystem=true, noCargo=true, post=post, productions=productions},
                        },
                    },
                },
            },
        }
        --printTable(contents)
        sectorGenerator:createContents(contents)
    
        Placer.resolveIntersections(placed)
        
        player:sendChatMessage("Station Founder", 0, "Founded a "..title.."!")
    end
    callable(XStationFounder, "spawn")
end


