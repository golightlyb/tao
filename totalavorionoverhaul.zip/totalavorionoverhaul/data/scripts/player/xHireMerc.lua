package.path = package.path .. ";data/scripts/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"

include ("utility")
include ("stringutility")
include ("productions")
include ("xSectorUtil")

-- namespace XHireMerc
XHireMerc = {}
XHireMerc.__index = XHireMerc

function XHireMerc.checkIfLimitReached(player)
    -- TODO
end

if onClient() then
    -- TODO
end

if onServer() then
    -- TODO
end


