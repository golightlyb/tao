package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include ("xUtil")
include ("xSectorUtil")
local SectorSpecifics = include ("sectorspecifics")
local Placer = include("placer")
local ShipUtility = include("shiputility")
local ShipGenerator = include("shipgenerator")
local XSectorGenerator = include("xSectorGenerator")

local SectorTemplate = {}

function SectorTemplate.getProbabilityWeight(x, y, seed, factionIndex, innerArea)
    if factionIndex then
        if innerArea then
            return 50 -- mostly just use colony instead
        else
            return 100
        end
    else
        return 0
    end
end

function SectorTemplate.offgrid(x, y)
    return false
end

function SectorTemplate.gates(x, y)
    return true
end

function SectorTemplate.musicTracks()
    return xDefaultMusicTracks()
end

function SectorTemplate.getDefenders(contents, seed, x, y)
    return contents.faction, contents.defenders
end

-- this function returns what relevant contents there will be in the sector (exact)
function SectorTemplate.contents(x, y)

    --[preamble]----------------------------------------------------------------
    local seed = Seed(string.join({GameSeed(), x, y, "gates"}, "-"))
    math.randomseed(seed)
    local random = random()
    local contents = {seed = tostring(seed),}
    ----------------------------------------------------------------------------
    
    --[faction specifics]-------------------------------------------------------
    local faction, otherFaction
    local isCentral = Galaxy():isCentralFactionArea(x, y)
    if onServer() then
        faction = Galaxy():getLocalFaction(x, y) or Galaxy():getNearestFaction(x, y)
    end
    
    --[special feature]---------------------------------------------------------
    local specs = SectorSpecifics(x, y, GameSeed())
    local planets = {specs:generatePlanets()}
    local hasPlanet = (#planets > 0)
    ----------------------------------------------------------------------------
    
    --[contents]----------------------------------------------------------------
    local contents      = {}
    local stationCounts = {}
    local garrison      = {}
    local events        = {}
    local style = "Gates"
    
    if isCentral then
        style                           = "Core Gates"
        garrison                        = {{variant="garrison", number=random:getInt(3, 4)}}
        
        stationCounts.spacedocks        = random:getInt(0, 1)
        stationCounts.tradingPosts      = random:getInt(0, 2)
        stationCounts.recyclers         = random:getInt(0, 1)
    else
        style                           = "Outer Gates"
        garrison                        = {
            {variant="garrison", number=random:getInt(1, 2)},
            {variant="antipirate", number=random:getInt(0, 1) * random:getInt(2, 5)},
        }
        events                          = {{variant="pirateAttack"}}
        
        stationCounts.defensePlatforms  = random:getInt(0, 2)
        stationCounts.tradingPosts      = random:getInt(0, 1)
        stationCounts.gasCollectors     = random:getInt(1, 4)
    end
    
    if hasPlanet then
        stationCounts.tradingPosts = math.min(1, stationCounts.tradingPosts)
        stationCounts.terrestrialTradingPosts = 1
    end
    
    local stations = xSectorUtil_StationsFromCounts(stationCounts)
    ----------------------------------------------------------------------------
    
    ---[layout]-----------------------------------------------------------------
    
    -- stations in a sparse donut
    local radius = getFloat(1500, 3000)
    local thickness = getFloat(100, 800)
    local depth = getFloat(100, 150)
    local asteroids = getInt(100, 300)
    local mineTraps = 0 --getInt(50, 100) * getInt(0, 1) * getInt(0, 1)
    local mineTrapShapeName = nil
    if mineTraps > 0 then
        mineTrapShapeName = "Outer Minefield Ring"
    end
    contents.x = {
        hasGates=SectorTemplate.gates(x,y),
        events = events,
        style  = style,
        shapes = {
            {
                name      = "Sparse Asteroid Ring",
                variant   = "arc",
                params    = {radius=radius, span=1.0, thickness=thickness, depth=depth},
                offset    = vec3(0, -200, 0),
                ships     = garrison,
                stations  = stations,
                asteroids = {number=asteroids},
            },
            {
                name      = mineTrapShapeName,
                variant   = "arc",
                params    = {radius=radius + math.max(500, thickness + thickness), span=1.0, thickness=50, depth=5},
                offset    = vec3(0, -200, 0),
                mineTraps = mineTraps,
            },
        },
    }
    ----------------------------------------------------------------------------
    
    --[sums]--------------------------------------------------------------------
    xSectorUtil_SetContentCounts(contents)
    return contents, random, faction, otherFaction
end

function SectorTemplate.generate(player, seed, x, y)
    local contents, random, faction, otherFaction = SectorTemplate.contents(x, y)
    XSectorGenerator(x, y, Sector(), faction, SectorTemplate.offgrid(x, y), random):createContents(contents)
    return {defenders = contents.defenders}
end

return SectorTemplate
