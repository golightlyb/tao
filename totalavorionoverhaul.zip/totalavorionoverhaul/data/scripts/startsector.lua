include("xUtil")
local XSectorGenerator = include("xSectorGenerator")

function SectorTemplate.contents(x, y)
    local seed = Seed(string.join({GameSeed(), x, y, "startsector"}, "-"))
    math.randomseed(seed);

    local random = random()
    local contents = {
        seed = tostring(seed),
    }

    if onServer() then
        faction = Galaxy():getLocalFaction(x, y) or Galaxy():getNearestFaction(x, y)
    end
    
    --[special feature]---------------------------------------------------------
    local specs = SectorSpecifics(x, y, GameSeed())
    local planets = {specs:generatePlanets()}
    local hasPlanet = (#planets > 0)
    ----------------------------------------------------------------------------
    
    local terrestrial = nil
    if hasPlanet then terrestrial = {{variant="terrestrial"}} end
    
    -- lets make the start sector a spectacle!!!
    contents.x = {
        style    = "Start Sector",
        hasGates = true,
        features = {
            {
                variant = "shatteredPlanet",
                offset  = vec3(0, -200, -3000),
                shapes = {
                    -- shatteredPlanet rings
                    {
                        variant   = "arc",
                        params    = {radius=700, span=1.0, thickness=200, depth=10, thickenOut=true},
                        asteroids = {number=100, minSize=5, maxSize=15, probability=0.05},
                        ships     = {
                            {variant="miner", number=2},
                        },
                    },
                    {
                        variant   = "arc",
                        params    = {radius=700, span=1.0, thickness=300, depth=20, thickenOut=true},
                        asteroids = {number=200, minSize=5, maxSize=11, probability=0.1},
                    },
                    {
                        variant   = "arc",
                        params    = {radius=700, span=1.0, thickness=400, depth=40, thickenOut=true},
                        asteroids = {number=300, minSize=5, maxSize=9, probability=0.1},
                    },
                    {
                        variant   = "arc",
                        params    = {radius=700, span=1.0, thickness=500, depth=80, thickenOut=true},
                        asteroids = {number=400, minSize=5, maxSize=7, probability=0},
                    },
                    {
                        name      = "Shattered Planet",
                        variant   = "arc",
                        params    = {radius=1200, span=1.0, thickness=200, depth=50, thickenOut=true},
                        stations  = {
                            {variant="mines", number=1},
                            {variant="oreProcessor"},
                        },
                    },
                },
            },
        },
        shapes = {
            -- long sector-sized ring
            {
                variant   = "arc",
                params    = {radius=20000, span=0.1, thickness=800, depth=150},
                offset    = vec3(0, -200, -20000),
                asteroids = {number=1000, probability=0.05},
            },
            {
                name      = "Large Asteroid Ring (inner track)",
                variant   = "arc",
                params    = {radius=19500, span=0.02, thickness=50, depth=50},
                offset    = vec3(0, -200, -20000),
                stations = {
                    {variant="spacedock"},
                    {variant="tradingPost"},
                    {variant="recycler"},
                },
            },
            {
                variant   = "arc",
                params    = {radius=19000, span=0.02, thickness=50, depth=50},
                offset    = vec3(0, -200, -20000),
                stations = terrestrial,
            },
            {
                name      = "Large Asteroid Ring (outer track)",
                variant   = "arc",
                params    = {radius=21000, span=0.05, thickness=50, depth=50},
                offset    = vec3(0, -200, -20000),
                stations = {
                    {variant="defensePlatform", number=6},
                },
                ships = {
                    {variant="garrison", number=3},
                },
            },
        },
    }
    
    -- for quick testing only
    if false then
        contents.x = {
            style    = "Start Sector",
            hasGates = true,
            shapes   = {
                {
                    name      = "Test Location",
                    variant   = "arc",
                    params    = {radius=5000, span=1.0, thickness=50, depth=50},
                    offset    = vec3(0, -200, 6000),
                    asteroids = {number=400, minSize=5, maxSize=15, probability=0.05},
                    stations = {
                        {variant="fortress"},
                        {variant="defensePlatform"},
                        {variant="spacedock"},
                        {variant="mines", number=2},
                    },
                    -- mineTraps = 50,
                    shashes   =  3,
                },
            },
        }
    end
    
    xSectorUtil_SetContentCounts(contents)    
    return contents, random, faction, nil
end


-- player is the player who triggered the creation of the sector (only set in start sector, otherwise nil)
function SectorTemplate.generate(player, seed, x, y)
    local sector = Sector()
    
    local contents, random, faction, otherFaction = SectorTemplate.contents(x, y)
    XSectorGenerator(x, y, sector, faction, false, random):createContents(contents)
    
    sector:removeScript("factionwar/initfactionwar.lua")
    sector:addScript("data/scripts/sector/neutralzone.lua")

    return {defenders = contents.defenders}
end


