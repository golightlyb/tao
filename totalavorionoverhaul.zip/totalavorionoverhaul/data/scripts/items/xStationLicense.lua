package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include("stringutility")
include("galaxy")

function create(item, rarity, factionIndex, hx, hy, x, y)

    item.stackable = true
    item.depleteOnUse = true
    item.icon = "data/textures/icons/station.png"
    item.rarity = rarity
    item:setValue("subtype", "StationLicense")
    item:setValue("factionIndex", factionIndex)

    local price = 0
    
    item.name = "Station Founder's License"%_t
    price = 500000

    item.price = price * Balancing_GetSectorRichnessFactor(hx, hy)

    local tooltip = Tooltip()
    tooltip.icon = item.icon

    local title = item.name

    local headLineSize = 25
    local headLineFontSize = 15
    local line = TooltipLine(headLineSize, headLineFontSize)
    line.ctext = title
    line.ccolor = rarity.tooltipFontColor
    tooltip:addLine(line)

    -- empty line
    tooltip:addLine(TooltipLine(14, 14))

    local line = TooltipLine(18, 14)
    line.ltext = "Faction"%_t
    line.rtext = "${faction:"..factionIndex.."}"
    line.icon = "data/textures/icons/flying-flag.png"
    line.iconColor = ColorRGB(0.8, 0.8, 0.8)
    tooltip:addLine(line)

    

    -- empty line
    tooltip:addLine(TooltipLine(14, 14))

    local line = TooltipLine(20, 15)
    line.ltext = "Depleted on Use"%_t
    line.lcolor = ColorRGB(1.0, 1.0, 0.3)
    tooltip:addLine(line)


    -- empty line
    tooltip:addLine(TooltipLine(14, 14))

    local line = TooltipLine(18, 14)
    line.ltext = "Can be activated by the player to build"%_t
    tooltip:addLine(line)
    line.ltext = "a station in the faction's territory."%_t
    tooltip:addLine(line)


    item:setTooltip(tooltip)

    return item
end

function run(playerIndex, factionIndex)
    local player = Player(playerIndex)
    if not player then return end
    local faction = Faction(factionIndex)
    if not faction then return end
    
    local playerFaction = player
    if playerFaction.isAlliance then playerFaction = Alliance(playerIndex) end
     
    local position = vec3(0, 0, 0)
    if player.craft then
        position = player.craft.translationf
    end
    
    local XSectorGenerator = include("xSectorGenerator")
    local sector = Sector()
    local x, y = sector:getCoordinates()
    local sectorGenerator = XSectorGenerator(x, y, sector, faction, false, random)
    sectorGenerator:createContents({
        x = {
            noSector = true,
            shapes = {
                {
                    variant   = "arc",
                    params = {radius=1, span=1.0, thickness=100, depth=1},
                    offset = player.craft.translationf,
                    stations = {
                        {variant="defensePlatform", faction=player},
                    },
                },
            },
        },
    })
    
end

function activate(item)

    local player = Player()

    local factionIndex = item:getValue("factionIndex")
    if not factionIndex then return false end

    run(player.index, factionIndex)

    return true
end
