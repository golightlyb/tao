
function TorpedoGenerator:getBodyProbability(x, y)
    local distFromCenter = length(vec2(x, y)) / Balancing_GetMaxCoordinates()

    local data = {}

    data[BodyType.XS] =  {          p = 1.0}
    data[BodyType.S] =   {          p = 1.0}
    data[BodyType.M] =   {d = 0.80, p = 2.0}
    data[BodyType.L] =   {d = 0.60, p = 1.0}
    data[BodyType.XL] =  {d = 0.50, p = 1.0}
    data[BodyType.XXL] = {d = 0.40, p = 0.5}

    local probabilities = {}

    for t, specs in pairs(data) do
        if not specs.d or distFromCenter < specs.d then
            probabilities[t] = specs.p
        end
    end

    return probabilities
end

function TorpedoGenerator:getWarheadProbability(x, y)
    local distFromCenter = length(vec2(x, y)) / Balancing_GetMaxCoordinates()

    local data = {}

    data[WarheadType.Nuclear] =    {p = 2.0}
    data[WarheadType.Plasma] =     {p = 2.0}
    data[WarheadType.AntiMatter] = {d = 0.50, p = 1.0}
    data[WarheadType.Conventional] = {p = 4.0}

    local probabilities = {}

    for t, specs in pairs(data) do
        if not specs.d or distFromCenter < specs.d then
            probabilities[t] = specs.p
        end
    end

    return probabilities
end

local function bucket(num) -- group 52 tech levels into buckets of size 5
	return math.floor((num / 5) + 0.5) * 5
end

function TorpedoGenerator:generateAll(x, y, offset_in, rarity_in, warhead_in, body_in) -- server
    local variants = {}
    local warheads = self:getWarheadProbability(x, y)
    local bodies  = self:getBodyProbability(x, y)
    
    for b = 1, TorpedoUtility.BodyTypes do
        local body = TorpedoUtility.BodyTypes - b + 1 -- reverse
        if not bodies[body] then goto continueBody end
        
        for w = 1, TorpedoUtility.WarheadTypes do
            local warhead = TorpedoUtility.WarheadTypes - w + 1 -- reverse
            if not warheads[warhead] then goto continueWarhead end
            
            table.insert(variants, self:generate(x, y, nil, nil, warhead, body))
            
            ::continueWarhead::
        end
        
        ::continueBody::
    end
    return variants
end

function TorpedoGenerator:generate(x, y, offset_in, rarity_in, warhead_in, body_in) -- server

    local offset = offset_in or 0
    local seed = self.random:createSeed()
    local sector = math.floor(length(vec2(x, y))) + offset

    local dps, tech = Balancing_GetSectorWeaponDPS(sector, 0)
    tech = bucket(tech)
    
    dps = dps * Balancing_GetSectorTurretsUnrounded(sector, 0) -- remove turret bias

    local rarity = rarity_in or Rarity(0) -- always this value

    local bodyProbabilities = self:getBodyProbability(sector, 0)
    local body = Bodies[selectByWeight(self.random, bodyProbabilities)]
    if body_in then body = Bodies[body_in] end

    local warheadProbabilities = self:getWarheadProbability(sector, 0)

    local torpedo = TorpedoTemplate()
    torpedo.type = warhead_in or selectByWeight(self.random, warheadProbabilities)
    local warhead = Warheads[torpedo.type]

    -- normal properties
    torpedo.rarity = rarity
    torpedo.tech = tech
    torpedo.size = round(body.size * warhead.size, 2)

    -- body properties
    torpedo.durability = 6 + (tech / 2);
    torpedo.turningSpeed = 0.3 + 0.1 * ((body.agility * 2) - 1)
    torpedo.maxVelocity = 250 + 100 * body.velocity
    torpedo.reach = body.reach * 1000 -- * 10km

    -- warhead properties
    local damage = dps * 5 * math.sqrt(torpedo.size) * math.pow(1.2, rarity.value)

    torpedo.shieldDamage = round(damage * warhead.shield / 100) * 100
    torpedo.hullDamage = round(damage * warhead.hull / 100) * 100
    torpedo.damageType = DamageTypes[torpedo.type].damageType
    torpedo.shieldPenetration = warhead.penetrateShields or false
    torpedo.shieldDeactivation = warhead.deactivateShields or false
    torpedo.shieldAndHullDamage = warhead.shieldAndHullDamage or false
    torpedo.energyDrain = warhead.energyDrain or false
    torpedo.storageEnergyDrain = (warhead.storageEnergyDrain or 0.0) * tech
    torpedo.acceleration = 0.5 * torpedo.maxVelocity * torpedo.maxVelocity / 1000 -- reach max velocity after 10km of travelled way

    if warhead.damageVelocityFactor then
        -- scale to normal dps damage dependent on maxVelocity
        torpedo.damageVelocityFactor = damage * warhead.hull / torpedo.maxVelocity
        torpedo.maxVelocity = torpedo.maxVelocity * 2.0
        torpedo.hullDamage = 0
    end

    -- torpedo visuals
    torpedo.visualSeed = self.random:getInt()
    torpedo.stripes = body.stripes
    torpedo.stripeColor = body.color
    torpedo.headColor = warhead.color
    torpedo.prefix = warhead.name
    torpedo.name = "${warhead} Torpedo ${speed}"%_T
    torpedo.icon = "data/textures/icons/missile-pod.png"
    torpedo.warheadClass = warhead.name
    torpedo.bodyClass = body.name

    -- impact visuals
    torpedo.numShockwaves = 1
    torpedo.shockwaveSize = 10 * torpedo.size * math.sqrt(torpedo.size)
    torpedo.shockwaveDuration = 0.6
    torpedo.shockwaveColor = warhead.color
    -- torpedo.shockwaveColor = ColorRGB(0.1, 0.3, 1.2) -- this looks cool :)
    torpedo.explosionSize = 5 + math.sqrt(torpedo.size)
    torpedo.flashSize = torpedo.size
    torpedo.flashDuration = 1

    return torpedo
end
