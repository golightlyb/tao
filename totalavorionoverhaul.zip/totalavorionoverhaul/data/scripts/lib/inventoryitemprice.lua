
function ArmedObjectPrice(object)
    -- local type = WeaponTypes.getTypeOfItem(object) or WeaponType.XGun

    local dps = object.dps * (1.0 + object.shieldDamageMultiplier) * (1.0 + object.hullDamageMultiplier)
    dps = dps + object.hullRepairRate + object.shieldRepairRate
    -- dps = dps + object.holdingForce / 10000
    
    local r = object.rarity.value + 1 -- 0 to 6
    local m = object.material.value -- 0 to 6
    
    local dpsValue = dps
    if dpsValue > 1000 then
        dpsValue = 1000 + math.sqrt(dpsValue - 1000)
    end
    --            (1000 to ~1500) x (1 to 128) x () x (1 to 128) x (1 to 3.16) gives 1k to 77 million
    local value = (1000 + (dpsValue * 0.5)) * math.pow(4, r/2) * math.pow(2, m) * math.sqrt(object.slots)
    
    if object.seeker then
        value = value * 1.25 -- to 92-odd million
    end
    value = math.min(value, 99999999)
    
    return value
end



function TorpedoPrice(torpedo)

    -- print ("## price calculation for " .. torpedo.rarity.name .. " " .. torpedo.name)
    local value = 0

    -- primary stat: damage value, calculation is very similar to turrets
    local damageValue = (torpedo.hullDamage + torpedo.shieldDamage) * 0.5 -- use the average since usually only either one will be dealt
    damageValue = damageValue + torpedo.maxVelocity * torpedo.damageVelocityFactor * 0.75 -- don't weigh velocity damage as high since it depends on the situation
    if torpedo.shieldAndHullDamage then damageValue = damageValue * 2 end  -- in this case we deal both shield and hull damage -> re-increase price back to 100%

    local reachValue = torpedo.reach * 0.35

    value = value + damageValue * reachValue
    value = value / 15000  -- lower value since you can fire torpedoes only once

    -- penetration, value is two and a half times the normal value because penetration is very strong
    local penetrationValue = 0
    if torpedo.shieldPenetration then penetrationValue = value * 1.5 end
    value = value + penetrationValue

    -- EMP
    local empValue = 0
    if torpedo.shieldDeactivation then empValue = empValue + 15000 end
    if torpedo.energyDrain then empValue = empValue + 15000 end
    value = value + empValue

    -- durability
    local durabilityValue = torpedo.durability * 20
    value = value + durabilityValue

    local speedValue = value * torpedo.maxVelocity / 300 * 0.1
    value = value + speedValue

    -- maneuverability of 1 is median, above makes it more expensive, below makes it cheaper
    local maneuverValue = value * torpedo.turningSpeed * 0.25
    value = value + maneuverValue

    -- check for numerical errors that can occur by changing weapon stats to things like NaN or inf
    value = math.max(0, value)
    if value ~= value then value = 0 end
    if not (value > -math.huge and value < math.huge) then value = 0 end

    if value <= 0 then
        value = 100000
    end

    -- print ("damage + reach: " .. createMonetaryString(damageValue * reachValue * 0.001))
    -- print ("durability: " .. createMonetaryString(durabilityValue))
    -- print ("speed: " .. createMonetaryString(speedValue))
    -- print ("maneuver: " .. createMonetaryString(maneuverValue))
    -- print ("emp: " .. createMonetaryString(empValue))
    -- print ("penetration: " .. createMonetaryString(penetrationValue))
    -- print ("rarity: " .. createMonetaryString(rarityValue))
    -- print ("total: " .. createMonetaryString(value))
    -- print ("## end")

    -- additional rarity scaling to make rarer torpedos more expensive than
    -- an equivalent torpedo of higher tech but lower rarity that does similar
    -- damage.
    local r = torpedo.rarity.value + 1 -- 0 to 6
    value = value * math.pow(1.2, r)
    
    value = round(value / 100) * 100
    
    return value
end