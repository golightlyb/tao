package.path = package.path .. ";data/scripts/?.lua"
TorpedoUtility = include ("lib/torpedoutility")

local order = {
    "conventional",
    "nuclear",
    "plasma",
    "antimatter",
}

return order, {
    -- some entries here duplicate the names and descriptions given in the
    -- torpedoutility files as an optimisation to prevent having to instantiate
    -- each torpedo to get its name.
    conventional = {
        name    = "Conventional",
        desc    = {"A torpedo with a conventional explosive warhead.","Trivially negated by shields."},
        wtype   = TorpedoUtility.WarheadType.Conventional,
        warhead = "XChemicals",
        mintech = 5,
        minsize = 1, -- XS
        maxsize = 2, -- Small
    },
    nuclear = {
        name    = "Nuclear",
        desc    = {"A torpedo with a nuclear warhead.","Balanced effectiveness against any target."},
        wtype   = TorpedoUtility.WarheadType.Nuclear,
        warhead = "XWarhead",
        mintech = 10,
        minsize = 2, -- Small
        maxsize = 4, -- Large
    },
    plasma = {
        name    = "Plasma",
        desc    = {"A torpedo with a plasma warhead.","Extremely effective against shields."},
        wtype   = TorpedoUtility.WarheadType.Plasma,
        warhead = "XWarhead",
        mintech = 15,
        minsize = 2, -- Small
        maxsize = 4, -- Large
    },
    antimatter = {
        name    = "Anti-Matter",
        desc    = {"A torpedo with an advanced anti-matter warhead.","Devestating against an exposed hull, but trivially negated by shields."},
        wtype   = TorpedoUtility.WarheadType.AntiMatter,
        warhead = "XWarhead",
        mintech = 25,
        minsize = 4, -- Large
        maxsize = 6, -- XXL
    },
}
