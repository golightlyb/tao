

function The4.spawn(x, y)
    return
end

function The4.spawnBeacon()
    return
end

function The4.tryPostBulletin(entity)
    return
end
