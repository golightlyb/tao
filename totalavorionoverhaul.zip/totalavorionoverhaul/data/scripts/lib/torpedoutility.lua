TorpedoUtility =  {}

local white = ColorRGB(1.0, 1.0, 1.0)

TorpedoUtility.BodyType =
{
    XS  = 1,
    S   = 2,
    M   = 3,
    L   = 4,
    XL  = 5,
    XXL = 6,
}
TorpedoUtility.BodyTypes = 6
BodyType = TorpedoUtility.BodyType

TorpedoUtility.WarheadType =
{
    Nuclear      = 1,
    Conventional = 2, -- depcrecated
    Plasma       = 3,
    AntiMatter   = 4,
}
TorpedoUtility.WarheadTypes = 4
WarheadType = TorpedoUtility.WarheadType

TorpedoUtility.Bodies = {}

table.insert(TorpedoUtility.Bodies, {type = BodyType.XS,  name = "XS"%_T,  velocity = 5, agility = 6, stripes = 3, size = 1.0, reach = 2, color = white})
table.insert(TorpedoUtility.Bodies, {type = BodyType.S,   name = "S"%_T,   velocity = 4, agility = 5, stripes = 2, size = 2.0, reach = 3, color = white})
table.insert(TorpedoUtility.Bodies, {type = BodyType.M,   name = "M"%_T,   velocity = 3, agility = 4, stripes = 1, size = 4.0, reach = 5, color = white})
table.insert(TorpedoUtility.Bodies, {type = BodyType.L,   name = "L"%_T,   velocity = 2, agility = 3, stripes = 1, size = 8.0, reach = 7, color = white})
table.insert(TorpedoUtility.Bodies, {type = BodyType.XL,  name = "XL"%_T,  velocity = 1, agility = 2, stripes = 2, size =16.0, reach =10, color = white})
table.insert(TorpedoUtility.Bodies, {type = BodyType.XXL, name = "XXL"%_T, velocity = 1, agility = 1, stripes = 3, size =24.0, reach =10, color = white})

TorpedoUtility.Warheads = {}
table.insert(TorpedoUtility.Warheads, {type = WarheadType.Nuclear,      name = "Nuclear"%_T,      hull = 2, shield = 2, size = 1.0, color = ColorRGB(1.0, 0.2, 0.2), shieldAndHullDamage = true})
table.insert(TorpedoUtility.Warheads, {type = WarheadType.Conventional, name = "Conventional"%_T, hull = 1, shield = 0, size = 1.0, color = ColorRGB(1.0, 0.7, 0.0)})
table.insert(TorpedoUtility.Warheads, {type = WarheadType.Plasma,       name = "Plasma"%_T,       hull = 1, shield = 4, size = 1.0, color = ColorRGB(0.2, 1.0, 0.2), shieldAndHullDamage = true})
table.insert(TorpedoUtility.Warheads, {type = WarheadType.AntiMatter,   name = "Anti-Matter"%_T,  hull = 6, shield = 0, size = 1.0, color = ColorRGB(1.0, 0.2, 1.0)})

TorpedoUtility.DamageTypes = {}
table.insert(TorpedoUtility.DamageTypes, {type = WarheadType.Nuclear,      damageType = DamageType.Physical})
table.insert(TorpedoUtility.DamageTypes, {type = WarheadType.Conventional, damageType = DamageType.Physical})
table.insert(TorpedoUtility.DamageTypes, {type = WarheadType.Plasma,       damageType = DamageType.Plasma})
table.insert(TorpedoUtility.DamageTypes, {type = WarheadType.AntiMatter,   damageType = DamageType.AntiMatter})

