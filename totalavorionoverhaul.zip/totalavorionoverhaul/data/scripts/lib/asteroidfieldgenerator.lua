
include "xUtil"

-- custom asteroid field generation. Note that asteroid maxSize is rebalanced
-- compared to createAsteroidFieldEx, which only used 0.4 of the maxSize except
-- for rare larger barren asteroids. We'd rather generate that twice instead.
function AsteroidFieldGenerator:xCreateAsteroidField(points, field)
    
    --[[ example:
    return {
        minSize
        maxSize
        probability (0.0 to 1.0)
    }
    --]]
    
    local sector = Sector()
    -- local points = AsteroidFieldGenerator:xGenerateDisc(disc, position)
    local probabilities = Balancing_GetMaterialProbability(self.coordX, self.coordY)
    for i = 1, #points do
        local resources = math.random() < field.probability
        local size = lerp(math.random(), 0, 1.0, field.minSize, field.maxSize)
        -- local size = xUtilGaussian(field.minSize, field.minSize * 0.1)

        local asteroidPosition = points[i]
        local material = Material(getValueFromDistribution(probabilities))

        local asteroid = nil
        if i % 50 == 0 then -- hiddenTreasure
            self:createHiddenTreasureAsteroid(asteroidPosition, size, material)
        elseif (size > 10) and (not resources) and (i % 3 == 0) then
            local plan = self.planGenerator:makeBigAsteroidPlan(size * math.sqrt(size), resources, material, getInt(3, 10))
            self:xCreateAsteroid(plan, asteroidPosition, resources)
        else
            local plan = self.planGenerator:makeSmallAsteroidPlan(size, resources, material)
            self:xCreateAsteroid(plan, asteroidPosition, resources)
        end
    end
    return mat
end

function AsteroidFieldGenerator:xCreateAsteroid(plan, translation, resources, title)
    plan.accumulatingHealth = false

    local position = MatrixLookUp(vec3(math.random(), math.random(), math.random()), vec3(math.random(), math.random(), math.random()))
    position.pos = translation

    local desc = AsteroidDescriptor()
    desc:setMovePlan(plan)
    desc.position = position
    if not resources then
        desc:removeComponent(ComponentType.MineableMaterial)
    else
        desc.isObviouslyMineable = true
    end

    if title then
        desc:addComponent(ComponentType.Title)
        desc.title = title
    end

    local asteroid = Sector():createEntity(desc)
    return asteroid
end