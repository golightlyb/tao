function WeaponTypes.getRandom(rand)
    return rand:getInt(WeaponType.XMining, WeaponType.XDisruptor)
end


-- Type       | Name           | Damage   | ROF    | burst  | cooldown  | range  | recoil | notes

-- XMining    | Harvesting laser | energy | mining and salvaging turret, no damage to shields
-- XCutting   | Cutting Laser    | energy | very short range mining and salvaging turret, no damage to shields, massive bonus against hulls

-- XGun       | autocannon     | physical | medium | short  | short     | short  | medium | coaxial only, limited max size
-- XCannon    | artillery      | physical | v. low | single | v. long   | long   | high   | explosion, multishot, bonus vs hull
-- XFlak      | flak battery   | physical | low    | long   | long      | medium | high   | explosion, bonus vs hull, scattershot, inaccurate
-- XMissile   | micro-missile  | physical | high   | short  | xx long   | medium | medium | seeking

-- XLaser     | laser turret   | energy   | beam   | medium | medium    | medium | none   | fast tracking
-- XDisruptor | disruptor      | plasma   | high   | short  | xx long   | short  | none   | coaxial only, limited min size, multishot, bonus vs shields
-- XLance     | particle lance | energy   | beam   | medium | xxxx long | long   | none   | coaxial only, size 10 only, high bonus vs shields, weak vs stone

-- physical damage to shields can be reduced by deflector subsystems (-20% energy each)
-- energy damage to shields can be reduced by polariser subsystems (-20% energy each)
-- plasma damage to shields can be reduced by hardening subsystems (-20% energy each)


-- TODO: add laser turret
-- TODO: add Point Defense Laser
-- TODO: add Flak cannon

WeaponTypes.addType("XMining",             "XMining /* Weapon Type */"%_t,                unarmed)
WeaponTypes.addType("XCutting",            "XCutting /* Weapon Type */"%_t,               unarmed)
WeaponTypes.addType("XLance",              "XLance /* Weapon Type */"%_t,                 armed)
WeaponTypes.addType("XGun",                "XGun /* Weapon Type */"%_t,                   armed)
WeaponTypes.addType("XCannon",             "XCannon /* Weapon Type */"%_t,                armed)
WeaponTypes.addType("XMissile",            "XMissile /* Weapon Type */"%_t,               armed)
WeaponTypes.addType("XDisruptor",          "XDisruptor /* Weapon Type */"%_t,             armed)

--WeaponTypes.addType("XLaser",              "XLaser /* Weapon Type */"%_t,                 armed)



--[[
 TODO

* Ion mines

Subsystems:

* Deflector (boost shield resistance against physical attacks, high energy cost)
* Polariser (boost shield resistance against disruptor, high energy cost)
* Reinforced armor refit (boost hull HP but decrease cargo space)
* Low armor refit (boost cargo space & acceleration but decrease hull HP)
* Chaff (manually activated anti-torpedo button with limited uses until recharged)
* Cloaking device (manually activated) ?
* Mine launcher (manually activated)

Torpedo overhaul, plus multibuy many torpedos at once

* Expand the plan cache system to stations for boosted loading speeds
* Remaining weapons and subsystems
* Additional sector types

--]]