package.path = package.path .. ";data/scripts/?.lua"
include ("lib/weapontype")

local order = {
    "mining",
    "cutting",
    
    "gun",
    "cannon",
    "disruptor",
    "missile",
    "lance",
}
return order, {
    -- some entries here duplicate the names and descriptions given in the
    -- turret files as an optimisation to prevent having to instantiate each
    -- turret to get its name.
    mining = {
        name    = "Harvesting Laser",
        desc    = {"A turret-mounted laser with bonus damage against stone.","Trivially negated by shields."},
        wtype   = WeaponType.XMining,
        coaxial = false,
        ingredients = {
            {"XMetal",       1},
            {"XLens",        0.50},
            {"XElectronics", 0.25},
        },
    },
    cutting = {
        name    = "Cutting Laser",
        desc    = {"An extremely short range salvaging laser that can tear through ship hulls", "but requires delicate manouvering. Trivially negated by shields."},
        wtype   = WeaponType.XCutting,
        coaxial = true,
        ingredients = {
            {"XMetal",       1},
            {"XLens",        2},
        },
    },
    gun = {
        name    = "Autocannon",
        desc    = {"A light cannon turret effective against lightly-armored targets.",},
        wtype   = WeaponType.XGun,
        coaxial = false,
        ingredients = {
            {"XMetal",       1},
            {"XElectronics", 0.25},
        },
    },
    cannon = {
        name    = "Artillery Cannon",
        desc    = {"A heavy cannon turret. Slow to fire, but long range and high damage.",},
        wtype   = WeaponType.XCannon,
        coaxial = false,
        ingredients = {
            {"XMetal",       25},
            {"XElectronics",  5},
            {"XLens",         0.25},
        },
    },
    disruptor = {
        name    = "Disruptor",
        desc    = {"Fires short, rapid burts that are highly effective against shields.",},
        wtype   = WeaponType.XDisruptor,
        coaxial = true,
        ingredients = {
            {"XMetalAdvanced", 0.25},
            {"XLens",          1},
        },
    },
    missile = {
        name    = "Micromissile launcher",
        desc    = {"Rapidly fires a burst of homing missiles.",},
        wtype   = WeaponType.XMissile,
        coaxial = true,
        ingredients = {
            {"XMetal",        1},
            {"XElectronics",  0.5},
            {"XLens",         0.25},
        },
    },
    lance = {
        name    = "Particle Lance",
        desc    = {"Fires a focused beam that is devastating against shields.",},
        wtype   = WeaponType.XLance,
        coaxial = true,
        ingredients = {
            {"XSystem",         0.25},
            {"XMetalAdvanced",  2},
            {"XLens",          10},
        },
    },
}
