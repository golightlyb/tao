package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include ("randomext")
include ("xUtil")

-- Shape is any interface for something that can generate random points.

-- namespace Shape
Shape={}
Shape.__index = Shape

local Arc = include("xShapes/arc")

local variants = {
    arc = Arc.newFromParams,
}

function Shape.new(variant, params)
    local v = variants[variant]
    if not v then
        eprint("invalid shape variant "..(variant or "nill"))
        return
    end
    return v(params)
end

return Shape