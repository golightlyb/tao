include("music")

function xUtilGaussian(mean, variance)
    -- from https://rosettacode.org/wiki/Statistics/Normal_distribution#Lua
    return math.sqrt(-2 * variance * math.log(math.random())) * math.cos(2 * math.pi * math.random()) + mean
end

function xUtilRandomMatrixFromCoordinates(position) -- input vec3
    local up = vec3(math.random(), math.random(), math.random())
    local look = vec3(math.random(), math.random(), math.random())
    local mat = MatrixLookUp(look, up)
    mat.pos = position
    return mat
end

function xUtilRandomAxisAlignedMatrixFromCoordinates(position) -- input vec3
    local up = vec3(0, 1, 0)
    local look = vec3(math.random(), 0, math.random())
    local mat = MatrixLookUp(look, up)
    mat.pos = position
    return mat
end

function xDefaultMusicTracks()
    local good = {
        primary = TrackCollection.HappyNeutral(),
        secondary = combine(TrackCollection.Happy(), TrackCollection.Neutral()),
    }

    local neutral = {
        primary = TrackCollection.Neutral(),
        secondary = TrackCollection.All(),
    }

    local bad = {
        primary = combine(TrackCollection.Middle(), TrackCollection.Desolate()),
        secondary = TrackCollection.Neutral(),
    }

    return good, neutral, bad
end

function xPlanCache_FromFile(galaxy, path)
    local ok, plan = galaxy:invokeFunction("xPlanCache.lua", "FromFile", path)
    if ok ~= 0 then
        eprint("xUtil: xPlanCache_FromFile: invokeFunction failed")
        return nil
    end
    return plan
end

function xPlanCache_PrintStats(galaxy)
    local ok, plan = galaxy:invokeFunction("xPlanCache.lua", "PrintStats", path)
    if ok ~= 0 then
        eprint("xUtil: xPlanCache_PrintStats: invokeFunction failed")
        return nil
    end
    return plan
end

function xPlanCache_Generated(galaxy, planType, faction, volume, styleName, material)
    --print("called xPlanCache_Generated("..planType.." "..faction.index.." "..volume.." "..(styleName or "N/A").." "..material.value..")")
    local ok, plan = galaxy:invokeFunction("xPlanCache.lua", "Generated", planType, faction, volume, styleName, material)
    if ok ~= 0 then
        eprint("xUtil: xPlanCache_Generated: invokeFunction failed")
        return nil
    end
    return plan
end

function xPlanCache_GeneratedStation(galaxy, faction, volume, styleName, material)
    return xPlanCache_Generated(galaxy, "Station", faction, volume, styleName, material)
end