

function initialize()
    local station = Entity()
    
    local base = "entity/merchants/XTorpedoBuilder_base.lua"
    station:addScriptOnce(base)
    
    local variant = station:getValue("XTorpedoBuilder_variant")
    if variant then
        local script = "entity/merchants/XTorpedoBuilder_"..variant..".lua"
        station:addScriptOnce(script)
        
        if true then
            local ok, title, minRarity, maxRarity, allowedTypeList, deniedTypeList = station:invokeFunction(script, "restrictArgs")
            if ok ~= 0 then
                print("XTorpedoBuilder: failed to invoke "..script.." restrictArgs: "..ok)
            end
            
            local ok, _ = station:invokeFunction(base, "restrict", title, minRarity, maxRarity, allowedTypeList, deniedTypeList)
            if ok ~= 0 then
                print("XTorpedoBuilder: failed to invoke "..script.." restrict: "..ok)
            end
        end
    end
    
end
