package.path = package.path .. ";data/scripts/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"
include ("randomext")
include ("galaxy")
include ("utility")
include ("stringutility")
include ("faction")
include ("player")
include ("relations")
include ("merchantutility")
include ("callable")
include ("goods")
include ("inventoryitemprice")
local TorpedoUtility = include("torpedoutility")
local TorpedoGenerator = include("torpedogenerator")
local Dialog = include("dialogutility")
local torpedoTableOrder, torpedoTable = include("x_torpedo_table")
local SellableInventoryItem = include ("sellableinventoryitem")
local SellableTorpedo = include ("sellabletorpedo")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XTorpedoBuilder
XTorpedoBuilder = {}
XTorpedoBuilder.interactionThreshold = 10000

local allowedTypes = nil -- set of ids, if nil, ignored
local deniedTypes  = nil -- set of ids, if nil ignored
local mainTitle    = "Assemble Torpedos  /* Window and Interaction Title*/"%_t

local minSelectedRarity = -1 -- petty
local maxSelectedRarity =  5 -- legendary
local minSelectedSize   =  TorpedoUtility.BodyType.XS
local maxSelectedSize   =  TorpedoUtility.BodyType.XXL

function XTorpedoBuilder.restrict(title, minRarity, maxRarity)
    if title then
        mainTitle = title
    end
    minSelectedRarity = (minRarity or -1)
    maxSelectedRarity = (maxRarity or 5) -- legendary
    
    if onServer() then
        invokeClientFunction(Player(callingPlayer), "restrict", title, variantHelpText, minRarity, maxRarity, allowedTypeList, deniedTypeList)
    end
end
callable(XTorpedoBuilder, "restrict")

function XTorpedoBuilder.interactionPossible(playerIndex, option)
    return CheckFactionInteraction(playerIndex, XTorpedoBuilder.interactionThreshold)
end

local techLevel = 0
local techMark = ""

local function bucket(num) -- group 52 tech levels into buckets of size 5
	return math.floor((num / 5) + 0.5) * 5
end

local function bucketToMark(num) -- group 52 tech levels into buckets of size 5
	return math.floor((num / 5) + 0.5)
end

function XTorpedoBuilder.initialize()
    local station = Entity()

    if station.title == "" then
        station.title = "Torpedo Assembler"%_t
    end
    
    local x, y = Sector():getCoordinates()
    local tech = Balancing_GetTechLevel(x, y)
    techLevel = bucket(tech)
    techMark  = toRomanLiterals(bucketToMark(tech))
end

local mainWindow

function XTorpedoBuilder._visitTorpedoTable(visit)
    for i = 1, #torpedoTableOrder do
        local id = torpedoTableOrder[i]
        local torpedo = torpedoTable[id]
        if torpedo and (not torpedo.hidden) then
            -- if torpedo.mintech <= techLevel then
                visit(id, torpedo)
            -- end
        end
    end
end

function XTorpedoBuilder.initUI()
    local res = getResolution()
    local size = vec2(800, 480)
    
    local menu = ScriptUI()
    window = menu:createWindow(Rect(res * 0.5 - size * 0.5, res * 0.5 + size * 0.5))
    menu:registerWindow(window, mainTitle, 11)
    mainWindow = window -- handle used for centering items
    
    local station = Entity()
    window.caption = mainTitle
    window.showCloseButton = 1
    window.moveable = 1
    
    -- create a padded inner window
    local window = window:createTabbedWindow(Rect(vec2(10, 10), size - 10))
    
    local tab = window:createTab("Assemble"%_t, "data/textures/icons/missile-pod.png", "Assemble and buy new torpedos"%_t)
    XTorpedoBuilder.buildAssembleTab(tab)
end

local playerStock = {} -- k,v in pairs {good id, quantity}
local playerShafts = {}-- mapping of id : number of auto-loading shafts
local playerStored = {} -- mapping of id : volume of number stored
local playerFreeSlots = {} -- mapping of id : number of free auto-loading shaft slots
local playerStorage = 0 -- volume, not number of torpedos
local playerTotalStorage = 0
local playerTotalShafts = 0
local maxIngredientTypesPerTorpedo = 1

local assemble = {}

function XTorpedoBuilder._doNothing()
end

function XTorpedoBuilder.buildAssembleTab(window)
    assemble.previousSelectedType = nil
    assemble.selectedRarity = -1
    assemble.selectedSize   =  1
    assemble.autoBuyNumber  =  0
    
    ---[System Info]------------------------------------------------------------
    local x = 10
    local y = 15
    assemble.comboboxTorpedoType = window:createValueComboBox(Rect(x, y, x+190, y+20), "_assemble_comboboxTorpedoType_update")
    XTorpedoBuilder._visitTorpedoTable(function(id, torpedo)
        assemble.comboboxTorpedoType:addEntry(id, torpedo.name, ColorRGB(1.0, 1.0, 1.0))
    end)
    
    y = y + 35
    assemble.borderPreview  = window:createRect            (Rect(x,   y,   x+190, y+190), ColorRGB(1.0, 1.0, 1.0))
    assemble.picturePreview = window:createPicture         (Rect(x+4, y+4, x+186, y+186), "data/textures/icons/minus.png")
    assemble.tooltipPreview = window:createTooltipDisplayer(Rect(x,   y,   x+190, y+190))

    y = y + 205
    local button = window:createButton(Rect(x, y, x+60, y+30), "-", "_assemble_decreaseRarity")
    button.icon = "data/textures/icons/minus.png"
    local button = window:createButton(Rect(x+130, y, x+190, y+30), "+", "_assemble_increaseRarity")
    button.icon = "data/textures/icons/plus.png"
    
    assemble.labelRarity = window:createLabel(vec2(0, y+10), "RARITY", 8)
    assemble.labelRarity.font = FontType.SciFi
    
    y = y + 40
    local button = window:createButton(Rect(x, y, x+60, y+30), "-", "_assemble_decreaseSize")
    button.icon = "data/textures/icons/minus.png"
    local button = window:createButton(Rect(x+130, y, x+190, y+30), "+", "_assemble_increaseSize")
    button.icon = "data/textures/icons/plus.png"

    assemble.labelSize = window:createLabel(vec2(0, y+10), "SIZE", 12)
    assemble.labelSize.font = FontType.SciFi
    
    ---[Dividers]---------------------------------------------------------------
    window:createLine(vec2(220,  10), vec2(220, 340))
    window:createLine(vec2(10,  340), vec2(770, 340))
    window:createLine(vec2(495, 250), vec2(495, 320))
    
    ---[Ingredients]------------------------------------------------------------
    local x = 240
    -- local y = 35
    
    local nameX       = x + 10
    local requiredX   = x + 290
    local stockX      = x + 420
    
    local y = 10
    window:createLabel(vec2(nameX,     y), "Cost"%_T, 20)
    
    local y = 50
    window:createLabel(vec2(nameX,     y), "Ingredient"%_T,     15)
    window:createLabel(vec2(requiredX, y), "Required"%_T,       15)
    window:createLabel(vec2(stockX,    y), "You Have"%_T,       15)
    
    assemble.ingredientFrames         = {}
    assemble.ingredientNameLabels     = {}
    assemble.ingredientRequiredLabels = {}
    assemble.ingredientStockLabels    = {}
    
    y = y + 25
    for i = 1, maxIngredientTypesPerTorpedo + 1 do -- +1 line for cash
        local yText = y + 6

        local frame         = window:createFrame(Rect(x, y, 770, 30 + y))
        local nameLabel     = window:createLabel(vec2(nameX,     yText), "", 15)
        local requiredLabel = window:createLabel(vec2(requiredX, yText), "", 15)
        local stockLabel    = window:createLabel(vec2(stockX,    yText), "", 15)

        table.insert(assemble.ingredientFrames,         frame)
        table.insert(assemble.ingredientNameLabels,     nameLabel)
        table.insert(assemble.ingredientRequiredLabels, requiredLabel)
        table.insert(assemble.ingredientStockLabels,    stockLabel)

        y = y + 35
    end    
    
    ---[Bottom bar, left]-------------------------------------------------------
    local y = 360
    assemble.labelBuy = window:createLabel(Rect(10, y, 200, y+20), "Frobbulator Weapon", 15)
    assemble.labelBuy.color = ColorRGB(0.5, 0.5, 0.5)
    
    y = y + 20
    local label = window:createLabel(Rect(10, y, 200, y+20), "Tech level "..techLevel.. " (MK "..techMark..")", 15)
    
    y = 160
    y = 200
    window:createLabel(Rect(240, y, 515, y+20), "Purchase", 20)
    
    y = 260
    window:createLabel(vec2(240, y), "Number:", 15)
    assemble.inputBuyNumber = window:createTextBox(Rect(340, y-5, 475, y+30), "_doNothing")
    assemble.inputBuyNumber.text = "1"
    assemble.inputBuyNumber.allowedCharacters = "0123456789"
    assemble.inputBuyNumber.clearOnClick = 1
    
    y = 260
    assemble.autoBuyLabel = window:createLabel(Rect(515, y, 760, y+20), "X of Y matching tubes.", 15)
    
    y = 300
    assemble.buttonBuy     = window:createButton(Rect(240, y, 475, y+20), "Purchase", "_assemble_buy")
    assemble.buttonBuyAuto = window:createButton(Rect(515, y, 760, y+20), "Auto Purchase", "_assemble_buy_auto")
    assemble.buttonBuyAuto.tooltip = "Will attempt to buy the configured torpedo until the volume of torpedos in your inventory of that type is in proportion to the number of shafts configured to automatically load that torpedo type."%_T.."\n\n"..
        "For example, if you have four shafts and one shaft is configured to load Plasma torpedos and has two slots free,"%_T .. " " ..
        "then Auto Purchase (with a Plasma torpedo selected) will attempt to fill 25% of your torpedo storage with plasma torpedos, plus two to fill the shaft."%_T
    
    
    ---[Bottom bar, right]------------------------------------------------------
    x = 240
    y = 335
    
    y = y + 25
    assemble.infoLabel1 = window:createLabel(Rect(x, y, 770, y+20), "Description", 15)
    y = y + 20
    assemble.infoLabel2 = window:createLabel(Rect(x, y, 770, y+20), "Description", 15)
end

local function possibleIngredient(goodId)
    local possible = {
        XChemicals     = true,
        XWarhead       = true,
    }
    return possible[goodId] or false
end

function XTorpedoBuilder.onShowWindow()
    XTorpedoBuilder.forceRefresh()
end

function XTorpedoBuilder._assemble_comboboxTorpedoType_update()
    local selectedType = assemble.comboboxTorpedoType.selectedValue
    
    assemble.selectedRarity = 0
    assemble.selectedSize = torpedoTable[selectedType].minsize
    XTorpedoBuilder.refresh()
end

function XTorpedoBuilder._assemble_decreaseRarity()
    assemble.selectedRarity = math.max(minSelectedRarity, assemble.selectedRarity - 1)
    XTorpedoBuilder.forceRefresh()
end

function XTorpedoBuilder._assemble_increaseRarity()
    assemble.selectedRarity = math.min(maxSelectedRarity, assemble.selectedRarity + 1)
    XTorpedoBuilder.forceRefresh()
end

function XTorpedoBuilder._assemble_decreaseSize()
    local selectedType = assemble.comboboxTorpedoType.selectedValue
    local _min = math.max(minSelectedSize, torpedoTable[selectedType].minsize)
    assemble.selectedSize = math.max(_min, assemble.selectedSize - 1)
    XTorpedoBuilder.forceRefresh()
end

function XTorpedoBuilder._assemble_increaseSize()
    local selectedType = assemble.comboboxTorpedoType.selectedValue
    local _max = math.min(maxSelectedSize, torpedoTable[selectedType].maxsize)
    assemble.selectedSize = math.min(_max, assemble.selectedSize + 1)
    XTorpedoBuilder.forceRefresh()
end

function XTorpedoBuilder.forceRefresh()
    assemble.previousSelectedType = nil
    XTorpedoBuilder.refresh()
end
callable(XTorpedoBuilder, "forceRefresh")

function XTorpedoBuilder.forceAsyncRefresh()
    -- display doesn't always update after server sends the new item
    -- so try again after a few tenths of a second
    XTorpedoBuilder.forceRefresh()
    deferredCallback(0.2, "forceRefresh")
end
callable(XTorpedoBuilder, "forceAsyncRefresh")

local function readPlayerCargo(player)
    for k, _ in pairs(playerStock) do
        playerStock[k] = 0
    end
    
    local player = player or Player()
    if not player then end
    
    local craft = player.craft
    if not craft then return end
    
    local cargoBay = CargoBay(craft)
    if not cargoBay then return end
    
    local cargo = cargoBay:getCargos()
    if not cargo then return end
    
    for good, quantity in pairs(cargo) do
        if good.stolen then goto continue end
        local id = GetGoodID(good.name)
        if not possibleIngredient(id) then goto continue end
        playerStock[id] = quantity
        ::continue::
    end
    
    playerStock["cash"] = (player.money or 0)
end

local function readPlayerTorpedos(player)
    for k, _ in pairs(playerShafts) do
        playerShafts[k] = 0
    end
    for k, _ in pairs(playerFreeSlots) do
        playerFreeSlots[k] = 0
    end
    for k, _ in pairs(playerStored) do
        playerStored[k] = 0
    end
    playerTotalShafts = 0
    playerStorage = 0

    local player = player or Player()
    if not player then return end
    
    local craft = player.craft or none
    if not craft then return end
    
    local launcher = TorpedoLauncher(craft)
    
    local db = ShipDatabaseEntry(player.index, craft.name)
    if not db then return end
    
    local shafts = db:getTorpedoes()
    if not shafts then return end
    
    playerStorage = shafts[-1].freeSpace
    playerTotalStorage = shafts[-1].space
    
    -- have to do it this way round
    if launcher then
        local i = 0
        while true do
            local t = launcher:getTorpedo(i, -1)
            if not t then break end
            playerStored[t.type] = (playerStored[t.type] or 0) + t.size
            i = i + 1
        end
    end
    
    for i = 0, 9 do
        local shaft=shafts[i]
        if not shaft then goto continue end
        if not shaft.enabled then goto continue end
        if shaft.automaticLoadingType > 0 then
            local t = shaft.automaticLoadingType
            playerShafts[t] = (playerShafts[t] or 0) + 1
            playerFreeSlots[t] = (playerFreeSlots[t] or 0) + shaft.freeSpace
        end
        playerTotalShafts = playerTotalShafts + 1
        
        ::continue::
    end
    
    --for i = 0, shafts do
        --local shaft = TorpedoShaft(i)
        --local maxTorpedos = launcher:getMaxTorpedoes(i)
        --local freeSlots = launcher:getFreeSlots(i)
        --print("%d: %d, %d", i, maxTorpedos, freeSlots)
    --end
    
    -- note, shaft minus one is unlaoded torpedo storage
end

local function readPlayer(player)
    local player = player or Player()
    readPlayerCargo(player)
    readPlayerTorpedos(player)
end

function XTorpedoBuilder.refresh()
    XTorpedoBuilder._assemble_refresh()
end

function XTorpedoBuilder._assemble_refresh()
    local selectedType = assemble.comboboxTorpedoType.selectedValue
    local selectedRarity = assemble.selectedRarity
    
    if (selectedType ~= assemble.previousSelectedType) and selectedType then
        local player = Player()
        readPlayer(player)
        
        ---[update labels and preview]------------------------------------------
        assemble.labelBuy.caption = torpedoTable[selectedType].name .. " " .. TorpedoUtility.Bodies[assemble.selectedSize].name
        assemble.labelBuy.color = Rarity(selectedRarity).color
        
        -- relative to 120, 325 (including 10 for window padding)
        assemble.labelRarity.caption = Rarity(selectedRarity).name
        local width = assemble.labelRarity.textWidth
        assemble.labelRarity.position = vec2(mainWindow.position.x + 115 - (width/2), assemble.labelRarity.position.y)

        assemble.labelSize.caption = TorpedoUtility.Bodies[assemble.selectedSize].name
        local width = assemble.labelSize.textWidth
        assemble.labelSize.position = vec2(mainWindow.position.x + 115 - (width/2), assemble.labelSize.position.y)
        
        assemble.previousSelectedType = selectedType
        
        assemble.currentPreview = XTorpedoBuilder._assemble_item(selectedType, selectedRarity, assemble.selectedSize)
        local tooltip = makeTorpedoTooltip(assemble.currentPreview, nil, 2)
        
        assemble.picturePreview:fadeTo(assemble.currentPreview.icon, 0)
        assemble.tooltipPreview:setTooltip(tooltip)
        assemble.borderPreview.color = Rarity(selectedRarity).color
        
        ---[update ingredients]------------------------------------------------
        for i = 1, maxIngredientTypesPerTorpedo + 1 do
            assemble.ingredientFrames[i].tooltip         = nil
            assemble.ingredientNameLabels[i].caption     = ""
            assemble.ingredientRequiredLabels[i].caption = ""
            assemble.ingredientStockLabels[i].caption    = ""
        end
        
        local offset = 1
        if selectedRarity >= 0 then
            local ingredient = torpedoTable[selectedType].warhead
            local good = goods[ingredient]
                
            assemble.ingredientFrames[1].tooltip         = "[TRADING GOOD]\n\n" .. good.description .. "\n\n".."Typically "..createMonetaryString(good.price).." Cr. each"
            assemble.ingredientNameLabels[1].caption     = good.name
            assemble.ingredientRequiredLabels[1].caption = 1
            assemble.ingredientStockLabels[1].caption    = (playerStock[ingredient] or 0)

            offset = offset + 1
        end
        
        local price = TorpedoPrice(assemble.currentPreview)
        assemble.ingredientNameLabels[offset].caption     = "Cash"
        assemble.ingredientRequiredLabels[offset].caption = createMonetaryString(price).." Cr." -- TODO
        assemble.ingredientStockLabels[offset].caption    = createMonetaryString(playerStock["cash"] or 0) .. " Cr."
        offset = offset + 1
        
        local matching = playerShafts[torpedoTable[selectedType].wtype] or 0
        local total = playerTotalShafts
        local proportion = 0
        if total > 0 then proportion = (100.0 * matching / total) end
        local freeSlots = playerFreeSlots[torpedoTable[selectedType].wtype] or 0
        local size = assemble.currentPreview.size
        local stored = playerStored[torpedoTable[selectedType].wtype] or 0
        
        local number = 0
        --if total > 0 then number = math.floor(math.min((playerTotalStorage / size) * (matching / total), playerStorage)) end
        --number = math.max(0, number - stored)
        if total > 0 then
            -- already stored `stored` volume
            -- want to store up to (playerTotalStorage / size) * (matching / total)
            local volumeToStore = math.floor(playerTotalStorage * matching / total) - stored
            if volumeToStore > 0 then
                number = math.floor(volumeToStore / size)
            end
        end
        
        number =  number + freeSlots
        assemble.autoBuyNumber = number
        assemble.autoBuyLabel.caption = "Number: "..number.." ("..math.floor(proportion).."% of shafts)."
        
        ---- buy button
        local caption = torpedoTable[selectedType].desc
        assemble.infoLabel1.caption = caption[1] or ""
        assemble.infoLabel2.caption = caption[2] or ""
    end
    
    -- local s = 
    -- local upgrade 
    -- player:getInventory():add(upgrade, true)
end
callable(XTorpedoBuilder, "refresh")

function XTorpedoBuilder._assemble_item(id, rarity, size)
    local x, y = Sector():getCoordinates()
    local generator = TorpedoGenerator()
    if not generator then
        print("nil sector torpedo generator")
    end
    local material = bestMaterial
    local item = generator:generate(x, y, 0, Rarity(rarity), torpedoTable[id].wtype, size)
    if not item then print("torpedo generation error") end
    return item
end

function XTorpedoBuilder._assemble_checkCanPurchase(id, rarity, size, number)
    -- returns ok, reasonIfNotOk, [moneyToTake, stockToTake, volume]
    -- money and stock is PER TORPEDO
    
    local item = XTorpedoBuilder._assemble_item(id, rarity, size)
    
    local moneyToTake = TorpedoPrice(item)
    local stockToTake = nil
    local volume = item.size
    
    --- check ingredients ------------------------------------------------------
    if rarity >= 0 then
        local ingredient = torpedoTable[id].warhead
        local good = goods[ingredient]
        local have = (playerStock[ingredient] or 0)
        local quantity = 1
        if have < 1 then
            return false, "Missing ingredients (need at least "..quantity.." "..good.name..")"
        end
        stockToTake = ingredient
    end
    
    --- check cash -------------------------------------------------------------
    local cash = playerStock["cash"] or 0
    if (cash < moneyToTake) and not Scenario().isCreative then
        return false, "Not enough money (need at least "..moneyToTake..")"%_t
    end
    
    return true, "", moneyToTake, stockToTake, volume
end

function XTorpedoBuilder._assemble_buy()
    local player = Player()
    local id     = assemble.comboboxTorpedoType.selectedValue
    local rarity = assemble.selectedRarity
    local size   = assemble.selectedSize
    local number = tonumber(assemble.inputBuyNumber.text)
    if number == 0 then goto continue end
    local maxNumber = math.floor(playerStorage / size)
    if number > maxNumber then
        number = math.min(number, maxNumber)
        player:sendChatMessage("Note: inventory can only fit "..number.. " of these torpedos.", 1)
    end
    
    readPlayer(player)
    local ok, reason, _, _ = XTorpedoBuilder._assemble_checkCanPurchase(id, rarity, size, number)
    if not ok then
        player:sendChatMessage(reason, 1)
        goto continue
    end
    
    if number > 0 then
        invokeServerFunction("_assemble_complete", id, rarity, size, number)
    end
    ::continue::
end

function XTorpedoBuilder._assemble_buy_auto()
    local player = Player()
    local id     = assemble.comboboxTorpedoType.selectedValue
    local rarity = assemble.selectedRarity
    local size   = assemble.selectedSize
    local number = assemble.autoBuyNumber
    if number == 0 then goto continue end
    
    readPlayer(player)
    local ok, reason, _, _ = XTorpedoBuilder._assemble_checkCanPurchase(id, rarity, size, number)
    if not ok then
        player:sendChatMessage(reason, 1)
        goto continue
    end
    
    if number > 0 then
        invokeServerFunction("_assemble_complete", id, rarity, size, number)
    end
    ::continue::
end

function XTorpedoBuilder._assemble_complete(id, rarity, size, number)
    local player = Player(callingPlayer)
    local ship   = player.craft
    ---[item]--
    local item = XTorpedoBuilder._assemble_item(id, rarity, size)
    
    ---[checks]-----------------------------------------------------------------
    readPlayer(player)
    local ok, reason, moneyToTake, stockToTake, volume = XTorpedoBuilder._assemble_checkCanPurchase(id, rarity, size, number)
    if not ok then
        player:sendChatMessage(mainTitle, 1, reason)
        return
    end
    
    local errors = {}
    errors[EntityType.Station] = "You must be docked to the station to trade."%_T
    errors[EntityType.Ship] = "You must be closer to the ship to trade."%_T
    if (not ship) or (not CheckShipDocked(player, ship, Entity(), errors)) then
        return
    end
    
    -- we can assume the neccessary cargo, inventories etc. have been checked
    -- at this point for the purposes of paying, but the player does need to be
    -- able to recieve the item and we check that before paying...
    local craft = player.craft
    if not craft then return end
    
    local launcher = TorpedoLauncher(craft)
    if not launcher then
        player:sendChatMessage(mainTitle, 1, "you need a torpedo launcher"%_T)
        return
    end
    
    print("STORAGE: "..playerStorage)
    local bought = 0
    local reason = ""
    local notEnoughSpace = "(not enough space to automatically install any more torpedos in a single purchase)"
    while number > 0 do
        local toBuy = math.ceil(number / 2)
        local toBuy = math.min(math.floor(playerStorage / volume), toBuy)
        if toBuy < 1 then
            reason = notEnoughSpace
            break
        end
        local toPay = moneyToTake * toBuy
        number = number - toBuy
        playerStorage = playerStorage - volume * toBuy
    
        local canPay, _, _ = player:canPayMoney(toPay)
        if not canPay then
            reason = "(not enough money to buy any more)"
            break
        end
        
        ---[pay cargo]--------------------------------------------------------------
        local cargoBay = CargoBay(craft)
        if (not cargoBay) and (not stockToTake) then return end
        
        if stockToTake then
            if (playerStock[stockToTake] >= toBuy) then
                playerStock[stockToTake] = playerStock[stockToTake] - toBuy
                cargoBay:removeCargo(tableToGood(goods[stockToTake]), 1 * toBuy)
            else
                reason = "(not enough ingredients to buy any more)"
                break
            end
        end
        
        ---[pay money]--------------------------------------------------------------
        if toPay > 0 then player:pay("Paid %1% credits", toPay) end
            
        ---[send to inventory]------------------------------------------------------
        for i = 1, toBuy do
            launcher:addTorpedo(item)
        end
        bought = bought + toBuy
        
        ::continue::
    end
        
    player:sendChatMessage(mainTitle, 0, bought .. " torpedos recieved!"%_T .. " "..reason)
    if reason == notEnoughSpace then
        player:sendChatMessage(mainTitle, 0, "(You can repeat auto-installation again to continue loading torpedos)")
    end
    invokeClientFunction(player, "forceAsyncRefresh")
end
callable(XTorpedoBuilder, "_assemble_complete")

