package.path = package.path .. ";data/scripts/lib/?.lua"
include ("utility")
include ("randomext")
include ("faction")
include ("goods")
include ("productions")
local ConsumerGoods = include ("consumergoods")
local Dialog = include("dialogutility")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XMiningColony
XMiningColony = {}

-- The Terestrial trader is just a factory with a trader appearance and
-- consumer goods, but should only appear when there's a background planet.

function XMiningColony.interactionPossible(playerIndex, option)
    return CheckFactionInteraction(playerIndex, 10000)
end

function XMiningColony.initialize()
    local station = Entity()
    if station.title == "" then
        station.title = "Mining Colony"%_t
    end

    if onServer() then
        local production = productions[productionIndexMiningColony]
        station:addScriptOnce("data/scripts/entity/merchants/consumer.lua", "Mining Colony"%_t, unpack(ConsumerGoods.XMiningColony()))
        station:addScriptOnce("data/scripts/entity/merchants/factory.lua", production, nil, 0)
        
        -- local goods = {"XPassenger", "XPassengerLuxury"}
        -- station:addScriptOnce("data/scripts/entity/merchants/tradingpost.lua", goods, goods)
    end
    
    -- XRefinery.shop:initialize(station.translatedTitle)

    if onClient() then -- always override
        EntityIcon().icon = "data/textures/icons/pixel/mine.png"
        InteractionText(station.index).text = Dialog.generateStationInteractionText(station, random())
    end
end

