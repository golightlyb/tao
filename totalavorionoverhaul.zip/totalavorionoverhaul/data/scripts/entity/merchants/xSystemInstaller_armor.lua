package.path = package.path .. ";data/scripts/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"

include ("callable")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XSystemInstallerArmor
XSystemInstallerArmor = {}

function XSystemInstallerArmor.initialize()
end

function XSystemInstallerArmor.restrictArgs()
    -- for some reason couldn't get translations to work here

    local station = Entity()
    local title = "Armor Installer"
    local variantHelpText = {
        "This station can install Armor upgrades up to Legendary.",
        "For general system upgrades, find a SpaceDock or a Systems Factory."
    }
    return title, variantHelpText, -1, 5, {"armor"}, nil
end
callable(XSystemInstallerArmor, "restrictArgs")
