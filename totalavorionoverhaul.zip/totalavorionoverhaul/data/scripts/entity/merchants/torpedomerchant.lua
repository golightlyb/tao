-- if this function returns false, the script will not be listed in the interaction window on the client,
-- even though its UI may be registered
function TorpedoMerchant.interactionPossible(playerIndex, option)
    return CheckFactionInteraction(playerIndex, TorpedoMerchant.interactionThreshold)
end

function TorpedoMerchant.shop:addItems()

    local station = Entity()

    if station.title == "" then
        station.title = "Torpedo Merchant"%_t
    end

    -- create all torpedoes
    local allTorpedoes = {}
    local generator = TorpedoGenerator()
    local variants = generator:generateAll(Sector():getCoordinates())

    for _, pair in pairs(variants) do
        TorpedoMerchant.shop:add(pair, getInt(1, math.ceil(100 / pair.size)))
    end
end

-- sets the special offer that gets updated every 20 minutes
function TorpedoMerchant.shop:onSpecialOfferSeedChanged()
    local generator = TorpedoGenerator(TorpedoMerchant.shop:generateSeed())
    local specialTorpedo = generator:generate(Sector():getCoordinates())
    local amount = getInt(5, 25)

    TorpedoMerchant.shop:setSpecialOffer(specialTorpedo, amount)
end

function TorpedoMerchant.initialize()
    TorpedoMerchant.shop:initialize("Torpedo Merchant"%_t)

    if onClient() and EntityIcon().icon == "" then
        EntityIcon().icon = "data/textures/icons/pixel/trade.png" -- TODO @Philipp
    end
end

function TorpedoMerchant.initUI()
    TorpedoMerchant.shop:initUI("Trade Equipment"%_t, "Torpedo Merchant"%_t, "Torpedoes"%_t, "data/textures/icons/bag-missile-pod.png")
end

TorpedoMerchant.shop.ItemWrapper = SellableTorpedo
TorpedoMerchant.shop.SortFunction = comp
