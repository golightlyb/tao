

function initialize()
    local station = Entity()
    
    local base = "data/scripts/entity/merchants/XTurretBuilder_base.lua"
    station:addScriptOnce(base)
    
    local variant = station:getValue("XTurretBuilder_variant")
    if variant then
        local script = "data/scripts/entity/merchants/XTurretBuilder_"..variant..".lua"
        station:addScriptOnce(script)
        
        if true then
            local ok, title, minRarity, maxRarity, allowedTypeList, deniedTypeList = station:invokeFunction(script, "restrictArgs")
            if ok ~= 0 then
                print("XTurretBuilder: failed to invoke "..script.." restrictArgs: "..ok)
            end
            
            local ok, _ = station:invokeFunction(base, "restrict", title, minRarity, maxRarity, allowedTypeList, deniedTypeList)
            if ok ~= 0 then
                print("XTurretBuilder: failed to invoke "..script.." restrict: "..ok)
            end
        end
    end
    
end
