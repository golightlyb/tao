-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XResourceTraderOre
XResourceTraderOre = {}

function XResourceTraderOre.initialize()
    local station = Entity()
    station:invokeFunction("data/scripts/entity/merchants/resourcetrader.lua", "setCanDepositOre")
end

