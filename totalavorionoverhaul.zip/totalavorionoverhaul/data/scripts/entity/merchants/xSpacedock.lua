package.path = package.path .. ";data/scripts/lib/?.lua"
include ("utility")
include ("randomext")
include ("faction")
local ConsumerGoods = include ("consumergoods")
local Dialog = include("dialogutility")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace Spacedock
Spacedock = {}
-- Spacedock = ShopAPI.CreateNamespace()

-- The Spacedock is a combined Equipment Dock, repair dock, and (TODO)
-- ship founder (with a simpler UI).

-- if this function returns false, the script will not be listed in the interaction window,
-- even though its UI may be registered
function Spacedock.interactionPossible(playerIndex, option)
    return CheckFactionInteraction(playerIndex, -10000)
end

function Spacedock.initialize()
    local station = Entity()
    if station.title == "" then
        station.title = "Spacedock"%_t
    end

    if onServer() then
        Sector():registerCallback("onPlayerArrivalConfirmed", "onPlayerArrivalConfirmed")

        station:addScriptOnce("data/scripts/entity/merchants/utilitymerchant.lua")
        --station:addScriptOnce("data/scripts/entity/merchants/turretmerchant.lua")
        station:addScriptOnce("data/scripts/entity/merchants/torpedomerchant.lua")
        station:addScriptOnce("data/scripts/entity/merchants/xSystemInstaller.lua")
        station:addScriptOnce("data/scripts/entity/merchants/xTurretBuilder.lua")
        station:addScriptOnce("data/scripts/entity/merchants/consumer.lua", "Spacedock"%_t, unpack(ConsumerGoods.XSpacedock()))
        station:addScriptOnce("data/scripts/entity/merchants/repairdock.lua")
        station:addScriptOnce("data/scripts/entity/merchants/customs.lua")
        station:addScriptOnce("data/scripts/entity/merchants/resourcetrader.lua")
        station:addScriptOnce("data/scripts/entity/merchants/buildingknowledgemerchant.lua")
    end

    if onClient() and EntityIcon().icon == "" then
        EntityIcon().icon = "data/textures/icons/pixel/shipyard2.png"
        InteractionText(station.index).text = Dialog.generateStationInteractionText(station, random())
    end
    
    station:setValue("remove_permanent_upgrades", true)
    station:setValue("build_advanced_blocks", true)
end

function Spacedock.initUI()
    local station = Entity()
    -- Spacedock.shop:initUI("Trade Equipment"%_t, station.translatedTitle, "Subsystems"%_t, "data/textures/icons/bag_circuitry.png")
end

function Spacedock.onPlayerArrivalConfirmed(playerIndex)
    Player(playerIndex):sendChatMessage("", ChatMessageType.Information, "There's a spacedock in this sector."%_T)
end

