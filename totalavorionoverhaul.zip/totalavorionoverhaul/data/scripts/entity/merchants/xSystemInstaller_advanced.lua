package.path = package.path .. ";data/scripts/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"

include ("callable")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XSystemInstallerAdvanced
XSystemInstallerAdvanced = {}

function XSystemInstallerAdvanced.initialize()
end

function XSystemInstallerAdvanced.restrictArgs()
-- for some reason couldn't get translations to work here   

    local station = Entity()
    local title = "Advanced System Installer"
    local variantHelpText = {
        "This station can install most advanced system upgrades.",
        "For armor upgrades, find an Armor Foundry or a Spacedock."
    }
    return title, variantHelpText, -1, 5, nil, {"armor"}
end
callable(XSystemInstallerAdvanced, "restrictArgs")