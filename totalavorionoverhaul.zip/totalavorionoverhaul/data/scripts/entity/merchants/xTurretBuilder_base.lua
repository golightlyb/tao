package.path = package.path .. ";data/scripts/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"
include ("randomext")
include ("galaxy")
include ("utility")
include ("stringutility")
include ("faction")
include ("player")
include ("relations")
include ("merchantutility")
include ("callable")
include ("goods")
include ("inventoryitemprice")
include ("tooltipmaker")
local Dialog = include("dialogutility")
local turretsTableOrder, turretsTable = include("x_turrets_table")
local SellableInventoryItem = include ("sellableinventoryitem")
local SectorTurretGenerator = include ("sectorturretgenerator")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XTurretBuilder
XTurretBuilder = {}
XTurretBuilder.interactionThreshold = 10000

local allowedTypes = nil -- set of ids, if nil, ignored
local deniedTypes  = nil -- set of ids, if nil ignored
local mainTitle    = "Assemble Weapons  /* Window and Interaction Title*/"%_t

local minSelectedRarity = -1 -- petty
local maxSelectedRarity =  5 -- legendary

function XTurretBuilder.restrict(title, minRarity, maxRarity, allowedTypeList, deniedTypeList)
    if title then
        mainTitle = title
    end
    minSelectedRarity = (minRarity or -1)
    maxSelectedRarity = (maxRarity or 5) -- legendary
    -- e.g. {"xarmor"}
    local typeList = allowedTypeList
    if typeList then
        allowedTypes = {}
        for i = 1,#typeList do
            allowedTypes[typeList[i]] = true
        end
    end
    local typeList = deniedTypeList
    if typeList then
        deniedTypes = {}
        for i = 1,#typeList do
            deniedTypes[typeList[i]] = true
        end
    end
    
    if onServer() then
        invokeClientFunction(Player(callingPlayer), "restrict", title, variantHelpText, minRarity, maxRarity, allowedTypeList, deniedTypeList)
    end
end
callable(XTurretBuilder, "restrict")

function XTurretBuilder.interactionPossible(playerIndex, option)
    return CheckFactionInteraction(playerIndex, XTurretBuilder.interactionThreshold)
end

local bestMaterial = Material(0)
local techLevel = 0
local techMark = ""

local function bucket(num) -- group 52 tech levels into buckets of size 5
	return math.floor((num / 5) + 0.5) * 5
end

local function bucketToMark(num) -- group 52 tech levels into buckets of size 5
	return math.floor((num / 5) + 0.5)
end

function XTurretBuilder.initialize()
    local station = Entity()

    if station.title == "" then
        station.title = "Weapon Assembler"%_t
    end
    
    local x, y = Sector():getCoordinates()
    local materials = Balancing_GetMaterialProbability(x, y)
    local highest = 0
    for k, p in pairs(materials) do
        if p >= 0.2 then
            k = math.max(k, highest)
        end
    end
    bestMaterial = Material(highest)
    
    local tech = Balancing_GetTechLevel(x, y)
    techLevel = bucket(tech)
    techMark  = toRomanLiterals(bucketToMark(tech))
end

function XTurretBuilder._visitTurretsTable(visit)
    for i = 1, #turretsTableOrder do
        local id = turretsTableOrder[i]
        local turret = turretsTable[id]
        if turret and (not turret.hidden) and (allowedTypes == nil or allowedTypes[id]) and (deniedTypes == nil or (not deniedTypes[id])) then
            visit(id, turret)
        end
    end
end

local mainWindow

function XTurretBuilder.initUI()
    local res = getResolution()
    local size = vec2(800, 480)
    
    local menu = ScriptUI()
    window = menu:createWindow(Rect(res * 0.5 - size * 0.5, res * 0.5 + size * 0.5))
    menu:registerWindow(window, mainTitle, 15)
    mainWindow = window -- handle used for centering items
    
    local station = Entity()
    window.caption = mainTitle
    window.showCloseButton = 1
    window.moveable = 1
    
    -- create a padded inner window
    local window = window:createTabbedWindow(Rect(vec2(10, 10), size - 10))
    
    local tab = window:createTab("Assemble"%_t, "data/textures/icons/turret-blueprint.png", "Assemble and buy new weapons"%_t)
    XTurretBuilder.buildAssembleTab(tab)
    
    local tab = window:createTab("Upgrade"%_t, "data/textures/icons/upgrade-production.png", "Upgrade existing weapons"%_t)
    XTurretBuilder.buildUpgradeTab(tab)
end

local playerStock = {} -- k,v in pairs {good id, quantity}
local playerTurrets = {} -- k,v in pairs {system id ":" rarity, quantity}
local playerInstalledTurrets = {}
local maxIngredientTypesPerTurret = 4

-- returns the number of ingredients needed to upgrade to the next level of rarity
local function ingredientUpgradeQuantity(baseQuantity, rarityValue)
    return math.ceil(baseQuantity * math.pow(2, (rarityValue)))
end

local assemble = {}
local upgrade  = {}

function XTurretBuilder._doNothing()
end

function XTurretBuilder.buildAssembleTab(window)
    assemble.previousSelectedType = nil
    assemble.selectedRarity = -1
    
    ---[System Info]------------------------------------------------------------
    local x = 10
    local y = 15
    assemble.comboboxTurretType = window:createValueComboBox(Rect(x, y, x+190, y+20), "_assemble_comboboxTurretType_update")
    XTurretBuilder._visitTurretsTable(function(id, turret)
        assemble.comboboxTurretType:addEntry(id, turret.name, ColorRGB(1.0, 1.0, 1.0))
    end)
    
    y = y + 35
    assemble.borderPreview  = window:createRect            (Rect(x,   y,   x+190, y+190), ColorRGB(1.0, 1.0, 1.0))
    assemble.picturePreview = window:createPicture         (Rect(x+4, y+4, x+186, y+186), "data/textures/icons/minus.png")
    assemble.tooltipPreview = window:createTooltipDisplayer(Rect(x,   y,   x+190, y+190))

    y = y + 205
    local button = window:createButton(Rect(x, y, x+60, y+30), "-", "_assemble_decreaseRarity")
    button.icon = "data/textures/icons/minus.png"
    local button = window:createButton(Rect(x+130, y, x+190, y+30), "+", "_assemble_increaseRarity")
    button.icon = "data/textures/icons/plus.png"

    assemble.labelRarity = window:createLabel(vec2(0, y+10), "RARITY", 8)
    assemble.labelRarity.font = FontType.SciFi
    
    ---[Dividers]---------------------------------------------------------------
    window:createLine(vec2(220,  10), vec2(220, 300))
    window:createLine(vec2( 10, 310), vec2(770, 310))
    window:createLine(vec2(220, 325), vec2(220, 410))
    
    ---[Ingredients]------------------------------------------------------------
    local x = 240
    -- local y = 35
    
    local nameX       = x + 10
    local requiredX   = x + 290
    local stockX      = x + 420
    
    local y = 10
    window:createLabel(vec2(nameX,     y), "Cost"%_T, 20)
    
    local y = 50
    window:createLabel(vec2(nameX,     y), "Ingredient"%_T,     15)
    window:createLabel(vec2(requiredX, y), "Required"%_T,       15)
    window:createLabel(vec2(stockX,    y), "You Have"%_T,       15)
    
    assemble.ingredientFrames         = {}
    assemble.ingredientNameLabels     = {}
    assemble.ingredientRequiredLabels = {}
    assemble.ingredientStockLabels    = {}
    
    y = y + 25
    for i = 1, maxIngredientTypesPerTurret + 2 do -- +2 lines for cash and system of previous level
        local yText = y + 6

        local frame         = window:createFrame(Rect(x, y, 770, 30 + y))
        local nameLabel     = window:createLabel(vec2(nameX,     yText), "", 15)
        local requiredLabel = window:createLabel(vec2(requiredX, yText), "", 15)
        local stockLabel    = window:createLabel(vec2(stockX,    yText), "", 15)

        table.insert(assemble.ingredientFrames,         frame)
        table.insert(assemble.ingredientNameLabels,     nameLabel)
        table.insert(assemble.ingredientRequiredLabels, requiredLabel)
        table.insert(assemble.ingredientStockLabels,    stockLabel)

        y = y + 35
    end    
    
    ---[Bottom bar, left]-------------------------------------------------------
    local y = 320
    assemble.labelBuy = window:createLabel(vec2(10, y), "Frobbulator Weapon", 15)
    assemble.labelBuy.color = ColorRGB(0.5, 0.5, 0.5)
    
    y = y + 15
    local label = window:createLabel(vec2(10, y), bestMaterial.name, 15)
    label.color = bestMaterial.color
    
    y = y + 15
    local label = window:createLabel(vec2(10, y), "Tech level "..techLevel.. " (MK "..techMark..")", 15)
    
    --checkboxInstall = window:createCheckBox(Rect(10, y, 200, y+20), "Install directly", "forceRefresh")
    --checkboxInstall:setCheckedNoCallback(true)
    --checkboxInstall.tooltip = "If checked, may replace an installed weaker system and return it to your inventory.\n\nIf unchecked, or if you have no free system slots, sends the system to your inventory instead."%_t
    
    y = y + 35
    assemble.buttonBuy = window:createButton(Rect(10, y, 200, y+20), "Purchase", "_assemble_buy")
    
    
    ---[Bottom bar, right]------------------------------------------------------
    x = 240
    y = 320
    
    y = y + 25
    assemble.infoLabel1 = window:createLabel(Rect(x, y, 770, y+20), "Description", 15)
    y = y + 20
    assemble.infoLabel2 = window:createLabel(Rect(x, y, 770, y+20), "Description", 15)
end

function XTurretBuilder.buildUpgradeTab(window)
    window:createLabel(vec2(10, 10), "Coming soon...", 15)
end

local function possibleIngredient(goodId)
    local possible = {
        XMetal         = true,
        XMetalAdvanced = true,
        XElectronics   = true,
        XLens          = true,
        XSystem        = true,
    }
    return possible[goodId] or false
end

function XTurretBuilder.onShowWindow()
    XTurretBuilder.forceRefresh()
end

function XTurretBuilder._assemble_comboboxTurretType_update()
    assemble.selectedRarity = 0
    XTurretBuilder.refresh()
end

function XTurretBuilder._assemble_decreaseRarity()
    assemble.selectedRarity = math.max(minSelectedRarity, assemble.selectedRarity - 1)
    XTurretBuilder.forceRefresh()
end

function XTurretBuilder._assemble_increaseRarity()
    assemble.selectedRarity = math.min(maxSelectedRarity, assemble.selectedRarity + 1)
    XTurretBuilder.forceRefresh()
end

function XTurretBuilder.forceRefresh()
    assemble.previousSelectedType = nil
    XTurretBuilder.refresh()
end
callable(XTurretBuilder, "forceRefresh")

function XTurretBuilder.forceAsyncRefresh()
    -- display doesn't always update after server sends the new item
    -- so try again after a few tenths of a second
    XTurretBuilder.forceRefresh()
    deferredCallback(0.2, "forceRefresh")
end
callable(XTurretBuilder, "forceAsyncRefresh")

local function readPlayerCargo(player)
    for k, _ in pairs(playerStock) do
        playerStock[k] = 0
    end
    
    local player = player or Player()
    if not player then end
    
    local craft = player.craft
    if not craft then return end
    
    local cargoBay = CargoBay(craft)
    if not cargoBay then return end
    
    local cargo = cargoBay:getCargos()
    if not cargo then return end
    
    for good, quantity in pairs(cargo) do
        if good.stolen then goto continue end
        local id = GetGoodID(good.name)
        if not possibleIngredient(id) then goto continue end
        playerStock[id] = quantity
        ::continue::
    end
    
    playerStock["cash"] = (player.money or 0)
end

local function readPlayerTurrets(player)
    for k, _ in pairs(playerTurrets) do
        playerTurrets[k] = 0
    end

    local player = player or Player()
    if not player then return end
    
    local inventory = player:getInventory()
    if not inventory then return end
    
    items = inventory:getItemsByType(InventoryItemType.Turret) 
    if not items then return end

    for _, v in pairs(items) do
        local item = v.item
        local n = v.amount
    end
end

local function readPlayerInstalledTurrets(player)
    for k, _ in pairs(playerInstalledTurrets) do
        playerInstalledTurrets[k] = 0
    end

    local player = player or Player()
    if not player then return end
    
    local craft = player.craft or none
    if not craft then return end
    
    local turrets = player:getShipTurretDesigns(craft.name)
    if not turrets then return end
    
    for _, v in pairs(items) do
        local item = v.item
        local n = v.amount
    end
end

local function readPlayer(player)
    local player = player or Player()
    readPlayerCargo(player)
    readPlayerTurrets(player)
    readPlayerInstalledTurrets(player)
end

function XTurretBuilder.refresh()
    XTurretBuilder._assemble_refresh()
end

function XTurretBuilder._assemble_refresh()
    local selectedType = assemble.comboboxTurretType.selectedValue
    local selectedRarity = assemble.selectedRarity
    
    if (selectedType ~= assemble.previousSelectedType) and selectedType then
        local player = Player()
        readPlayer(player)
        
        ---[update labels and preview]------------------------------------------
        assemble.labelBuy.caption = turretsTable[selectedType].name
        assemble.labelBuy.color = Rarity(selectedRarity).color
        
        -- relative to 120, 325 (including 10 for window padding)
        assemble.labelRarity.caption = Rarity(selectedRarity).name
        local width = assemble.labelRarity.textWidth
        assemble.labelRarity.position = vec2(mainWindow.position.x + 115 - (width/2), assemble.labelRarity.position.y)

        assemble.previousSelectedType = selectedType
        
        assemble.currentPreview = XTurretBuilder._assemble_item(selectedType, selectedRarity)
        local tooltip = makeTurretTooltip(assemble.currentPreview, nil, 2)
        
        assemble.picturePreview:fadeTo(assemble.currentPreview.weaponIcon, 0)
        assemble.tooltipPreview:setTooltip(tooltip)
        assemble.borderPreview.color = Rarity(selectedRarity).color
        
        ---[update ingredients]------------------------------------------------
        for i = 1, maxIngredientTypesPerTurret + 2 do
            assemble.ingredientFrames[i].tooltip         = nil
            assemble.ingredientNameLabels[i].caption     = ""
            assemble.ingredientRequiredLabels[i].caption = ""
            assemble.ingredientStockLabels[i].caption    = ""
        end
        
        local offset = 1
        if selectedRarity >= 0 then
            local ingredients = turretsTable[selectedType].ingredients or {}
            for i = 1, #ingredients do
                local ing = ingredients[i]
                local id, quantity = ing[1], ing[2]
                local good = goods[id]
                if i > maxIngredientTypesPerTurret then goto continue end
                local levelQuantity = ingredientUpgradeQuantity(quantity, selectedRarity)
                
                assemble.ingredientFrames[i].tooltip         = "[TRADING GOOD]\n\n" .. good.description .. "\n\n".."Typically "..createMonetaryString(good.price).." Cr. each"
                assemble.ingredientNameLabels[i].caption     = good.name
                assemble.ingredientRequiredLabels[i].caption = levelQuantity
                assemble.ingredientStockLabels[i].caption    = (playerStock[id] or 0)
                
                ::continue::
            end
            offset = offset + #ingredients
        end
        
        local price = ArmedObjectPrice(InventoryTurret(assemble.currentPreview))
        assemble.ingredientNameLabels[offset].caption     = "Cash"
        assemble.ingredientRequiredLabels[offset].caption = createMonetaryString(price).." Cr." -- TODO
        assemble.ingredientStockLabels[offset].caption    = createMonetaryString(playerStock["cash"] or 0) .. " Cr."
        offset = offset + 1
        
        ---- buy button
        local caption = turretsTable[selectedType].desc
        assemble.infoLabel1.caption = caption[1] or ""
        assemble.infoLabel2.caption = caption[2] or ""
    end
    
    -- local s = 
    -- local upgrade 
    -- player:getInventory():add(upgrade, true)
end
callable(XTurretBuilder, "refresh")

function XTurretBuilder._assemble_item(id, rarity)
    local x, y = Sector():getCoordinates()
    local generator = SectorTurretGenerator()
    if not generator then
        print("nil sector turret generator")
    end
    local material = bestMaterial
    local item = generator:generate(x, y, 0, Rarity(rarity), turretsTable[id].wtype, material)
    if not item then print("turret generation error") end
    return item
end

function XTurretBuilder._assemble_checkCanPurchase(id, rarity)
    -- returns ok, reasonIfNotOk, [moneyToTake, stockToTake]
    
    local item = XTurretBuilder._assemble_item(id, rarity)
    
    local moneyToTake = ArmedObjectPrice(InventoryTurret(item))
    local stockToTake = {} -- map id -> quantity
    
    --- check ingredients ------------------------------------------------------
    if rarity >= 0 then
        local ingredients = turretsTable[id].ingredients or {}
        for i = 1, #ingredients do
            local ing = ingredients[i]
            local ingId, quantity = ing[1], ing[2]
            local good = goods[ingId]
            if i > maxIngredientTypesPerTurret then goto continue end
            local levelQuantity = ingredientUpgradeQuantity(quantity, rarity)
            
            local have = (playerStock[ingId] or 0)
            if have < levelQuantity then
                return false, "Missing ingredients (need "..levelQuantity.." "..good.name..")"
            end

            stockToTake[ingId] = levelQuantity
            
            ::continue::
        end
    end
    
    --- check cash -------------------------------------------------------------
    local cash = playerStock["cash"] or 0
    if (cash < moneyToTake) and not Scenario().isCreative then
        return false, "Not enough money."%_t
    end
    
    return true, "", moneyToTake, stockToTake
end

function XTurretBuilder._assemble_buy(button)
    local player = Player()
    local id = assemble.comboboxTurretType.selectedValue
    local rarity = assemble.selectedRarity
    
    readPlayer(player)
    local ok, reason, _, _ = XTurretBuilder._assemble_checkCanPurchase(id, rarity)
    if not ok then
        player:sendChatMessage(reason, 1)
        goto continue
    end
    
    invokeServerFunction("_assemble_complete", id, rarity)
    
    ::continue::
end

function XTurretBuilder._assemble_complete(id, rarity)
    local player = Player(callingPlayer)
    local ship   = player.craft
    
    print("got order:")
    print(rarity)
    print(id)
    print("---")
    
    ---[item]--
    local item = XTurretBuilder._assemble_item(id, rarity)
    
    ---[checks]-----------------------------------------------------------------
    readPlayer(player)
    local ok, reason, moneyToTake, stockToTake = XTurretBuilder._assemble_checkCanPurchase(id, rarity)
    if not ok then
        player:sendChatMessage(mainTitle, 1, reason)
        return
    end
    
    local errors = {}
    errors[EntityType.Station] = "You must be docked to the station to trade."%_T
    errors[EntityType.Ship] = "You must be closer to the ship to trade."%_T
    if (not ship) or (not CheckShipDocked(player, ship, Entity(), errors)) then
        return
    end
    
    -- we can assume the neccessary cargo, inventories etc. have been checked
    -- at this point for the purposes of paying, but the player does need to be
    -- able to recieve the item and we check that before paying...
    local craft = player.craft
    if not craft then return end
    
    local inventory = player:getInventory()
    if not inventory then return end
    
    if inventory.occupiedSlots >= inventory.maxSlots then
        player:sendChatMessage(mainTitle, 1, "inventory full"%_T)
        return
    end
    
    local canPay, _, _ = player:canPayMoney(moneyToTake)
    if not canPay then
        player:sendChatMessage(mainTitle, 1, "you can't afford this"%_T)
        return
    end
    
    ---[pay cargo]--------------------------------------------------------------
    local cargoBay = CargoBay(craft)
    if (not cargoBay) and (stockToTake ~= {}) then return end
    
    for k, v in pairs(stockToTake) do
        cargoBay:removeCargo(tableToGood(goods[k]), v)
    end
    
    ---[pay money]--------------------------------------------------------------
    if moneyToTake > 0 then player:pay("Paid %1% credits", moneyToTake) end
        
    ---[send to inventory]------------------------------------------------------
    if (not install) or forceSendToInventory then
        local item = SellableInventoryItem(InventoryTurret(item))
        
        -- recent = true is helpful when there's lots of loot, but when there's
        -- few systems like in our overhaul, its easier if they stack nicely
        -- instead
        local recent = false
        
        -- should never drop, but just in case inventory is somehow full after
        -- checking it wasn't full
        inventory:addOrDrop(item.item, recent)
        
        player:sendChatMessage(mainTitle, 0, "new weapon sent to inventory!"%_T)
    end
    
    invokeClientFunction(player, "forceAsyncRefresh")
end
callable(XTurretBuilder, "_assemble_complete")

