package.path = package.path .. ";data/scripts/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"
include ("randomext")
include ("galaxy")
include ("utility")
include ("stringutility")
include ("faction")
include ("player")
include ("relations")
include ("merchantutility")
include ("callable")
include ("goods")
local Dialog = include("dialogutility")
local systemsTableOrder, systemsTable = include("systems/x_systems_table")
local SellableInventoryItem = include ("sellableinventoryitem")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XSystemInstaller
XSystemInstaller = {}
XSystemInstaller.interactionThreshold = 10000

local variant
local allowedTypes = nil -- set of ids, if nil, ignored
local deniedTypes  = nil -- set of ids, if nil ignored
local helpText     = nil -- helpText is a tuple {text, tooltip}
local mainTitle    = "Install Systems  /* Window and Interaction Title*/"%_t

local minSelectedRarity = -1 -- petty
local maxSelectedRarity =  4 -- exotic
local selectedRarity    =  0 -- (0; common) to (5; legendary)

function XSystemInstaller.restrict(title, variantHelpText, minRarity, maxRarity, allowedTypeList, deniedTypeList)
    if title then
        mainTitle = title
    end
    -- variantHelpText is a tuple {text, tooltip}
    if variantHelpText then
        helpText = variantHelpText
    end
    minSelectedRarity = (minRarity or -1)
    maxSelectedRarity = (maxRarity or 5) -- legendary
    -- e.g. {"xarmor"}
    local typeList = allowedTypeList
    if typeList then
        allowedTypes = {}
        for i = 1,#typeList do
            allowedTypes[typeList[i]] = true
        end
    end
    local typeList = deniedTypeList
    if typeList then
        deniedTypes = {}
        for i = 1,#typeList do
            deniedTypes[typeList[i]] = true
        end
    end
    
    if onServer() then
        invokeClientFunction(Player(callingPlayer), "restrict", title, variantHelpText, minRarity, maxRarity, allowedTypeList, deniedTypeList)
    end
end
callable(XSystemInstaller, "restrict")

function XSystemInstaller.interactionPossible(playerIndex, option)
    return CheckFactionInteraction(playerIndex, XSystemInstaller.interactionThreshold)
end

function XSystemInstaller._defaultHelpText()
    return  {
        "Spacedocks carry out general, but limited system installations."%_T,
            "For Armor upgrades up to Legendary, find an Armor Forge."%_T.."\n"..
            "For System upgrades up to Legendary, find a Systems Factory."%_T
    }
end

function XSystemInstaller.initialize()
    local station = Entity()
    helpText = XSystemInstaller._defaultHelpText()
    
    if station.title == "" then
        station.title = "System Installer"%_t
    end

    local variant = station:getValue("XSystemInstaller_variant")
    if variant then
        station:addScriptOnce("data/scripts/entity/merchants/XSystemInstaller_"..variant..".lua")
    end
    
    station:setValue("remove_permanent_upgrades", true)
end

function XSystemInstaller._visitSystemsTable(visit)
    for i = 1, #systemsTableOrder do
        local id = systemsTableOrder[i]
        local system = systemsTable[id]
        if system and (not system.hidden) and (allowedTypes == nil or allowedTypes[id]) and (deniedTypes == nil or (not deniedTypes[id])) then
            visit(id, system)
        end
    end
end

local mainWindow

function XSystemInstaller.initUI()
    if variant then
        ok, title, variantHelpText, minRarity, maxRarity, allowedTypeList, deniedTypeList = station:invokeFunction("data/scripts/entity/merchants/XSystemInstaller_"..variant..".lua", "restrict")
        if ok then
            XSystemInstaller.restrict(title, variantHelpText, minRarity, maxRarity, allowedTypeList, deniedTypeList)
        else
            print("XSystemInstaller: failed to invoke variant restrict function")
        end
    end

    local res = getResolution()
    local size = vec2(800, 480)
    
    local menu = ScriptUI()
    window = menu:createWindow(Rect(res * 0.5 - size * 0.5, res * 0.5 + size * 0.5))
    menu:registerWindow(window, mainTitle, 12)
    mainWindow = window -- handle used for centering items
    
    local station = Entity()
    window.caption = mainTitle
    window.showCloseButton = 1
    window.moveable = 1
    
    -- create a padded inner window
    XSystemInstaller.buildGui(window:createTabbedWindow(Rect(vec2(10, 10), size - 10)))
end

local playerStock = {} -- k,v in pairs {good id, quantity}
local playerSystems = {} -- k,v in pairs {system id ":" rarity, quantity}
local playerInstalledSystems = {}
local maxIngredientTypesPerSystem = 3

-- returns the number of ingredients needed to upgrade to the next level of rarity
local function ingredientUpgradeQuantity(baseQuantity, rarityValue)
    return math.ceil(baseQuantity * math.pow(2, (selectedRarity + 1)))
end

local function numberOfPreviousUpgradesRequired(id, rarityValue)
    if rarityValue <= 0 then -- common
        return 0
    elseif rarityValue == 1 then -- uncommon
        return 1
    elseif rarityValue <= 3 then -- up to exceptional
        return 2
    else
        return 1 -- the cost is prohibative enough!
    end
end

local comboboxSystemType
local ingredientFrames = {}
local ingredientNameLabels  = {}
local ingredientRequiredLabels = {}
local ingredientStockLabels = {}
local ownedMarkLabels = {}
local ownedQuantityLabels = {}
local checkboxInstall
local picturePreview
local tooltipPreview
local borderPreview
local labelMark
local labelPreviousLevelInventoryMix
local labelBuy
local buttonBuy

local currentPreview       = nil
local previousSelectedType = nil

function XSystemInstaller._doNothing()
end

function XSystemInstaller.buildGui(window)
    
    ---[Top Bar]----------------------------------------------------------------
    local label = window:createLabel(vec2(10, 5), "[?] "..helpText[1], 14)
    label.tooltip = helpText[2]
    label.color = ColorRGB(0.5, 1.0, 1.0)
    
    ---[System Info]------------------------------------------------------------
    local x = 10
    local y = 55
    comboboxSystemType = window:createValueComboBox(Rect(x, y, x+190, y+20), "_updateSelection")
    XSystemInstaller._visitSystemsTable(function(id, system)
        comboboxSystemType:addEntry(id, system.name, ColorRGB(1.0, 1.0, 1.0))
    end)
    
    y = y + 35
    borderPreview  = window:createRect            (Rect(x,   y,   x+190, y+190), ColorRGB(1.0, 1.0, 1.0))
    picturePreview = window:createPicture         (Rect(x+4, y+4, x+186, y+186), "data/textures/icons/minus.png")
    tooltipPreview = window:createTooltipDisplayer(Rect(x,   y,   x+190, y+190))

    y = y + 205
    local button = window:createButton(Rect(x, y, x+60, y+30), "-", "_decreaseRarity")
    button.icon = "data/textures/icons/minus.png"
    local button = window:createButton(Rect(x+130, y, x+190, y+30), "+", "_increaseRarity")
    button.icon = "data/textures/icons/plus.png"

    labelMark = window:createLabel(vec2(0, y+5), "", 14)
    labelMark.font = FontType.SciFi
    
    ---[Dividers]---------------------------------------------------------------
    window:createLine(vec2(220,  50), vec2(220, 340))
    window:createLine(vec2( 10, 350), vec2(770, 350))
    window:createLine(vec2(220, 365), vec2(220, 460))
    
    ---[Ingredients]------------------------------------------------------------
    local x = 240
    -- local y = 35
    labelName = window:createLabel(vec2(250, 500), "", 16)
    labelName.font = FontType.SciFi
    
    local nameX       = x + 10
    local requiredX   = x + 290
    local stockX      = x + 420
    
    local y = 50
    window:createLabel(vec2(nameX,     y), "Cost"%_T, 20)
    
    local y = 90
    window:createLabel(vec2(nameX,     y), "Ingredient"%_T,     15)
    window:createLabel(vec2(requiredX, y), "Required"%_T,       15)
    window:createLabel(vec2(stockX,    y), "You Have"%_T,       15)
    
    y = y + 25
    for i = 1, maxIngredientTypesPerSystem + 2 do -- +2 lines for cash and system of previous level
        local yText = y + 6

        local frame         = window:createFrame(Rect(x, y, 770, 30 + y))
        local nameLabel     = window:createLabel(vec2(nameX,     yText), "", 15)
        local requiredLabel = window:createLabel(vec2(requiredX, yText), "", 15)
        local stockLabel    = window:createLabel(vec2(stockX,    yText), "", 15)

        table.insert(ingredientFrames,         frame)
        table.insert(ingredientNameLabels,     nameLabel)
        table.insert(ingredientRequiredLabels, requiredLabel)
        table.insert(ingredientStockLabels,    stockLabel)

        y = y + 35
    end
    
    labelPreviousLevelInventoryMix = window:createLabel(vec2(x + 10, y + 15), "", 15)
    
    ---[Bottom bar, left]-------------------------------------------------------
    local y = 360
    labelBuy = window:createLabel(Rect(10, y, 780, y+20), "Frobbulator System", 15)
    labelBuy.color = ColorRGB(0.5, 0.5, 0.5)
    
    y = y + 35
    checkboxInstall = window:createCheckBox(Rect(10, y, 200, y+20), "Install directly", "forceRefresh")
    checkboxInstall:setCheckedNoCallback(true)
    checkboxInstall.tooltip = "If checked, may replace an installed weaker system and return it to your inventory.\n\nIf unchecked, or if you have no free system slots, sends the system to your inventory instead."%_t
    
    y = y + 35
    buttonBuy = window:createButton(Rect(10, y, 200, y+20), "Pay & Install", "onInstallButtonPressed")
    
    
    ---[Bottom bar, right]------------------------------------------------------
    x = 240
    y = 360
    
    y = y + 25
    local width = (780 - x) / 7
    for i = 0, 6 do
        local rarity = Rarity(i-1)
        local label = window:createLabel(vec2(x + (width * i), y), "MK "..toRomanLiterals(i+1), 15)
        label.font = FontType.SciFi
        label.color = rarity.color
        label.tooltip = "You own this many of this system at this rarity."%_t
        table.insert(ownedMarkLabels, label)
        
        local label = window:createLabel(vec2(x + (width * i), y + 30), "-", 15)
        label.tooltip = "You own this many of this system at this rarity."%_t
        table.insert(ownedQuantityLabels, label)
    end
end

local function possibleIngredient(goodId)
    local possible = {
        XArmor       = true,
        XElectronics = true,
        XLens        = true,
        XSystem      = true,
    }
    return possible[goodId] or false
end

local function readPlayerCargo(player)
    for k, _ in pairs(playerStock) do
        playerStock[k] = 0
    end
    
    local player = player or Player()
    if not player then end
    
    local craft = player.craft
    if not craft then return end
    
    local cargoBay = CargoBay(craft)
    if not cargoBay then return end
    
    local cargo = cargoBay:getCargos()
    if not cargo then return end
    
    for good, quantity in pairs(cargo) do
        if good.stolen then goto continue end
        local id = GetGoodID(good.name)
        if not possibleIngredient(id) then goto continue end
        playerStock[id] = quantity
        ::continue::
    end
    
    playerStock["cash"] = (player.money or 0)
end

local function readPlayerSystems(player)
    for k, _ in pairs(playerSystems) do
        playerSystems[k] = 0
    end

    local player = player or Player()
    if not player then return end
    
    local inventory = player:getInventory()
    if not inventory then return end
    
    items = inventory:getItemsByType(InventoryItemType.SystemUpgrade) 
    if not items then return end

    for _, v in pairs(items) do
        local item = v.item
        local n = v.amount
        
        -- TODO optimise; this is O(kn) for k = number of system types, but
        -- k is small.
        XSystemInstaller._visitSystemsTable(function(id, system)
            if system.script == item.script then
                local key = id .. ":" .. item.rarity.value
                playerSystems[key] = (playerSystems[key] or 0) + n
            end
        end)
    end
end

local function readPlayerInstalledSystems(player)
    for k, _ in pairs(playerInstalledSystems) do
        playerInstalledSystems[k] = 0
    end

    local player = player or Player()
    if not player then return end
    
    local craft = player.craft or none
    if not craft then return end
    
    local shipSystem = ShipSystem(craft)
    if not shipSystem then return end
    
    local systems = shipSystem:getUpgrades()
    if not systems then return end
    
    for item, installed in pairs(systems) do
        -- if not installed then goto continue end
        
        -- TODO optimise; this is O(kn) for k = number of system types, but
        -- k is small.
        XSystemInstaller._visitSystemsTable(function(id, system)
            if system.script == item.script then
                local key = id .. ":" .. item.rarity.value
                playerInstalledSystems[key] = (playerInstalledSystems[key] or 0) + 1
            end
        end)
    end
end

local function readPlayer(player)
    local player = player or Player()
    readPlayerCargo(player)
    readPlayerSystems(player)
    readPlayerInstalledSystems(player)
end

local function playerSystemsOfType(id, rarity)
    return playerSystems[id .. ":" .. rarity] or 0
end

local function playerInstalledSystemsOfType(id, rarity)
    return playerInstalledSystems[id .. ":" .. rarity] or 0
end

function XSystemInstaller.onShowWindow()
    XSystemInstaller.forceRefresh()
end

function XSystemInstaller._updateSelection()
    selectedRarity = 0
    XSystemInstaller.refresh()
end

function XSystemInstaller._decreaseRarity()
    selectedRarity = math.max(minSelectedRarity, selectedRarity - 1)
    XSystemInstaller.forceRefresh()
end

function XSystemInstaller._increaseRarity()
    selectedRarity = math.min(maxSelectedRarity, selectedRarity + 1)
    XSystemInstaller.forceRefresh()
end

function XSystemInstaller.forceRefresh()
    previousSelectedType = nil
    XSystemInstaller.refresh()
end
callable(XSystemInstaller, "forceRefresh")

function XSystemInstaller.forceAsyncRefresh()
    -- display doesn't always update after server sends the new item
    -- so try again after a few tenths of a second
    XSystemInstaller.forceRefresh()
    deferredCallback(0.2, "forceRefresh")
end
callable(XSystemInstaller, "forceAsyncRefresh")

function XSystemInstaller.refresh()
    local selectedType = comboboxSystemType.selectedValue
    
    if (selectedType ~= previousSelectedType) and selectedType then
        local player = Player()
        readPlayer(player)
        
        ---[update labels and preview]------------------------------------------
        labelBuy.caption = systemsTable[selectedType].name
        labelBuy.color = Rarity(selectedRarity).color
        
        -- relative to 120, 325 (including 10 for window padding)
        labelMark.caption = "MK " .. toRomanLiterals(selectedRarity + 2)
        local width = labelMark.textWidth
        labelMark.position = vec2(mainWindow.position.x + 115 - (width/2), labelMark.position.y)

        previousSelectedType = selectedType
        currentPreview = SystemUpgradeTemplate(systemsTable[selectedType].script, Rarity(selectedRarity), Seed("0"))
        picturePreview:fadeTo(currentPreview.icon, 0)
        tooltipPreview:setTooltip(currentPreview.tooltip)
        borderPreview.color = Rarity(selectedRarity).color
        
        ---[update ingredients]------------------------------------------------
        for i = 1, maxIngredientTypesPerSystem + 2 do
            ingredientFrames[i].tooltip         = nil
            ingredientNameLabels[i].caption     = ""
            ingredientRequiredLabels[i].caption = ""
            ingredientStockLabels[i].caption    = ""
        end
        
        local offset = 1
        if selectedRarity >= 0 then
            local ingredients = systemsTable[selectedType].ingredients or {}
            for i = 1, #ingredients do
                local ing = ingredients[i]
                local id, quantity = ing[1], ing[2]
                local good = goods[id]
                if i > maxIngredientTypesPerSystem then goto continue end
                local levelQuantity = ingredientUpgradeQuantity(quantity, selectedRarity)
                
                ingredientFrames[i].tooltip         = "[TRADING GOOD]\n\n" .. good.description .. "\n\n".."Typically "..createMonetaryString(good.price).." Cr. each"
                ingredientNameLabels[i].caption     = good.name
                ingredientRequiredLabels[i].caption = levelQuantity
                ingredientStockLabels[i].caption    = (playerStock[id] or 0)
                
                ::continue::
            end
            offset = offset + #ingredients
        end
        
        ingredientNameLabels[offset].caption     = "Cash"
        ingredientRequiredLabels[offset].caption = createMonetaryString(currentPreview.price).." Cr."
        ingredientStockLabels[offset].caption    = createMonetaryString(playerStock["cash"] or 0) .. " Cr."
        offset = offset + 1
        
        local numberOfPreviousUpgrades = numberOfPreviousUpgradesRequired(selectedType, selectedRarity)
        if numberOfPreviousUpgrades > 0 then
            -- requires a previous rarity to upgrade
            local fromInventory = playerSystemsOfType(selectedType, selectedRarity - 1)
            local fromInstalled = playerInstalledSystemsOfType(selectedType, selectedRarity - 1)
            
            ingredientNameLabels[offset].caption     = systemsTable[selectedType].name ..  " MK " .. toRomanLiterals(selectedRarity + 1)
            ingredientRequiredLabels[offset].caption = "" .. numberOfPreviousUpgrades
            ingredientStockLabels[offset].caption    =  (fromInventory + fromInstalled) .. " *"
            
            ingredientNameLabels[offset].color = Rarity(selectedRarity - 1).color
            
            labelPreviousLevelInventoryMix.caption = "* " .. fromInventory .. " from inventory and " .. fromInstalled .. " installed."
        else
            labelPreviousLevelInventoryMix.caption = ""
        end
        
        -- update owned --
        x = 280
        local width = (800 - x) / 7
        for i = 0, 6 do
            local rarity = Rarity(i-1)
            local label = ownedMarkLabels[i+1]
            local w = label.textWidth
            label.position = vec2(mainWindow.position.x + x + (width * i) - (w/2), label.position.y)
            
            local label = ownedQuantityLabels[i+1]
            local fromInventory = playerSystemsOfType(selectedType, i - 1)
            local fromInstalled = playerInstalledSystemsOfType(selectedType, i - 1)
            label.caption = fromInstalled + fromInventory
            local w = label.textWidth
            label.position = vec2(mainWindow.position.x + x + (width * i) - (w/2), label.position.y)
        end
        
        ---- buy button
        if checkboxInstall.checked then
            buttonBuy.caption = "Pay & Install"%_T
        else
            buttonBuy.caption = "Purchase"%_T
        end
    end
    
    -- local s = 
    -- local upgrade 
    -- player:getInventory():add(upgrade, true)
end
callable(XSystemInstaller, "refresh")

function XSystemInstaller.checkCanPurchase(id, rarity, price)
    -- returns ok, reasonIfNotOk, [moneyToTake, stockToTake, systemsToTake, installedSystemsToTake]
    local required = {}

    local moneyToTake   = price
    local stockToTake   = {} -- map id -> quantity
    local systemsToTake = 0
    local installedSystemsToTake = 0
    
    --- check ingredients ------------------------------------------------------
    if rarity >= 0 then
        local ingredients = systemsTable[id].ingredients or {}
        for i = 1, #ingredients do
            local ing = ingredients[i]
            local ingId, quantity = ing[1], ing[2]
            local good = goods[ingId]
            if i > maxIngredientTypesPerSystem then goto continue end
            local levelQuantity = ingredientUpgradeQuantity(quantity, rarity)
            
            local have = (playerStock[ingId] or 0)
            if have < levelQuantity then
                return false, "Missing ingredients (need "..levelQuantity.." "..good.name..")"
            end

            stockToTake[ingId] = levelQuantity
            
            ::continue::
        end
    end
    
    --- check cash -------------------------------------------------------------
    local cash = playerStock["cash"] or 0
    if (cash < price) and not Scenario().isCreative then
        return false, "Not enough money."%_t
    end
    
    --- check systems ----------------------------------------------------------
    
    local numberOfPreviousUpgrades = numberOfPreviousUpgradesRequired(id, rarity)
    if numberOfPreviousUpgrades > 0 then
        local fromInventory = playerSystemsOfType(id, rarity - 1)
        local fromInstalled = playerInstalledSystemsOfType(id, rarity - 1)
        local haveTotal = fromInventory + fromInstalled
        if haveTotal < numberOfPreviousUpgrades then
            return false, "Missing required previous system (need "..numberOfPreviousUpgrades.." "..systemsTable[id].name.." MK "..toRomanLiterals(rarity + 1)
        end
        systemsToTake = math.min(numberOfPreviousUpgrades, fromInventory)
        installedSystemsToTake = numberOfPreviousUpgrades - systemsToTake
    end
    
    return true, "", moneyToTake, stockToTake, systemsToTake, installedSystemsToTake
end

function XSystemInstaller.onInstallButtonPressed(button)
    local player = Player()
    local install = checkboxInstall.checked
    local id = comboboxSystemType.selectedValue
    local rarity = selectedRarity
    local price = currentPreview.price
    
    readPlayer(player)
    local ok, reason, _, _, _ = XSystemInstaller.checkCanPurchase(id, rarity, price)
    if not ok then
        player:sendChatMessage(reason, 1)
        goto continue
    end
    
    invokeServerFunction("install", id, rarity, price, install)
    
    ::continue::
end

function XSystemInstaller.install(id, rarity, price, install)
    local player = Player(callingPlayer)
    local ship   = player.craft
    
    ---[checks]-----------------------------------------------------------------
    readPlayer(player)
    local ok, reason, moneyToTake, stockToTake, systemsToTake, installedSystemsToTake = XSystemInstaller.checkCanPurchase(id, rarity, price)
    if not ok then
        player:sendChatMessage("System Installer", 1, reason)
        return
    end
    
    local errors = {}
    errors[EntityType.Station] = "You must be docked to the station to trade."%_T
    errors[EntityType.Ship] = "You must be closer to the ship to trade."%_T
    if (not ship) or (not CheckShipDocked(player, ship, Entity(), errors)) then
        return
    end
    
    -- we can assume the neccessary cargo, inventories etc. have been checked
    -- at this point for the purposes of paying, but the player does need to be
    -- able to recieve the item and we check that before paying...
    local craft = player.craft
    if not craft then return end
    
    local inventory = player:getInventory()
    if not inventory then return end
    
    if inventory.occupiedSlots >= inventory.maxSlots then
        player:sendChatMessage("System Installer"%_t, 1, "inventory full"%_T)
        return
    end
    
    local shipSystem = ShipSystem(craft)
    if not shipSystem then return end
    
    local canPay, _, _ = player:canPayMoney(fee)
    if not canPay then
        player:sendChatMessage("System Installer"%_t, 1, "you can't afford this"%_T)
        return
    end
    
    ---[pay cargo]--------------------------------------------------------------
    local cargoBay = CargoBay(craft)
    if (not cargoBay) and (stockToTake ~= {}) then return end
    
    for k, v in pairs(stockToTake) do
        cargoBay:removeCargo(tableToGood(goods[k]), v)
    end
    
    ---[pay systems]------------------------------------------------------------
    
    -- remove installed (if neccessary) first, so that the removed item can
    -- then be removed from inventory in the next step
    for i = 0, shipSystem.numSockets-1 do
        local upgrade = shipSystem:getUpgrade(i)
        if not upgrade then goto continue end
        -- TODO optimise; this is O(kn) for k = number of system types, but
        -- k is small.
        XSystemInstaller._visitSystemsTable(function(systemId, system)
            if installedSystemsToTake > 0 and id == systemId and system.script == upgrade.script and upgrade.rarity.value == rarity - 1 then
                installedSystemsToTake = installedSystemsToTake - 1
                systemsToTake = systemsToTake + 1 -- remove it from cargo in next step
                shipSystem:removeUpgrade(i)
            end
        end)
        ::continue::
    end
    
    if installedSystemsToTake > 0 then
        -- should never happen but let's allow it to continue with a warning
        -- rather than take from the player and give them nothing in return
        print("ERROR: was unable to take installed system")
    end
    
    -- then remove from inventory
    local inventory = player:getInventory()
    local items = inventory:getItemsByType(InventoryItemType.SystemUpgrade)
    if items then        
        if systemsToTake > 0 then
            for i, v in pairs(items) do
                local item = v.item
                local n = v.amount

                -- TODO optimise; this is O(kn) for k = number of system types, but
                -- k is small.
                XSystemInstaller._visitSystemsTable(function(systemId, system)
                    if id == systemId and system.script == item.script and item.rarity.value == rarity - 1 then
                        local toRemove = math.min(n, systemsToTake)
                        for j = 1, toRemove do
                            inventory:remove(i)
                            systemsToTake = systemsToTake - 1
                        end
                    end
                end)
                
            end
        end
    end
    
    if systemsToTake > 0 then
        -- should never happen but let's allow it to continue with a warning
        -- rather than take from the player and give them nothing in return
        print("ERROR: was unable to take system")
    end
    
    ---[pay money]--------------------------------------------------------------
    if moneyToTake > 0 then player:pay("Paid %1% credits", moneyToTake) end
    
    
    ---[install purchase?]------------------------------------------------------
    local forceSendToInventory = false
    local system = SystemUpgradeTemplate(systemsTable[id].script, Rarity(rarity), Seed("0"))
    
    local freeSockets = shipSystem.numSockets - shipSystem.numUpgrades
    
    if install then
        local unique    = systemsTable[id].unique or false
        local permanent = systemsTable[id].permanent or false
        if unique then
            -- if there's an installed version of a lower level then remove it
            -- and install a replacement
            if XSystemInstaller._uninstallLowest(shipSystem, system) then
                print("unique; uninstalled a lower level to make room")
                XSystemInstaller._installSystem(shipSystem, system, permanent)
           
           -- otherwise just install it if there's room
            elseif freeSockets > 0 and not XSystemInstaller._installed(shipSystem, system) then
                print("unique; nothing to uninstall; have room")
                XSystemInstaller._installSystem(shipSystem, system, permanent)
                
            -- otherwise, send to inventory
            else
                print("unique; no room")
                forceSendToInventory = true
            end
        else
            -- not unique, so we can just install if there's room
            if freeSockets > 0 then
                print("not unique; have room")
                XSystemInstaller._installSystem(shipSystem, system, permanent)
                
            -- otherwise, if there's an installed version of a lower level then
            -- remove it and install a replacement
            elseif XSystemInstaller._uninstallLowest(shipSystem, system) then
                print("not unique; uninstalled a lower level to make room")
                XSystemInstaller._installSystem(shipSystem, system, permanent)
                
            -- otherwise, send to inventory
            else
                print("not unique; no room")
                forceSendToInventory = true
            end
        end
        
        if not forceSendToInventory then
            player:sendChatMessage("System Installer"%_t, 0, "new system installed!"%_T)
        end
    end
    
    ---[send to inventory?]-----------------------------------------------------
    if (not install) or forceSendToInventory then
        local item = SellableInventoryItem(system)
        
        -- recent = true is helpful when there's lots of loot, but when there's
        -- few systems like in our overhaul, its easier if they stack nicely
        -- instead
        local recent = false
        
        -- should never drop, but just in case inventory is somehow full after
        -- checking it wasn't full
        inventory:addOrDrop(item.item, recent)
        
        player:sendChatMessage("System Installer"%_t, 0, "new system sent to inventory!"%_T)
    end
    
    invokeClientFunction(player, "forceAsyncRefresh")
end
callable(XSystemInstaller, "install")


function XSystemInstaller._uninstallLowest(shipSystem, system)
    -- get lowest level
    local lowest = 999 -- inf
    for i = 0, shipSystem.numSockets-1 do
        local upgrade = shipSystem:getUpgrade(i)
        if not upgrade then goto continue end
        if upgrade.script == system.script then
            lowest = math.min(lowest, upgrade.rarity.value)
        end
        ::continue::
    end
    
    -- nothing lower than the one we want to install
    if lowest >= system.rarity.value then
        return false
    end
    
    -- got a candidate
    for i = 0, shipSystem.numSockets-1 do
        local upgrade = shipSystem:getUpgrade(i)
        if not upgrade then goto continue end
        if upgrade.script == system.script then
            if upgrade.rarity.value == lowest then
                shipSystem:removeUpgrade(i)
                return true
            end
        end
        ::continue::
    end
    
    print("unreachable")
    return false -- should never happen
end


function XSystemInstaller._installed(shipSystem, system)
    for i = 0, shipSystem.numSockets-1 do
        local upgrade = shipSystem:getUpgrade(i)
        if not upgrade then goto continue end
        if upgrade.script == system.script then
            return true
        end
        ::continue::
    end
    return false
end

function XSystemInstaller._installSystem(shipSystem, system, permanent)
    shipSystem:addUpgrade(system, permanent)
end
