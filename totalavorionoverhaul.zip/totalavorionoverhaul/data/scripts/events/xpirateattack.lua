
package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include ("galaxy")
include ("randomext")
include ("stringutility")
include ("player")
include ("relations")
local Placer = include ("placer")
local EventUT = include ("eventutility")
local ShipUtility = include("shiputility")
local Placer = include("placer")
local XSectorGenerator = include("xSectorGenerator")

local ships = {}
local reward = 0
local reputation = 0

local participants = {}

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XPirateAttack
XPirateAttack = {}
XPirateAttack.attackersGenerated = false

if onServer() then

    function XPirateAttack.secure()
        return {reward = reward, reputation = reputation, ships = ships}
    end

    function XPirateAttack.restore(data)
        ships = data.ships
        reputation = data.reputation
        reward = data.reward
    end

    function XPirateAttack.initialize()

        local sector = Sector()

        -- no pirate attacks at the very edge of the galaxy
        local x, y = sector:getCoordinates()
        if length(vec2(x, y)) > 560 then
            print("Too far out for pirate attacks.")
            terminate()
            return
        end

        if not EventUT.attackEventAllowed() then
            terminate()
            return
        end

        ships = {}
        participants = {}
        local numPirates = getInt(3, 6)
        reward = 1 + (numPirates / 2)
        reputation = 0

        local sector = Sector()
        local x, y = sector:getCoordinates()
        
        local faction = Galaxy():getPirateFaction(Balancing_GetPirateLevel(x, y) + 1)
        local controller = Galaxy():getControllingFaction(x, y)
        if controller and controller.index == faction.index then
            terminate()
            return
        end

        local sectorGenerator = XSectorGenerator(x, y, sector, faction, false, random)
        
        local generated = {}
        local function post(ship)
            ship.title = "Pirate Invader " .. ShipUtility.getMilitaryNameByVolume(ship.volume)
            ship:registerCallback("onDestroyed", "onShipDestroyed")
            ship:registerCallback("onSetForDeletion", "onShipDestroyed")
            ships[ship.index.string] = true
            table.insert(generated, ship)
        end
        
        sectorGenerator:createContents({
            x = {
                noSector = true,
                shapes = {
                    {
                        variant   = "arc",
                        params = {radius=200, span=1.0, thickness=100, depth=20},
                        offset = vec3(getFloat(-1000, 1000), getFloat(-100, 100), getFloat(-1000, 1000)),
                        ships  = {
                            {variant="pirate", number=numPirates, post=post},
                        },
                    },
                },
            },
        })
        
        Placer.resolveIntersections(generated)
        XPirateAttack.attackersGenerated = true

        reputation = reward * 2000
        reward = reward * 10000 * Balancing_GetSectorRichnessFactor(sector:getCoordinates())

        sector:broadcastChatMessage("Server"%_t, 2, "Pirates are attacking the sector!"%_t)
        AlertAbsentPlayers(2, "Pirates are attacking sector \\s(%1%:%2%)!"%_t, sector:getCoordinates())
    end

    function XPirateAttack.getUpdateInterval()
        return 5
    end

    function XPirateAttack.update(timeStep)

        if not XPirateAttack.attackersGenerated then return end

        -- check if all ships are still there
        -- ships might have changed sector or deleted in another way, which doesn't trigger destruction callback
        local sector = Sector()
        for id, _ in pairs(ships) do
            local pirate = sector:getEntity(id)
            if pirate == nil then
                ships[id] = nil
            end
        end

        -- if not -> end event
        if tablelength(ships) == 0 then
            XPirateAttack.endEvent()
        end
    end

    function XPirateAttack.onShipDestroyed(shipIndex)
        ships[shipIndex.string] = nil

        local ship = Entity(shipIndex)
        local damagers = {ship:getDamageContributors()}
        for _, damager in pairs(damagers) do
            local faction = Faction(damager)
            if faction and (faction.isPlayer or faction.isAlliance) then
                participants[damager] = damager
            end
        end
    end


    function XPirateAttack.endEvent()

        local faction = Galaxy():getLocalFaction(Sector():getCoordinates())
        if faction then

            local messages =
            {
                "Thank you for defeating those pirates. You have our endless gratitude."%_t,
                "We thank you for taking care of those ships. We have transferred a reward to your account."%_t,
                "Thank you for taking care of those pirates. We have transferred a reward to your account."%_t,
            }

            -- give payment to players/alliances who participated
            for _, participant in pairs(participants) do
                local participantFaction = Faction(participant)

                participantFaction:sendChatMessage(faction.name, 0, getRandomEntry(messages))
                participantFaction:receive("Received %1% Credits for defeating a pirate attack."%_T, reward)
                changeRelations(participantFaction, faction, reputation, RelationChangeType.CombatSupport, nil, nil, faction)

                local x, y = Sector():getCoordinates()
            end
        end

        terminate()
    end

end

