if onServer() then

    function FactionAttacksSmugglers.restore(data)
        terminate()
    end

    function FactionAttacksSmugglers.initialize()
        terminate()
    end

    function FactionAttacksSmugglers.spawnDefenders()
    end

    function FactionAttacksSmugglers.onDefendersGenerated(generated)
    end

    function FactionAttacksSmugglers.getUpdateInterval()
        return 60 * 60
    end

    function FactionAttacksSmugglers.update(timeStep)
        terminate()
    end

    function FactionAttacksSmugglers.handleSmugglersDefeated()
    end

    function FactionAttacksSmugglers.endEventSmugglersDefeated()
        terminate()
    end

end

if onClient() then

    function FactionAttacksSmugglers.createDefenderChatterBegin(id)
    end

    function FactionAttacksSmugglers.createDefenderChatterEnd(id)
    end

end
