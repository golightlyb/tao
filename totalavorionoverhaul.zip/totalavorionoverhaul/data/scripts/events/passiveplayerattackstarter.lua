if onServer() then

    function PassivePlayerAttackStarter.initialize()
        terminate()
    end

end
