if onServer() then

    function TraderAttackedByPirates.restore(data)
        terminate()
    end

    function TraderAttackedByPirates.initialize()
        terminate()
    end

    function TraderAttackedByPirates.getUpdateInterval()
        return 60 * 60
    end

    function TraderAttackedByPirates.onPiratesGenerated(generated)
    end

    function TraderAttackedByPirates.update(timeStep)
        terminate()
    end

    function TraderAttackedByPirates.onShotHit(objectIndex, shooterIndex)
    end

    function TraderAttackedByPirates.setAggressiveAndUnregister(id)

    function TraderAttackedByPirates.onShipDestroyed(shipIndex)
    end

    function TraderAttackedByPirates.onTraderShipDestroyed(shipIndex)
    end

    function TraderAttackedByPirates.endEvent()
        terminate()
    end

end
