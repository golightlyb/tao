if onServer() then

    function initialize(playerIndex, entityName)
        terminate()
    end

    function spawnPirates(entry)
        terminate()
    end

    function spawnFaction(faction, entry)
        terminate()
    end

    function onPiratesGenerated(ships)
        terminate()
    end

    function onFactionGenerated(ships)
        terminate()
    end

end

