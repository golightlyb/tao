
if onServer() then

    function PirateAttack.secure()
    end

    function PirateAttack.restore(data)
        terminate()
    end

    function PirateAttack.initialize()
        terminate()
    end

    function PirateAttack.getUpdateInterval()
        return 60 * 60
    end

    function PirateAttack.onPiratesGenerated(generated)
    end

    function PirateAttack.update(timeStep)
        terminate()
    end

    function PirateAttack.onShipDestroyed(shipIndex)
    end


    function PirateAttack.endEvent()
        terminate()
    end

end

if onClient() then

    function PirateAttack.onPiratesGenerated(id)
    end

end
