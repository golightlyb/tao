
package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include ("xUtil")
include ("xSectorUtil")
local SectorSpecifics = include ("SectorSpecifics")
local Placer = include("placer")
local ShipUtility = include("shiputility")
local ShipGenerator = include("shipgenerator")
local XSectorGenerator = include("xSectorGenerator")

local SectorTemplate = {}

function SectorTemplate.getProbabilityWeight(x, y, seed, factionIndex, innerArea)
    if factionIndex then
        if innerArea then
            return 50
        else
            return 100
        end
    else
        return 150
    end
end

function SectorTemplate.offgrid(x, y)
    return true
end

function SectorTemplate.gates(x, y)
    return false
end

function SectorTemplate.musicTracks()
    return xDefaultMusicTracks()
end

function SectorTemplate.getDefenders(contents, seed, x, y)
    return contents.faction, contents.defenders
end

-- this function returns what relevant contents there will be in the sector (exact)
function SectorTemplate.contents(x, y)

    --[preamble]----------------------------------------------------------------
    local seed = Seed(string.join({GameSeed(), x, y, "shatteredPlanet"}, "-"))
    math.randomseed(seed)
    local random = random()
    local contents = {seed = tostring(seed),}
    ----------------------------------------------------------------------------
    
    --[faction specifics]-------------------------------------------------------
    local faction
    if onServer() then
        faction = Galaxy():getLocalFaction(x, y)
    end
    local isCentral = Galaxy():isCentralFactionArea(x, y) and faction
    ----------------------------------------------------------------------------
    
    --[special feature]---------------------------------------------------------
    local specs = SectorSpecifics(x, y, GameSeed())
    local planets = {specs:generatePlanets()}
    local hasPlanet = (#planets > 0)
    ----------------------------------------------------------------------------
    
    --[contents]----------------------------------------------------------------
    local contents = {x={hasGates=SectorTemplate.gates(x,y)}}
    local stationCounts = {}
    local miners        = {}
    local garrison      = {}
    local events        = {}
    local style         = "Shattered Planet"
    
    if isCentral then
        style                           = "Faction Shattered Planet"
        miners                          = {{variant="miner",    number=random:getInt(1, 2)}}
        garrison                        = {{variant="garrison", number=random:getInt(1, 4)}}
        
        stationCounts.mines             = random:getInt(0, 3)
        stationCounts.refineries        = 1
        stationCounts.oreProcessors     = 1
        stationCounts.defensePlatforms  = random:getInt(0, 1)
        
        if hasPlanet then
            stationCounts.terrestrialTradingPosts = 1
        end
    elseif faction then
        style                           = "Faction Outskirts Shattered Planet"
        miners                          = {{variant="miner",    number=random:getInt(0, 1)}}
        garrison                        = {{variant="garrison", number=random:getInt(0, 1)}}
        events                          = {{variant="pirateAttack"}}
        
        stationCounts.mines             = random:getInt(0, 1)
        stationCounts.refineries        = random:getInt(0, 1)
        stationCounts.oreProcessors     = random:getInt(0, 1)
        stationCounts.defensePlatforms  = 1
    else
        events                          = {{variant="pirateAttack"}}
    end
    
    local stations = xSectorUtil_StationsFromCounts(stationCounts)
    ----------------------------------------------------------------------------
    
    ---[layout]-----------------------------------------------------------------
    local radius = getFloat(600, 900)
    local thickness = getFloat(150, 250)
    local depth = getFloat(8, 15)
    local additionalThickness = 100
    local asteroids = getFloat(50, 120)
    local p = 0.05
    if not isCentral then p = 0.075 end
    if not faction   then p = 0.100 end
    
    contents.x = {
        style    = style,
        events   = events,
        hasGates = true,
        features = {
            {
                variant = "shatteredPlanet",
                offset  = vec3(getFloat(-1000, 1000), -200, getFloat(-5000, -2000)),
                shapes = {
                    -- shatteredPlanet rings
                    {
                        variant   = "arc",
                        params    = {radius=radius, span=1.0, thickness=thickness, depth=depth, thickenOut=true},
                        asteroids = {number=asteroids, minSize=5, maxSize=15, probability=p},
                        ships     = miners,
                    },
                    {
                        variant   = "arc",
                        params    = {radius=radius, span=1.0, thickness=thickness + (additionalThickness * 1), depth=depth*2, thickenOut=true},
                        asteroids = {number=asteroids*2, minSize=5, maxSize=11, probability=p*2},
                    },
                    {
                        variant   = "arc",
                        params    = {radius=radius, span=1.0, thickness=thickness + (additionalThickness * 2), depth=depth*2, thickenOut=true},
                        asteroids = {number=asteroids*3, minSize=5, maxSize=9, probability=p*2},
                    },
                    {
                        variant   = "arc",
                        params    = {radius=radius, span=1.0, thickness=thickness + (additionalThickness * 3), depth=depth*2, thickenOut=true},
                        asteroids = {number=asteroids*4, minSize=3, maxSize=5, probability=0},
                    },
                    {
                        variant   = "arc",
                        params    = {radius=radius + (additionalThickness * 3), span=1.0, thickness=thickness, depth=depth*2, thickenOut=true},
                        stations  = stations,
                        ships     = garrison,
                    },
                },
            },
        },
    }
    ----------------------------------------------------------------------------
    
    --[sums]--------------------------------------------------------------------
    xSectorUtil_SetContentCounts(contents)
    return contents, random, faction, otherFaction
end

function SectorTemplate.generate(player, seed, x, y)
    local contents, random, faction, otherFaction = SectorTemplate.contents(x, y)
    XSectorGenerator(x, y, Sector(), faction, SectorTemplate.offgrid(x, y), random):createContents(contents)
    return {defenders = contents.defenders}
end

return SectorTemplate
