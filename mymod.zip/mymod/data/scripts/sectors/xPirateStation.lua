
package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include ("xUtil")
include ("xSectorUtil")
local SectorSpecifics = include ("SectorSpecifics")
local Placer = include("placer")
local ShipUtility = include("shiputility")
local ShipGenerator = include("shipgenerator")
local XSectorGenerator = include("xSectorGenerator")

local SectorTemplate = {}

function SectorTemplate.getProbabilityWeight(x, y, seed, factionIndex, innerArea)
    if factionIndex then
        if innerArea then
            return 0
        else
            return 50
        end
    else
        return 150
    end
end

function SectorTemplate.offgrid(x, y)
    return true
end

function SectorTemplate.gates(x, y)
    return true
end

function SectorTemplate.musicTracks()
    return xDefaultMusicTracks()
end

function SectorTemplate.getDefenders(contents, seed, x, y)
    return contents.faction, contents.defenders
end

-- this function returns what relevant contents there will be in the sector (exact)
function SectorTemplate.contents(x, y)

    --[preamble]----------------------------------------------------------------
    local seed = Seed(string.join({GameSeed(), x, y, "piratestation"}, "-"))
    math.randomseed(seed)
    local random = random()
    local contents = {seed = tostring(seed),}
    ----------------------------------------------------------------------------
    
    --[faction specifics]-------------------------------------------------------
    local faction, otherFaction
    if onServer() then
        faction = Galaxy():getPirateFaction(Balancing_GetPirateLevel(x, y) + 1)
        local sx = x + random:getInt(-15, 15)
        local sy = y + random:getInt(-15, 15)
        otherFaction = Galaxy():getNearestFaction(sx, sy)
    end
    ----------------------------------------------------------------------------
    
    --[contents]----------------------------------------------------------------
    local contents = {x={hasGates=false}}
    local stationCounts = {}
    local garrison      = {}
    local attackers     = {}
    local events        = {}
    local style = "Pirate Station"
    
    if otherFaction then
        style                       = "Contested Pirate Station"
        attackers                   = {{variant="antipirate", number=random:getInt(2, 5), faction=otherFaction}}
    end
    
    events                          = {{variant="pirateAttack"}}
    
    garrison                        = {{variant="pirate", defender=true, number=random:getInt(5, 11)}}

    stationCounts.fortresses        = random:getInt(0, 1)
    stationCounts.defensePlatforms  = random:getInt(0, 3)
    
    local stations = xSectorUtil_StationsFromCounts(stationCounts)
    ----------------------------------------------------------------------------
    
    ---[layout]-----------------------------------------------------------------
    
    -- stations along the inner curve of a long sector-sized ring
    local radius = getFloat(15000, 30000)
    local thickness = getFloat(600, 800)
    local depth = thickness/5
    local asteroids = getFloat(500, 1250)
    contents.x = {
        style  = style,
        events = events,
        shapes = {
            {
                variant   = "arc",
                params    = {radius=radius, span=0.1, thickness=thickness, depth=depth},
                offset    = vec3(0, -200, -radius),
                asteroids = {number=asteroids},
                mineTraps = random:getInt(1, 100),
                ships     = {{variant="miner", number=1}},
            },
            {
                variant   = "arc",
                params    = {radius=radius-thickness, span=0.05, thickness=50, depth/3},
                offset    = vec3(0, -200, -radius),
                stations  = stations,
                ships     = garrison,
            },
            {
                variant   = "arc",
                params    = {radius=radius-5000, span=0.05, thickness=50, depth/3},
                offset    = vec3(0, -200, -radius),
                ships     = attackers,
            },
        },
    }
    ----------------------------------------------------------------------------
    
    --[sums]--------------------------------------------------------------------
    xSectorUtil_SetContentCounts(contents)
    return contents, random, faction, otherFaction
end

function SectorTemplate.generate(player, seed, x, y)
    local contents, random, faction, otherFaction = SectorTemplate.contents(x, y)
    XSectorGenerator(x, y, Sector(), faction, SectorTemplate.offgrid(x, y), random):createContents(contents)
    return {defenders = contents.defenders}
end

return SectorTemplate
