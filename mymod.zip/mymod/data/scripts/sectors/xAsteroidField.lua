
package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include("xUtil")
local SectorSpecifics = include ("SectorSpecifics")
local SectorGenerator = include ("SectorGenerator")
local Placer = include("placer")
local ShipUtility = include("shiputility")
local ShipGenerator = include("shipgenerator")

local SectorTemplate = {}

function SectorTemplate.getProbabilityWeight(x, y, seed, factionIndex, innerArea)
    if factionIndex then
        if innerArea then
            return 50
        else
            return 200
        end
    else
        return 300
    end
end

function SectorTemplate.offgrid(x, y)
    return true
end

function SectorTemplate.gates(x, y)
    return false
end

function SectorTemplate.musicTracks()
    return xDefaultMusicTracks()
end

-- this function returns what relevant contents there will be in the sector (exact)
function SectorTemplate.contents(x, y)

    --[preamble]----------------------------------------------------------------
    local seed = Seed(string.join({GameSeed(), x, y, "asteroidfield"}, "-"))
    math.randomseed(seed)
    local random = random()
    local contents = {
        xSectorType="Asteroid Field",
        xOffGrid=true,
        xHasGates=false,
        seed = tostring(seed),
    }
    ----------------------------------------------------------------------------
    
    --[asteroids]---------------------------------------------------------------
    p = 0.15 -- richer because its an off-grid sector (default is 0.05)
    local small, medium, large = xUtilSmallAsteroidFieldStats(p), xUtilMediumAsteroidFieldStats(p), xUtilLargeAsteroidFieldStats(p)
    -- local withTraps = (random.getInt(1, 3) == 1)
    local withTraps = 0
    local numSmall, numMedium, numLarge
    contents.xAsteroidFields = {}
    numSmall  = random:getInt( 8, 15)
    numMedium = random:getInt( 3,  5)
    numLarge = 1
    for i = 1, numSmall do
        if withTraps then
            small.mineTraps = random:getInt(3, 6)
        end
        table.insert(contents.xAsteroidFields, small)
    end
    for i = 1, numMedium do
        if withTraps then
            medium.mineTraps = random:getInt(6, 12)
        end
        table.insert(contents.xAsteroidFields, medium)
    end
    for i = 1, numLarge do
        if withTraps then
            large.mineTraps = random:getInt(12, 24)
        end
        table.insert(contents.xAsteroidFields, large)
    end
    ----------------------------------------------------------------------------

    contents.xPirateAttacks     = true
    contents.asteroidEstimation = xUtilEstimateAsteroids(contents)
    contents.stations           = 0
    contents.ships              = 0
    
    return contents, random
end

function SectorTemplate.generate(player, seed, x, y)
    local contents, random, faction, otherFaction = SectorTemplate.contents(x, y)
    SectorGenerator(x, y):xFromContents(player, contents, random, faction, otherFaction)
end

return SectorTemplate
