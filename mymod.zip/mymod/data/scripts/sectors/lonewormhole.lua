function SectorTemplate.getProbabilityWeight(x, y, seed, factionIndex, innerArea)
    if factionIndex then
        if innerArea then
            return 25
        else
            return 50
        end
    else
        return 75
    end
end
