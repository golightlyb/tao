function SectorTemplate.getProbabilityWeight(x, y, seed, factionIndex, innerArea)
    if factionIndex then
        if innerArea then
            return 0 -- use colony instead
        else
            return 100
        end
    else
        return 0
    end
end
