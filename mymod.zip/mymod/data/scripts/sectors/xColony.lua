
package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include("xUtil")
local SectorSpecifics = include ("SectorSpecifics")
local SectorGenerator = include ("SectorGenerator")
local Placer = include("placer")
local ShipUtility = include("shiputility")
local ShipGenerator = include("shipgenerator")

local SectorTemplate = {}

function SectorTemplate.getProbabilityWeight(x, y, seed, factionIndex, innerArea)
    if factionIndex then
        if innerArea then
            return 450
        else
            return 150
        end
    else
        return 0
    end
end

function SectorTemplate.offgrid(x, y)
    return false
end

function SectorTemplate.gates(x, y)
    return true
end

function SectorTemplate.musicTracks()
    return xDefaultMusicTracks()
end

function SectorTemplate.getDefenders(contents, seed, x, y)
    return contents.faction, contents.defenders
end

-- this function returns what relevant contents there will be in the sector (exact)
function SectorTemplate.contents(x, y)

    --[preamble]----------------------------------------------------------------
    local seed = Seed(string.join({GameSeed(), x, y, "colony"}, "-"))
    math.randomseed(seed)
    local random = random()
    local contents = {
        xSectorType="Colony",
        xHasGates=SectorTemplate.gates(x,y),
        seed = tostring(seed),
    }
    ----------------------------------------------------------------------------
    
    --[faction specifics]-------------------------------------------------------
    local faction, otherFaction
    local isHeadquaters = false
    local neighbourIsFriendly = true -- exists if otherFaction
    local isCentral = Galaxy():isCentralFactionArea(x, y)
    if onServer() then
        faction = Galaxy():getLocalFaction(x, y) or Galaxy():getNearestFaction(x, y)
        
        local sx = x + random:getInt(-15, 15)
        local sy = y + random:getInt(-15, 15)
        otherFaction = Galaxy():getNearestFaction(sx, sy)
        if faction:getRelations(otherFaction.index) < -20000 then neighbourIsFriendly = false end

        -- create headquarters
        local hx, hy = faction:getHomeSectorCoordinates()

        if hx == x and hy == y then
            isHeadquaters = true
        end

        contents.faction = faction.index

        if otherFaction then
            contents.neighbor = otherFaction.index
        end
    end
    ----------------------------------------------------------------------------
    
    
    --[contents]----------------------------------------------------------------
    local _min = 0
    if isHeadquaters then
        _min = 1
    end
    
    contents.xSpacedock       = random:getInt(_min, 1)
    contents.xTraders         = random:getInt(_min, 2) -- OK anywhere
    
    if isCentral or isHeadquaters then
        contents.xFactories        = random:getInt(1, 3) -- any generic factory-production type
        contents.xDefensePlatforms = random:getInt(3, 6)
        contents.defenders         = 3
        if isHeadquaters then
            contents.xFortress = 1
        end
    else
        contents.xMines            = random:getInt(1, 3) -- any generic mine-production type
        contents.xRefinery         = random:getInt(0, 1)
        contents.xOreProcessor     = random:getInt(0, 1)
        contents.xRecycler         = random:getInt(0, 1)
        contents.xDefensePlatforms = random:getInt(1, 3)
        contents.defenders         = 1
        
        if otherFaction then
            contents.xNeighborTraders  = random:getInt(0, 1)
            if not neighbourIsFriendly then
                contents.xFortress = 1
            end
        end
    end
    if isHeadquaters then
        contents.defenders         = 6
        contents.xDefensePlatforms = 8
        contents.xSectorType="Headquaters"
    elseif isCentral then
        contents.xSectorType="Core Colony"
    else
        contents.xSectorType="Outer Colony"
        contents.xPirateAttacks = true
    end
    ----------------------------------------------------------------------------
    
    --[asteroids]---------------------------------------------------------------
    contents.xArc = {
        asteroids = {number=random:getInt(0, 1) * 1000},
        stashes   = random:getInt(0, 1) * random:getInt(0, 2)
    }
    contents.asteroidEstimation = 0 -- contents.xArc.Asteroids
    ----------------------------------------------------------------------------
    
    --[special feature]---------------------------------------------------------
    local specs = SectorSpecifics(x, y, GameSeed())
    local planets = {specs:generatePlanets()}
    if #planets > 0 and planets[1].type ~= PlanetType.BlackHole then
        contents.xTerrestrial = 1
    end
    ----------------------------------------------------------------------------
    
    contents.stations           = xUtilCountStations(contents)
    contents.ships              = contents.defenders
    
    return contents, random, faction, otherFaction
end

function SectorTemplate.generate(player, seed, x, y)
    local contents, random, faction, otherFaction = SectorTemplate.contents(x, y)
    SectorGenerator(x, y):xFromContents(player, contents, random, faction, otherFaction)
end

return SectorTemplate
