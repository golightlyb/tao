
package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include ("xUtil")
include ("xSectorUtil")
local SectorSpecifics = include ("SectorSpecifics")
local Placer = include("placer")
local ShipUtility = include("shiputility")
local ShipGenerator = include("shipgenerator")
local XSectorGenerator = include("xSectorGenerator")

local SectorTemplate = {}

function SectorTemplate.getProbabilityWeight(x, y, seed, factionIndex, innerArea)
    if factionIndex then
        if innerArea then
            return 450
        else
            return 150
        end
    else
        return 0
    end
end

function SectorTemplate.offgrid(x, y)
    return false
end

function SectorTemplate.gates(x, y)
    return true
end

function SectorTemplate.musicTracks()
    return xDefaultMusicTracks()
end

function SectorTemplate.getDefenders(contents, seed, x, y)
    return contents.faction, contents.defenders
end

-- this function returns what relevant contents there will be in the sector (exact)
function SectorTemplate.contents(x, y)

    --[preamble]----------------------------------------------------------------
    local seed = Seed(string.join({GameSeed(), x, y, "colony"}, "-"))
    math.randomseed(seed)
    local random = random()
    local contents = {seed = tostring(seed),}
    ----------------------------------------------------------------------------
    
    --[faction specifics]-------------------------------------------------------
    local faction, otherFaction
    local isHeadquaters = false
    local neighbourIsFriendly = true -- exists if otherFaction
    local isCentral = Galaxy():isCentralFactionArea(x, y)
    if onServer() then
        faction = Galaxy():getLocalFaction(x, y) or Galaxy():getNearestFaction(x, y)
        
        local sx = x + random:getInt(-15, 15)
        local sy = y + random:getInt(-15, 15)
        otherFaction = Galaxy():getNearestFaction(sx, sy)
        if faction:getRelations(otherFaction.index) < -20000 then neighbourIsFriendly = false end

        -- create headquarters
        local hx, hy = faction:getHomeSectorCoordinates()

        if hx == x and hy == y then
            isHeadquaters = true
        end

        contents.faction = faction.index

        if otherFaction then
            contents.neighbor = otherFaction.index
        end
    end
    ----------------------------------------------------------------------------
    
    --[special feature]---------------------------------------------------------
    local specs = SectorSpecifics(x, y, GameSeed())
    local planets = {specs:generatePlanets()}
    local hasPlanet = (#planets > 0)
    ----------------------------------------------------------------------------
    
    --[contents]----------------------------------------------------------------
    local contents = {x={hasGates=SectorTemplate.gates(x,y)}}
    local stationCounts = {}
    local garrison      = {}
    local events        = {}
    local style = "Colony"
    
    if isHeadquaters then
        style                           = "Headquarters"
        garrison                        = {{variant="garrison", number=random:getInt(5, 6)}}
        
        stationCounts.spacedocks        = 1
        stationCounts.fortresses        = 1
        stationCounts.tradingPosts      = 1
        stationCounts.defensePlatforms  = random:getInt(3, 4)
    elseif isCentral then
        style                           = "Core Colony"
        garrison                        = {{variant="garrison", number=random:getInt(3, 4)}}
        
        stationCounts.spacedocks        = random:getInt(0, 1)
        stationCounts.factories         = random:getInt(1, 4)
        stationCounts.tradingPosts      = random:getInt(0, 2)
    else
        style                           = "Outer Colony"
        garrison                        = {{variant="garrison", number=random:getInt(1, 2)}}
        
        events                         = {{variant="pirateAttack"}}
        
        stationCounts.mines             = random:getInt(1, 3)
        stationCounts.refineries        = random:getInt(0, 1)
        stationCounts.oreProcessors     = random:getInt(0, 1)
        stationCounts.recyclers         = random:getInt(0, 1)
        stationCounts.defensePlatforms  = random:getInt(0, 2)
        stationCounts.tradingPosts      = random:getInt(0, 1)
    end
    
    if otherFaction and not neighbourIsFriendly then
        stationCounts.fortresses = 1
    end
    if hasPlanet then
        stationCounts.tradingPosts = math.min(1, stationCounts.tradingPosts)
        stationCounts.terrestrialTradingPosts = 1
    end
    
    local stations = xSectorUtil_StationsFromCounts(stationCounts)
    if otherFaction and neighbourIsFriendly then
        table.insert(stations, {variant="tradingPost", faction=otherFaction})
    end
    ----------------------------------------------------------------------------
    
    ---[layout]-----------------------------------------------------------------
    
    -- stations along the inner curve of a long sector-sized ring
    local radius = getFloat(15000, 30000)
    local thickness = getFloat(600, 800)
    local depth = thickness/5
    local asteroids = getFloat(500, 1250)
    contents.x = {
        events = events,
        style  = style,
        shapes = {
            {
                variant   = "arc",
                params    = {radius=radius, span=0.1, thickness=thickness, depth=depth},
                offset    = vec3(0, -200, -radius),
                asteroids = {number=asteroids},
                ships     = {{variant="miner", number=1}},
            },
            {
                variant   = "arc",
                params    = {radius=radius-thickness, span=0.05, thickness=50, depth/3},
                offset    = vec3(0, -200, -radius),
                stations  = stations,
                ships     = garrison,
            },
        },
    }
    ----------------------------------------------------------------------------
    
    --[sums]--------------------------------------------------------------------
    xSectorUtil_SetContentCounts(contents)
    return contents, random, faction, otherFaction
end

function SectorTemplate.generate(player, seed, x, y)
    local contents, random, faction, otherFaction = SectorTemplate.contents(x, y)
    XSectorGenerator(x, y, Sector(), faction, SectorTemplate.offgrid(x, y), random):createContents(contents)
    return {defenders = contents.defenders}
end

return SectorTemplate
