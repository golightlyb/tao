
package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include ("xUtil")
include ("xSectorUtil")
local SectorSpecifics = include ("SectorSpecifics")
local Placer = include("placer")
local ShipUtility = include("shiputility")
local ShipGenerator = include("shipgenerator")
local XSectorGenerator = include("xSectorGenerator")

local SectorTemplate = {}

function SectorTemplate.getProbabilityWeight(x, y, seed, factionIndex, innerArea)
    if factionIndex then
        if innerArea then
            return 50
        else
            return 100
        end
    else
        return 450
    end
end

function SectorTemplate.offgrid(x, y)
    return true
end

function SectorTemplate.gates(x, y)
    return false
end

function SectorTemplate.musicTracks()
    return xDefaultMusicTracks()
end

function SectorTemplate.getDefenders(contents, seed, x, y)
    return contents.faction, contents.defenders
end

-- this function returns what relevant contents there will be in the sector (exact)
function SectorTemplate.contents(x, y)

    --[preamble]----------------------------------------------------------------
    local seed = Seed(string.join({GameSeed(), x, y, "asteroidRing"}, "-"))
    math.randomseed(seed)
    local random = random()
    local contents = {seed = tostring(seed),}
    ----------------------------------------------------------------------------
    
    --[faction specifics]-------------------------------------------------------
    local faction
    if onServer() then
        faction = Galaxy():getLocalFaction(x, y)
    end
    local isCentral = Galaxy():isCentralFactionArea(x, y) and faction
    ----------------------------------------------------------------------------
    
    --[special feature]---------------------------------------------------------
    local specs = SectorSpecifics(x, y, GameSeed())
    local planets = {specs:generatePlanets()}
    local hasPlanet = (#planets > 0)
    ----------------------------------------------------------------------------
    
    --[contents]----------------------------------------------------------------
    local contents      = {}
    local stationCounts = {}
    local miners        = {}
    local garrison      = {}
    local events        = {}
    local style         = "Asteroid Ring"
    
    if isCentral then
        style                           = "Faction Asteroid Ring"
        miners                          = {{variant="miner",    number=random:getInt(1, 2)}}
        garrison                        = {{variant="garrison", number=random:getInt(1, 4)}}
        
        stationCounts.mines             = random:getInt(0, 3)
        stationCounts.refineries        = 1
        stationCounts.oreProcessors     = 1
        stationCounts.defensePlatforms  = random:getInt(0, 1)
        
        if hasPlanet then
            stationCounts.terrestrialTradingPosts = 1
        end
    elseif faction then
        style                           = "Faction Outskirts Asteroid Ring"
        miners                          = {{variant="miner",    number=random:getInt(0, 1)}}
        garrison                        = {{variant="garrison", number=random:getInt(0, 1)}}
        events                          = {{variant="pirateAttack"}}
        
        stationCounts.mines             = random:getInt(0, 1)
        stationCounts.refineries        = random:getInt(0, 1)
        stationCounts.oreProcessors     = random:getInt(0, 1)
        stationCounts.defensePlatforms  = 1
    else
        events                          = {{variant="pirateAttack"}}
    end
    
    local stations = xSectorUtil_StationsFromCounts(stationCounts)
    ----------------------------------------------------------------------------
    
    ---[layout]-----------------------------------------------------------------
    local radius = getFloat(15000, 30000)
    local thickness = getFloat(600, 800)
    local depth = getFloat(100, 200)
    local asteroids = getFloat(500, 1250)
    local p = 0.05
    local mineTraps = 0
    local stashes   = 0
    if not isCentral then p = 0.075 end
    if not faction   then p = 0.100 end
    if not faction   then mineTraps = getInt(1, 100) end
    if not faction   then stashes = getInt(0, 5) end
    
    contents.x = {
        hasGates=SectorTemplate.gates(x,y),
        style    = style,
        events   = events,
        hasGates = true,
        shapes = {
            -- long sector-sized ring
            {
                variant   = "arc",
                params    = {radius=radius, span=0.1, thickness=thickness, depth=depth},
                offset    = vec3(0, -200, -radius),
                asteroids = {number=asteroids, probability=p},
                mineTraps = mineTraps,
                stashes   = stashes,
                ships     = miners,
            },
            -- an inner arc where stations are
            {
                name      = "Large Asteroid Ring",
                variant   = "arc",
                params    = {radius=radius - (thickness * 2), span=0.05, thickness=50, depth=depth/3},
                offset    = vec3(0, -200, -radius),
                stations  = stations,
                ships     = garrison,
            },
        },
    }
    ----------------------------------------------------------------------------
    
    --[sums]--------------------------------------------------------------------
    xSectorUtil_SetContentCounts(contents)
    return contents, random, faction, otherFaction
end

function SectorTemplate.generate(player, seed, x, y)
    local contents, random, faction, otherFaction = SectorTemplate.contents(x, y)
    XSectorGenerator(x, y, Sector(), faction, SectorTemplate.offgrid(x, y), random):createContents(contents)
    return {defenders = contents.defenders}
end

return SectorTemplate
