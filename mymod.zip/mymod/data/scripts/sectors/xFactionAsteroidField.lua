
package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include("xUtil")
local SectorSpecifics = include ("SectorSpecifics")
local SectorGenerator = include ("SectorGenerator")
local Placer = include("placer")
local ShipUtility = include("shiputility")
local ShipGenerator = include("shipgenerator")

local SectorTemplate = {}

function SectorTemplate.getProbabilityWeight(x, y, seed, factionIndex, innerArea)
    if factionIndex then
        if innerArea then
            return 50
        else
            return 300
        end
    else
        return 0
    end
end

function SectorTemplate.offgrid(x, y)
    return false
end

function SectorTemplate.gates(x, y)
    return true
end

function SectorTemplate.musicTracks()
    return xDefaultMusicTracks()
end

-- this function returns what relevant contents there will be in the sector (exact)
function SectorTemplate.contents(x, y)

    --[preamble]----------------------------------------------------------------
    local seed = Seed(string.join({GameSeed(), x, y, "factionasteroidfield"}, "-"))
    math.randomseed(seed)
    local random = random()
    local contents = {
        xSectorType="Faction Asteroid Field",
        xHasGates=SectorTemplate.gates(x,y),
        seed = tostring(seed),
    }
    ----------------------------------------------------------------------------
    
    --[faction specifics]-------------------------------------------------------
    local faction
    if onServer() then
        faction = Galaxy():getLocalFaction(x, y) or Galaxy():getNearestFaction(x, y)
    end
    ----------------------------------------------------------------------------
    
    --[asteroids]---------------------------------------------------------------
    local small, medium, large = xUtilSmallAsteroidFieldStats(), xUtilMediumAsteroidFieldStats(), xUtilLargeAsteroidFieldStats()
    local numSmall, numMedium, numLarge
    contents.xAsteroidFields = {}
    numSmall  = random:getInt( 8, 15)
    numMedium = random:getInt( 3,  5)
    numLarge = 1
    for i = 1, numSmall do
        table.insert(contents.xAsteroidFields, small)
    end
    for i = 1, numMedium do
        table.insert(contents.xAsteroidFields, medium)
    end
    for i = 1, numLarge do
        table.insert(contents.xAsteroidFields, large)
    end
    ----------------------------------------------------------------------------

    --[special feature]---------------------------------------------------------
    local specs = SectorSpecifics(x, y, GameSeed())
    local planets = {specs:generatePlanets()}
    if #planets > 0 and planets[1].type ~= PlanetType.BlackHole then
        contents.xTerrestrial = 1
        contents.xDefensePlatforms = 3
    end
    ----------------------------------------------------------------------------
    
    contents.xPirateAttacks     = true
    
    n = random:getInt(1, 3)
    if n == 1 then
        contents.xOreProcessor = 1
    elseif n == 2 then
        contents.xRefinery = 1
    else
        contents.xRefinery = 1
        contents.xOreProcessor = 1
    end
    
    contents.asteroidEstimation = xUtilEstimateAsteroids(contents)
    contents.stations           = xUtilCountStations(contents)
    contents.xMiningShips       = 1
    contents.ships              = 1 -- miner
    
    return contents, random, faction
end

function SectorTemplate.generate(player, seed, x, y)
    local contents, random, faction, otherFaction = SectorTemplate.contents(x, y)
    SectorGenerator(x, y):xFromContents(player, contents, random, faction, otherFaction)
end

return SectorTemplate
