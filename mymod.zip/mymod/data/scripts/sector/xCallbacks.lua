
package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"
include("xUtil")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace SectorCallbacks
SectorCallbacks = {}

function SectorCallbacks.initialize()
    local s = Sector()
    s:registerCallback("onSectorGenerated", "onSectorGenerated")
end

function SectorCallbacks.onSectorGenerated(...)
    local g = Galaxy()
    local s = Sector()
    -- local x, y = s:getCoordinates()
    
    -- TODO: could age the cache here and evict old entries
    
    xPlanCache_PrintStats(g)
end

