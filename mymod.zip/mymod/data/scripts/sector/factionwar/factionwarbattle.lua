local ShipGenerator = include("shipgenerator")
local SectorTurretGenerator = include("sectorturretgenerator")

function FactionWarBattle.spawnShips(faction)
    print("spawning faction war ships")
    
    local x, y = Sector():getCoordinates()

    local position = random():getDirection() * 1500
    local dir = normalize(-position)
    local up = vec3(0, 1, 0)
    local right = normalize(cross(up, dir))
    up = normalize(cross(right, dir))

    -- while not async, generation should be very quick using the plan cache
    
    local x, y = Sector():getCoordinates()
    local turretGenerator = SectorTurretGenerator()
    local cannon = turretGenerator:generate(x, y, 0, Rarity(RarityType.Exceptional), WeaponType.XCannon)

    local defenderArms = {
        --{turret=gun,     num=4, limit=8},
        --{turret=missile, num=1, limit=2},
        {turret=cannon,  num=3, limit=6},
    }
    
    local ships = {}
    for i = -4, 4 do
        local mat = MatrixLookUpPosition(look, up, position + right * 100 * i)
        local ship = ShipGenerator.xCreateDefender(faction,pos, defenderArms, "Assault")
        ship:removeScript("entity/antismuggle.lua")
        ship:addScriptOnce("data/scripts/sector/factionwar/temporarydefender.lua")
        table.insert(ships, ship)
    end
    Placer.resolveIntersections(ships)
    
    wavesSpawned = wavesSpawned + 1
end