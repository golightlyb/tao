if onServer() then

function RespawnTeleporter.initialize()
end

end

