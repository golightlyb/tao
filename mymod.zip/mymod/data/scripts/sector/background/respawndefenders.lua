local ShipUtility = include("shiputility")
local Placer = include("placer")
local XSectorGenerator = include("xSectorGenerator")

function RespawnDefenders.updateServer(timeStep)
    if numDefenders == 0 then return end
    if defenderFactionIndex == 0 then return end

    -- actually tick once every 15 minutes
    local updateInterval = 15 * 60

    updateTimer = (updateTimer or 0) + timeStep
    if updateTimer < updateInterval then return end
    updateTimer = updateTimer - updateInterval

    local sector = Sector()
    if not sector then return end

    -- initialize values?
    if numDefenders == nil or defenderFactionIndex == nil then
        RespawnDefenders.calculateSectorDefenders()

        if numDefenders == 0 then return end
        if defenderFactionIndex == 0 then return end
    end

    if FactionEradicationUtility.isFactionEradicated(defenderFactionIndex) then
        return
    end

    -- no respawning of defenders when there are no stations left
    if not RespawnDefenders.hasStations(defenderFactionIndex) then
        return
    end

    -- count current defenders
    local numCurrentDefenders = 0
    for _, defender in pairs({sector:getEntitiesByScriptValue("is_defender", true)}) do
        if defender.factionIndex == defenderFactionIndex then
            numCurrentDefenders = numCurrentDefenders + 1
        end
    end

    if updateTimer >= updateInterval then
        -- the last update was at least 2 * updateInterval ago
        -- respawn defenders right away
        updateTimer = 0
        missingLastTick = math.max(missingLastTick or 0, numDefenders - numCurrentDefenders)
    end

    local faction
    local respawnAmount = 0
    if missingLastTick and missingLastTick > 0 then
        faction = Faction(defenderFactionIndex)
        if not faction then
--            print("faction doesn't exist")
            return
        end

        respawnAmount =  missingLastTick
    end

    if respawnAmount > 0 then
        local x, y = sector:getCoordinates()
        print("respawning %i defenders at %i, %i", respawnAmount, x, y)
        -- respawn defenders
        local ships = {}

--        print("generate " .. respawnAmount .. " defenders")
        local generator = XSectorGenerator(x, y, Sector(), faction, true, random)

        local ships = {}
        local function post(ship)
            if specialHandling == "noAntiSmuggle" then
                ship:removeScript("antismuggle.lua")
            end
            table.insert(ships, ship)
        end
        
        generator:createContents({
            x = {
                noSector = true,
                shapes = {
                    {
                        variant   = "arc",
                        params = {radius=200, span=1.0, thickness=100, depth=20},
                        offset = vec3(random:getFloat(-1000, 1000), random:getFloat(-100, 100), random:getFloat(-1000, 1000)),
                        ships  = {
                            {variant="garrison", number=6, post=post},
                        },
                    },
                },
            },
        })

        Placer.resolveIntersections(ships)

        missingLastTick = nil
        return
    end

    missingLastTick = numDefenders - numCurrentDefenders

--    print("missing defenders: " .. tostring(missingLastTick))


    if missingLastTick <= 0 then missingLastTick = nil end
end
