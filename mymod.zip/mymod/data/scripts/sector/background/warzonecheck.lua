local SectorTurretGenerator = include("sectorturretgenerator")
local Placer = include("placer")
local ShipGenerator = include("shipgenerator")
local SectorGenerator = include("sectorgenerator")

if onServer() then

    function WarZoneCheck.onDestroyed(destroyedId, destroyerId)

        local victim = Entity(destroyedId)
        if not victim then return end

        if victim:getValue("is_pirate") then return end
        if victim:getValue("is_xsotan") then return end
        if victim:getValue("is_persecutor") then return end
        if not victim.type == EntityType.Fighter then return end
        if not victim.type == EntityType.Drone then return end
        if not victim:hasComponent(ComponentType.Plan) then return end
        if not victim:hasComponent(ComponentType.Durability) then return end
        if victim.type == 0 then return end -- added

        local factor = 1

        -- don't overpunish players who already lost ships/stations by immediately calling out a warzone
        if victim.playerOwned or victim.allianceOwned then
            factor = 0.2
        end

        if victim.isStation then
            WarZoneCheck.increaseScore(100 * factor)
        else
            if Sector():getNumEntitiesByType(EntityType.Station) == 0 then return end

            local destroyer = Entity(destroyerId)
            if destroyer then
                -- less influence from pirates and xsotan
                if destroyer:getValue("is_pirate") then factor = math.min(factor, 0.25) end
                if destroyer:getValue("is_xsotan") then factor = math.min(factor, 0.25) end
                if destroyer:getValue("is_persecutor") then factor = math.min(factor, 0.25) end

                if destroyer.playerOwned or destroyer.allianceOwned then
                    -- weigh player factions normally
                    WarZoneCheck.increaseScore(40 * factor)
                else
                    -- weigh AI factions less for increased influence of players
                    WarZoneCheck.increaseScore(10 * factor)
                end
            end
        end

    end

    function WarZoneCheck.spawnReinforcements()

        local sector = Sector()
        -- safeguard: if there are already reinforcements for some reason, don't spawn new ones
        if sector:getEntitiesByScriptValue("war_zone_reinforcement") then return end

        
        -- to spawn reinforcements, sector must be controlled by an AI faction
        local x, y = sector:getCoordinates()
        local faction = Galaxy():getControllingFaction(x, y)
        if not faction or not faction.isAIFaction then return end
        local generator = SectorGenerator(x, y)

        if FactionEradicationUtility.isFactionEradicated(faction.index) then return end

        local turretGenerator = SectorTurretGenerator()
        local cannon = turretGenerator:generate(x, y, 0, Rarity(RarityType.Exceptional), WeaponType.XCannon)

        local defenderArms = {
            --{turret=gun,     num=4, limit=8},
            --{turret=missile, num=1, limit=2},
            {turret=cannon,  num=3, limit=6},
        }
        
        local dir = random():getDirection()
        local position = generator:getPositionInSector()
        local up = vec3(0, 1, 0)
        local look = -dir
        local right = normalize(cross(dir, up))

        for i = -3, 3 do
            local mat = MatrixLookUpPosition(look, up, position + right * 100 * i)
            local ship = ShipGenerator.xCreateDefender(faction, mat, defenderArms, "Reinforcement")
            ship:removeScript("entity/antismuggle.lua")
            ship:setValue("war_zone_reinforcement", true)
            table.insert(ships, ship)
        end
        Placer.resolveIntersections(ships)

        -- for unit tests
        WarZoneCheck.reinforcementsRequested = 7
    end

end