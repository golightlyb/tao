local SectorTurretGenerator = include("sectorturretgenerator")
local Placer = include("placer")
local ShipGenerator = include("shipgenerator")

if onServer() then
    function WarZoneCheck.spawnReinforcements()

        local sector = Sector()
        -- safeguard: if there are already reinforcements for some reason, don't spawn new ones
        if sector:getEntitiesByScriptValue("war_zone_reinforcement") then return end

        -- to spawn reinforcements, sector must be controlled by an AI faction
        local x, y = sector:getCoordinates()
        local faction = Galaxy():getControllingFaction(x, y)
        if not faction or not faction.isAIFaction then return end

        if FactionEradicationUtility.isFactionEradicated(faction.index) then return end

        local turretGenerator = SectorTurretGenerator()
        local cannon = turretGenerator:generate(x, y, 0, Rarity(RarityType.Exceptional), WeaponType.XCannon)

        local defenderArms = {
            --{turret=gun,     num=4, limit=8},
            --{turret=missile, num=1, limit=2},
            {turret=cannon,  num=3, limit=6},
        }
        
        local dir = random():getDirection()
        local position = generator:getPositionInSector()
        local up = vec3(0, 1, 0)
        local look = -dir
        local right = normalize(cross(dir, up))

        for i = -3, 3 do
            local mat = MatrixLookUpPosition(look, up, position + right * 100 * i)
            local ship = ShipGenerator.xCreateDefender(faction, mat, defenderArms, "Reinforcement")
            ship:removeScript("entity/antismuggle.lua")
            ship:setValue("war_zone_reinforcement", true)
            table.insert(ships, ship)
        end
        Placer.resolveIntersections(ships)

        -- for unit tests
        WarZoneCheck.reinforcementsRequested = 7
    end

end