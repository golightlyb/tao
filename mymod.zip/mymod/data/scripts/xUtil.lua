include("music")

function xUtilGaussian(mean, variance)
    -- from https://rosettacode.org/wiki/Statistics/Normal_distribution#Lua
    return math.sqrt(-2 * variance * math.log(math.random())) * math.cos(2 * math.pi * math.random()) + mean
end

function xUtilCountStations(contents)
    local sum = 0
    sum = sum + (contents.xFortress or 0)
    sum = sum + (contents.xSpacedock or 0)
    sum = sum + (contents.xTraders or 0)
    sum = sum + (contents.xNeighbourTraders or 0)
    sum = sum + (contents.xTerrestrial or 0)
    sum = sum + (contents.xRefinery or 0)
    sum = sum + (contents.xOreProcessor or 0)
    sum = sum + (contents.xFactories or 0)
    sum = sum + (contents.xMines or 0)
    sum = sum + (contents.xRecycler or 0)
    sum = sum + (contents.xDefensePlatforms or 0)
    return sum
end

function xUtilEstimateAsteroids(contents)
    return 0 -- deprecated
end

function xDefaultMusicTracks()
    local good = {
        primary = TrackCollection.HappyNeutral(),
        secondary = combine(TrackCollection.Happy(), TrackCollection.Neutral()),
    }

    local neutral = {
        primary = TrackCollection.Neutral(),
        secondary = TrackCollection.All(),
    }

    local bad = {
        primary = combine(TrackCollection.Middle(), TrackCollection.Desolate()),
        secondary = TrackCollection.Neutral(),
    }

    return good, neutral, bad
end

function xPlanCache_FromFile(galaxy, path)
    local ok, plan = galaxy:invokeFunction("xPlanCache.lua", "FromFile", path)
    if not ok then
        eprint("xUtil: xPlanCache_FromFile: invokeFunction failed")
        return nil
    end
    return plan
end

function xPlanCache_PrintStats(galaxy)
    local ok, plan = galaxy:invokeFunction("xPlanCache.lua", "PrintStats", path)
    if not ok then
        eprint("xUtil: xPlanCache_PrintStats: invokeFunction failed")
        return nil
    end
    return plan
end

function xPlanCache_Generated(galaxy, planType, faction, volume, styleName, material)
    local ok, plan = galaxy:invokeFunction("xPlanCache.lua", "Generated", planType, faction, volume, styleName, material)
    if not ok then
        eprint("xUtil: xPlanCache_Generated: invokeFunction failed")
        return nil
    end
    return plan
end