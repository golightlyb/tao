function xUtilCountStations(contents)
    local sum = 0
    sum = sum + (contents.xSpacedock or 0)
    sum = sum + (contents.xTraders or 0)
    sum = sum + (contents.xNeighbourTraders or 0)
    sum = sum + (contents.xTerrestrial or 0)
    sum = sum + (contents.xRefinery or 0)
    sum = sum + (contents.xOreProcessor or 0)
    sum = sum + (contents.xFactories or 0)
    sum = sum + (contents.xMines or 0)
    sum = sum + (contents.xRecycler or 0)
    sum = sum + (contents.xDefensePlatforms or 0)
    return sum
end