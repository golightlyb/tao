include("music")

function xUtilCountStations(contents)
    local sum = 0
    sum = sum + (contents.xFortress or 0)
    sum = sum + (contents.xSpacedock or 0)
    sum = sum + (contents.xTraders or 0)
    sum = sum + (contents.xNeighbourTraders or 0)
    sum = sum + (contents.xTerrestrial or 0)
    sum = sum + (contents.xRefinery or 0)
    sum = sum + (contents.xOreProcessor or 0)
    sum = sum + (contents.xFactories or 0)
    sum = sum + (contents.xMines or 0)
    sum = sum + (contents.xRecycler or 0)
    sum = sum + (contents.xDefensePlatforms or 0)
    return sum
end

function xUtilEstimateAsteroids(contents)
    --[[
    contents.asteroidFields == {
        number, -- vanilla is (25 to 75), (263 to 438), (450 to 750)
        radius, -- vanilla is 360 to 2250
        minSize, -- vanilla is 5
        maxSize, -- vanilla is 25
        probability, -- vanilla is 0.05
        stash, -- chance 0 to 1
        claimable, -- chance 0 to 1
    }
    
    normally, the generator lerps (0 to 0.4) between minSize and maxSize,
    but also randomly generates barren rocks by lerping from 0 to 1.0.
    This means that average resource asteroid size is (minSize + (0.2 x maxSize)).
    --]]
    local sum = 0
    if contents.xAsteroidFields then
        for i = 1, #contents.xAsteroidFields do
            sum = sum + contents.xAsteroidFields[i].number
        end
    end
    return math.ceil(sum)
end

function xUtilSmallAsteroidFieldStats(p, pStash, pClaim)
    -- small asteroid field rebalanced with reduced maxSize
    
    -- average size = (minSize + (0.2 x maxSize)
    -- old size = (5 + (0.2 * 25)) = 10
    -- new size = (5 + (0.2 * 15)) =  8
    -- so base probability of 0.05 is increased by 25% = 0.0625

    if p == nil then p = 0.0625 end -- rebalanced
    if pStash == nil then pStash = 0.01 end
    if pClaim == nil then pClaim = 0 end
    
    local n = getInt(25, 75)
    local d = getInt(3, 5)
    return {
        number      = n,               -- vanilla is fine
        radius      = 100 + (n * d),
        minSize     = 5,               -- vanilla is fine
        maxSize     = 15,              -- smaller than vanilla
        probability = p,
        stash       = pStash,
        claim       = pClaim,
        mineTraps   = 0,
    }
end

function xUtilMediumAsteroidFieldStats(p, pStash, pClaim)
    -- half the asteroids compared to vanilla, so for same p, increase
    -- the minimum and maximum asteroid size to balance.

    -- average size = (minSize + (0.2 x maxSize)
    -- old size = (5 + (0.2 * 25)) = 10
    -- new size = (a + (0.2 *  b)) = 20 -- twice old average size
    -- for, say, a =10, then b = 50
    
    if p == nil then p = 0.05 end -- vanilla is fine
    if pStash == nil then pStash = 0.05 end
    if pClaim == nil then pClaim = 0.01 end

    local n = getInt(130, 215)
    local d = getInt(4, 6)
    return {
        number      = n,                -- about half
        radius      = 500 + (n * d),
        minSize     = 10,               -- rebalanced
        maxSize     = 50,               -- rebalanced
        probability = p,
        stash       = pStash,
        claim       = pClaim,
        mineTraps   = 0,
    }
end

function xUtilLargeAsteroidFieldStats(p, pStash, pClaim)
    -- one third of the asteroids compared to vanilla, so for same p, increase
    -- the minimum and maximum asteroid size to balance.

    -- average size = (minSize + (0.2 x maxSize)
    -- old size = (5 + (0.2 * 25)) = 10
    -- new size = (a + (0.2 *  b)) = 30 -- thrice old average size
    -- for, say, a =15, then b = 75
    
    if p == nil then p = 0.05 end -- vanilla is fine
    if pStash == nil then pStash = 0.10 end
    if pClaim == nil then pClaim = 0.05 end

    local n = getInt(200, 250)
    local d = getInt(4, 6)
    return {
        number      = n,              -- about a third
        radius      = 800 + (n * d),
        minSize     = 15,           -- rebalanced
        maxSize     = 75,            -- rebalanced
        probability = p,
        stash       = pStash,
        claim       = pClaim,
        mineTraps   = 0,
    }
end

function xDefaultMusicTracks()
    local good = {
        primary = TrackCollection.HappyNeutral(),
        secondary = combine(TrackCollection.Happy(), TrackCollection.Neutral()),
    }

    local neutral = {
        primary = TrackCollection.Neutral(),
        secondary = TrackCollection.All(),
    }

    local bad = {
        primary = combine(TrackCollection.Middle(), TrackCollection.Desolate()),
        secondary = TrackCollection.Neutral(),
    }

    return good, neutral, bad
end

function xPlanCache_FromFile(galaxy, path)
    local ok, plan = galaxy:invokeFunction("xPlanCache.lua", "FromFile", path)
    if not ok then
        eprint("xUtil: xPlanCache_FromFile: invokeFunction failed")
        return nil
    end
    return plan
end

function xPlanCache_PrintStats(galaxy)
    local ok, plan = galaxy:invokeFunction("xPlanCache.lua", "PrintStats", path)
    if not ok then
        eprint("xUtil: xPlanCache_PrintStats: invokeFunction failed")
        return nil
    end
    return plan
end

function xPlanCache_Generated(galaxy, planType, faction, volume, styleName, material)
    local ok, plan = galaxy:invokeFunction("xPlanCache.lua", "Generated", planType, faction, volume, styleName, material)
    if not ok then
        eprint("xUtil: xPlanCache_Generated: invokeFunction failed")
        return nil
    end
    return plan
end