
function xSectorUtil_StationsFromCounts(s)
    -- input counts such as {spacedock=2}
    -- output {{variant="spacedock"}, {variant="spacedock"}}

    local function __each(t, variant, number)
        if not number then return end
        for i = 1, number do
            table.insert(t, {variant=variant})
        end
    end

    local stations = {}
    
    __each(stations, "spacedock",       s.spacedocks)
    __each(stations, "fortress",        s.fortresses)
    __each(stations, "oreProcessor",    s.oreProcessors)
    __each(stations, "tradingPost",     s.tradingPosts)
    __each(stations, "terrestrial",     s.terrestrialTradingPosts)
    __each(stations, "recycler",        s.recyclers)
    __each(stations, "defensePlatform", s.defensePlatforms)

    if s.mines then
        table.insert(stations, {variant="mines", number=s.mines})
    end
    if s.factories then
        table.insert(stations, {variant="factories", number=s.factories})
    end
    
    return stations
end

function xSectorUtil_CountTotal(xs)
    -- input e.g. {{variant="spacedock"}, {variant="mines", number=2}}
    -- output number e.g. 3
    if not xs then return 0 end
    local sum = 0
    for i = 1, #xs do
        local x = xs[i]
        if x.number == nil then
            sum = sum + 1
        else
            sum = sum + x.number
        end
    end
    return sum
end

function xSectorUtil_WalkShapes(shapes, visit)
    -- call visitor for each stations entry in an array of arcs
    shapes = shapes or {}
    for i = 1, #shapes do
        visit(shapes[i])
    end
end

function xSectorUtil_WalkContentShapes(content, visit)
    -- call visitor for each shape entry in a sector content object
    content = content or {}
    local x = content.x or {}
    local features = x.features or {}
    for i = 1, #features do
        local feature = features[i]
        xSectorUtil_WalkShapes(feature.shapes, visit)
    end
    xSectorUtil_WalkShapes(x.shapes, visit)
end

function xSectorUtil_CountsFromContent(content, key)
    -- count each variant type from a sector content object
    local counts = {}
    local total = 0
    
    local function visit(shape)
        local xs = shape[key]
        if not xs then return end
        for i = 1, #xs do
            local x = xs[i]
            local variant = x.variant
            local number = 1
            if x.number then number = x.number end
            counts[variant] = (counts[variant] or 0) + number
            total = total + number
        end
    end

    xSectorUtil_WalkContentShapes(content, visit)
    
    return counts, total
end

function xSectorUtil_TotalDefenders(content)
    local defenders = 0
    
    local function visit(shape)
        local xs = shape.ships
        if not xs then return end
        for i = 1, #xs do
            local x = xs[i]
            local variant = x.variant
            local number = 1
            if x.number then number = x.number end
            if (variant == "garrison") or x.defender then
                defenders = defenders + number
            end
        end
    end
    
    xSectorUtil_WalkContentShapes(content, visit)
    
    return defenders
end

function xSectorUtil_TotalShips(content)
    _, total = xSectorUtil_CountsFromContent(content, "ships")
    return total
end

function xSectorUtil_TotalStations(content)
    _, total = xSectorUtil_CountsFromContent(content, "stations")
    return total
end

function xSectorUtil_TotalAsteroids(content)
    local total = 0
    local function visit(shape)
        local asteroids = shape.asteroids or {}
        local number = asteroids.number or 0
        total = total + number
    end
    xSectorUtil_WalkContentShapes(content, visit)
    return total
end

function xSectorUtil_SetContentCounts(content)
    content.ships              = xSectorUtil_TotalShips(content)
    content.defenders          = xSectorUtil_TotalDefenders(content)
    content.stations           = xSectorUtil_TotalStations(content)
    content.asteroidEstimation = xSectorUtil_TotalAsteroids(content)
    
end
