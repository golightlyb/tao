
-- TODO this is duplicated in xSectorGenerator
local variantScripts = {
    spacedock       = "data/scripts/entity/merchants/xSpacedock.lua",
    fortress        = "data/scripts/entity/merchants/xFortress.lua",
    refinery        = "data/scripts/entity/merchants/xRefinery.lua",
    oreProcessor    = "data/scripts/entity/merchants/xOreProcessor.lua",
    tradingPost     = "data/scripts/entity/merchants/tradingpost.lua",
    terrestrial     = "data/scripts/entity/merchants/xTerrestrial.lua",
    recycler        = "data/scripts/entity/merchants/xRecycler.lua",
    defensePlatform = "data/scripts/entity/xDefensePlatform.lua",
    miningColony    = "data/scripts/entity/merchants/xMiningColony.lua",
    
    -- must appear last because some of the previous variants are also factories
    factory         = "data/scripts/entity/merchants/factory.lua",
}

-- used by player station founder
xUtil_serviceStations = {
    {
        title         = "Spacedock",
        shorttitle    = "Spacedock",
        variant       = "spacedock",
        tooltip       = "Provides a range of essential civil and military services.",
        foundingCost  = 16 * 1000 * 1000,
        foundingNotes = "Comes armed with several cannons.",
    },
    {
        title         = "Refinery",
        shorttitle    = "Refinery",
        variant       = "refinery",
        tooltip       = "Refines resources (Iron, Titanium, etc.)",
        foundingCost  = 2 * 1000 * 1000,
        foundingNotes = "Unarmed.",
    },
    {
        title         = "Trading Post",
        shorttitle    = "Trading Post",
        variant       = "tradingPost",
        tooltip       = "Buys and sells goods in demand.",
        foundingCost  = 4 * 1000 * 1000,
        foundingNotes = "Unarmed.",
    },
    {
        title         = "Terrestrial Trading Post",
        shorttitle    = "Terrestrial",
        variant       = "terrestrial",
        tooltip       = "Terrestrial trading post. Trades goods (and people) on and off planet.",
        foundingCost  = 4 * 1000 * 1000,
        foundingNotes = "Unarmed.",
    },
    {
        title         = "Recycling Station",
        shorttitle    = "Recycler",
        variant       = "recycler",
        tooltip       = "Recycles waste and scrap metals.",
        foundingCost  = 2 * 1000 * 1000,
        foundingNotes = "Unarmed.",
    }
}

xUtil_specialProducers = {
    {
        title         = "Ore Processing Station",
        shorttitle    = "Ore Processor",
        variant       = "oreProcessor",
        tooltip       = "Turns raw ore into metal.",
        foundingCost  = 2 * 1000 * 1000,
        foundingNotes = "Unarmed.",
    },
    {
        title         = "Gas Collector",
        shorttitle    = "Gas Collector",
        variant       = "factory",
        tooltip       = "Extracts raw resources from gasses.",
        foundingCost  = 4 * 1000 * 1000,
        foundingNotes = "Unarmed.",
    },
    {
        title         = "Asteroid Mine",
        shorttitle    = "Asteroid Mine",
        variant       = "factory",
        tooltip       = "Extracts raw resources from rocks.",
        foundingCost  = 1 * 1000 * 1000,
        foundingNotes = "Unarmed.",
    },
    {
        title         = "Factory",
        shorttitle    = "Factory",
        variant       = "factory",
        tooltip       = "Consumes ingredients and produces products.",
        foundingCost  = 8 * 1000 * 1000,
        foundingNotes = "Unarmed.",
    },
}

-- used by player station founder
xUtil_militaryStations = {
    {
        title         = "Defense Platform",
        shorttitle    = "Defense Platform",
        variant       = "defensePlatform",
        tooltip       = "A floating deterrent.",
        foundingCost  = 250 * 1000,
        foundingNotes = "Comes armed with two cannons.",
    },
    {
        title         = "Fortress",
        shorttitle    = "Fortress",
        variant       = "fortress",
        tooltip       = "A really big floating deterrent.",
        foundingCost  = 4 * 1000 * 1000,
        foundingNotes = "Comes armed with many cannons. Buys some goods.",
    },
}

function xSectorUtil_VariantFromStation(station)
    for k, v in pairs(variantScripts) do
        if station:hasScript(v) then
            if k == "factory" and station:getValue("factory_type") == "mine" then
                return "mine"
            end
            return k
        end
    end
    return nil
end

local variantChances = { -- crew levels
    -- limit to six picks
    spacedock       = {
        noneMin     = 60, noneMax   = 80, -- double vanilla
        engineMin   = 10, engineMax = 30, -- double vanilla
        repairMin   = 10, repairMax = 30, -- double vanilla
        pilotMin    = 10, pilotMax  = 30, -- triple vanilla
        gunnerMin   = 5,  gunnerMax = 10, -- vanilla
        minerMin    = 2,  minerMax  =  5, -- few
    },
    fortress        = {
        engineMin   = 10, engineMax   = 30, -- double vanilla
        repairMin   = 10, repairMax   = 30, -- double vanilla
        gunnerMin   = 20, gunnerMax   = 40, -- 4x vanilla
        pilotMin    = 10, pilotMax    = 30, -- triple vanilla
        securityMin = 10, securityMax = 30, -- triple vanilla
        -- attackerMin = 10, attackerMax = 30, -- triple vanilla -- not used
    },
    refinery        = {
        noneMin     = 15, noneMax   = 20, -- half vanilla
        engineMin   =  5, engineMax = 15, -- vanilla
        repairMin   =  5, repairMax = 15, -- vanilla
        minerMin    =  5, minerMax  = 10, -- few, but more
    },
    oreProcessor    = {
        noneMin     = 15, noneMax   = 20, -- half vanilla
        engineMin   =  5, engineMax = 15, -- vanilla
        repairMin   =  5, repairMax = 15, -- vanilla
        minerMin    =  5, minerMax  = 10, -- few, but more
    },
    tradingPost     = {
        noneMin     = 15, noneMax     = 20, -- half vanilla
        pilotMin    =  3, pilotMax    = 10, -- vanilla
        gunnerMin   =  3, gunnerMax   =  5, -- few
        minerMin    =  3, minerMax    =  5, -- few
        securityMin =  3, securityMax = 15, -- vanilla
    },
    terrestrial     = {
        noneMin     =100, noneMax     = 200, -- loads!
        minerMin    = 20, minerMax    =  60, -- loads! (more than you'd ever need!)
        engineMin   =  5, engineMax   = 15, -- vanilla
        repairMin   =  5, repairMax   = 15, -- vanilla
        securityMin =  3, securityMax = 15, -- vanilla
    },
    recycler        = {
        noneMin     = 15, noneMax   = 20, -- half vanilla
        engineMin   =  5, engineMax = 15, -- vanilla
        repairMin   =  5, repairMax = 15, -- vanilla
    },
    factory         = {
        noneMin     = 15, noneMax   = 20, -- half vanilla
        engineMin   =  5, engineMax = 15, -- vanilla
        repairMin   =  5, repairMax = 15, -- vanilla
    },
    mine            = {
        noneMin     = 15, noneMax   = 20, -- half vanilla
        engineMin   =  5, engineMax = 15, -- vanilla
        repairMin   =  5, repairMax = 15, -- vanilla
        minerMin    = 10, minerMax  = 20, -- quite a lot
    },
    defensePlatform = {},
    miningColony    = {
        noneMin     = 50, noneMax     = 100, -- loads!
        minerMin    = 20, minerMax    =  30, -- loads! (more than you'd ever need!)
        engineMin   =  5, engineMax   = 15, -- vanilla
        repairMin   =  5, repairMax   = 15, -- vanilla
        securityMin =  3, securityMax = 15, -- vanilla
    },
}

function xSectorUtil_CrewBoardChances(station)
    local variant = xSectorUtil_VariantFromStation(station)
    if not variant then return {} end
    return variantChances[variant]
end

function xSectorUtil_StationsFromCounts(s)
    -- input counts such as {spacedock=2}
    -- output {{variant="spacedock"}, {variant="spacedock"}}

    local function __each(t, variant, number)
        if not number then return end
        for i = 1, number do
            table.insert(t, {variant=variant})
        end
    end

    local stations = {}
    
    __each(stations, "spacedock",       s.spacedocks)
    __each(stations, "fortress",        s.fortresses)
    __each(stations, "oreProcessor",    s.oreProcessors)
    __each(stations, "tradingPost",     s.tradingPosts)
    __each(stations, "terrestrial",     s.terrestrialTradingPosts)
    __each(stations, "recycler",        s.recyclers)
    __each(stations, "defensePlatform", s.defensePlatforms)
    __each(stations, "miningColony",    s.miningColonies)

    if s.mines then
        table.insert(stations, {variant="mines", number=s.mines})
    end
    if s.factories then
        table.insert(stations, {variant="factories", number=s.factories})
    end
    
    return stations
end

function xSectorUtil_CountTotal(xs)
    -- input e.g. {{variant="spacedock"}, {variant="mines", number=2}}
    -- output number e.g. 3
    if not xs then return 0 end
    local sum = 0
    for i = 1, #xs do
        local x = xs[i]
        if x.number == nil then
            sum = sum + 1
        else
            sum = sum + x.number
        end
    end
    return sum
end

function xSectorUtil_WalkShapes(shapes, visit, offset)
    -- call visitor for each shape entry in an array of shapes
    shapes = shapes or {}
    for i = 1, #shapes do
        visit(shapes[i], offset)
    end
end

function xSectorUtil_WalkContentShapes(content, visit, offset)
    offset = offset or vec3(0, 0, 0)
    -- call visitor for each shape entry in a sector content object
    content = content or {}
    local x = content.x or {}
    local features = x.features or {}
    for i = 1, #features do
        local feature = features[i]
        xSectorUtil_WalkShapes(feature.shapes, visit, feature.offset + offset)
    end
    xSectorUtil_WalkShapes(x.shapes, visit, offset)
end

function xSectorUtil_CountsFromContent(content, key)
    -- count each variant type from a sector content object
    local counts = {}
    local total = 0
    
    local function visit(shape)
        local xs = shape[key]
        if not xs then return end
        for i = 1, #xs do
            local x = xs[i]
            local variant = x.variant
            local number = 1
            if x.number then number = x.number end
            counts[variant] = (counts[variant] or 0) + number
            total = total + number
        end
    end

    xSectorUtil_WalkContentShapes(content, visit)
    
    return counts, total
end

function xSectorUtil_TotalDefenders(content)
    local defenders = 0
    
    local function visit(shape)
        local xs = shape.ships
        if not xs then return end
        for i = 1, #xs do
            local x = xs[i]
            local variant = x.variant
            local number = 1
            if x.number then number = x.number end
            if (variant == "garrison") or x.defender then
                defenders = defenders + number
            end
        end
    end
    
    xSectorUtil_WalkContentShapes(content, visit)
    
    return defenders
end

function xSectorUtil_TotalShips(content)
    _, total = xSectorUtil_CountsFromContent(content, "ships")
    return total
end

function xSectorUtil_TotalStations(content)
    _, total = xSectorUtil_CountsFromContent(content, "stations")
    return total
end

function xSectorUtil_TotalAsteroids(content)
    local total = 0
    local function visit(shape)
        local asteroids = shape.asteroids or {}
        local number = asteroids.number or 0
        total = total + number
    end
    xSectorUtil_WalkContentShapes(content, visit)
    return total
end

function xSectorUtil_SetContentCounts(content)
    content.ships              = xSectorUtil_TotalShips(content)
    content.defenders          = xSectorUtil_TotalDefenders(content)
    content.stations           = xSectorUtil_TotalStations(content)
    content.asteroidEstimation = xSectorUtil_TotalAsteroids(content) 
end

function xSectorUtil_SetSectorLocations(sector, locations)
    local ok, _ = sector:invokeFunction("data/scripts/sector/xLocations.lua", "set", locations)
    if not ok then
        eprint("xUtil: xSectorUtil_SetSectorLocations: invokeFunction failed")
        return false
    end
    return true
end

function xSectorUtil_GetSectorLocations(sector)
    local ok, locations = sector:invokeFunction("data/scripts/sector/xLocations.lua", "get")
    if not ok then
        eprint("xUtil: xSectorUtil_GetSectorLocations: invokeFunction failed")
        return nil
    end
    return locations
end
