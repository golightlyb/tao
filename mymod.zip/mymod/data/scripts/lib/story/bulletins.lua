function StoryBulletins.initialize()
end



