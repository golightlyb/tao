
function Smuggler.spawn(x, y)
    return
end

function Smuggler.spawnEngineer(x, y)
    return
end

function Smuggler.spawnRepresentative(station)
    return
end

return Smuggler
