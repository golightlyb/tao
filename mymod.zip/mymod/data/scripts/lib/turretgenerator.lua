
local function bucket(num) -- group 52 tech levels into buckets of size 5
	return math.floor((num / 5) + 0.5) * 5
end

local function bucketToMark(num) -- group 52 tech levels into buckets of size 5
	return math.floor((num / 5) + 0.5)
end


function TurretGenerator.generateTurret(rand, type, dps, tech, material, rarity, coaxialAllowed)
    tech = bucket(tech)
    if rarity == nil then
        local index = rand:getValueOfDistribution(32, 32, 16, 8, 4, 1)
        rarity = Rarity(index - 1)
    end

    if coaxialAllowed == nil then coaxialAllowed = true end

    local gen = generatorFunction[type]
    if gen == nil then return nil end
    return gen(rand, dps, tech, material, rarity, coaxialAllowed)
end

local xRarityAdjectives = {}
xRarityAdjectives[RarityType.Petty]       = ""
xRarityAdjectives[RarityType.Common]      = ""
xRarityAdjectives[RarityType.Uncommon]    = ""
xRarityAdjectives[RarityType.Rare]        = ""
xRarityAdjectives[RarityType.Exceptional] = "Mastercrafted  /* weapon adjective */"%_T
xRarityAdjectives[RarityType.Exotic]      = "Mastercrafted  /* weapon adjective */"%_T
xRarityAdjectives[RarityType.Legendary]   = "Mastercrafted  /* weapon adjective */"%_T

local xGunCaliberAdjectives = {}
xGunCaliberAdjectives[ 1] = "20mm"
xGunCaliberAdjectives[ 2] = "30mm"
xGunCaliberAdjectives[ 3] = "40mm"
xGunCaliberAdjectives[ 4] = "50mm"
xGunCaliberAdjectives[ 5] = "60mm"

local xCannonCaliberAdjectives = {}
xCannonCaliberAdjectives[ 2] = "3.9\""
xCannonCaliberAdjectives[ 3] = "5.25\""
xCannonCaliberAdjectives[ 4] = "7.5\""
xCannonCaliberAdjectives[ 6] = "12\""
xCannonCaliberAdjectives[ 8] = "16\""
xCannonCaliberAdjectives[10] = "20\""

local xMissileAdjectives = {}
xMissileAdjectives[ 2] = "2x"
xMissileAdjectives[ 3] = "3x"
xMissileAdjectives[ 4] = "4x"
xMissileAdjectives[ 6] = "6x"
xMissileAdjectives[ 8] = "8x"
xMissileAdjectives[12] = "12x"
xMissileAdjectives[16] = "16x"

local function xGetRarityAdjective(rarity)
    return xRarityAdjectives[rarity.value]
end

local function xGetBarrelAdjective(turret, wtype)
    if turret.shotsPerFiring > 1 then
        if turret.shotsPerFiring == 2 then
            return "", "(2-gun)  /* weapon 'barrel' name part */"%_T
        elseif turret.shotsPerFiring == 3 then
            return "", "(3-gun)  /* weapon 'barrel' name part */"%_T
        elseif turret.shotsPerFiring == 4 then
            return "", "(4-gun)  /* weapon 'barrel' name part */"%_T
        elseif turret.shotsPerFiring == 5 then
            return "", "(5-gun)  /* weapon 'barrel' name part */"%_T
        end
    else
        if turret.numVisibleWeapons == 2 then
            return "Twin-linked  /* weapon 'barrel' name part */"%_T, ""
        elseif turret.numVisibleWeapons == 3 then
            return "Triple-linked  /* weapon 'barrel' name part */"%_T, ""
        elseif turret.numVisibleWeapons == 4 then
            return "Quad-linked  /* weapon 'barrel' name part */"%_T, ""
        elseif turret.numVisibleWeapons > 4 then
            return "Multi-linked  /* weapon 'barrel' name part */"%_T, ""
        end
    end
    return "", ""
end

local function xMakeTitleParts(turret, wtype, size, techBucket)
    local mark = " MK " .. toRomanLiterals(math.floor((techBucket + 0.5)/5))
    local quality = xGetRarityAdjective(turret.rarity)
    local barrelPrefix, barrelSuffix = xGetBarrelAdjective(turret, wtype)
    local prefix = ""
    local suffix = ""
    if turret.coaxial ~= true then
        suffix = "Turret  /* weapon if not coax */"
    end
    suffix = suffix .. mark
    prefix = barrelPrefix .. prefix
    if barrelSuffix then
        suffix = suffix .. "  " .. barrelSuffix
    end
    return quality, prefix, suffix
end

local function xMakeTitle(turret, wtype, size, techBucket, name)
    local quality, prefix, suffix = xMakeTitleParts(turret, wtype, size, techBucket)
    return Format("%1%%2%%3%%4%%5%%6%%7% /* [outer-adjective][barrel][coax][dmg-adjective][multishot][name][serial], e.g. Enduring Dual Coaxial E-Tri-Cannon T-F */"%_T, quality, prefix, "", "", "", name, suffix)
end

scales[WeaponType.XGun] = {
    {from =  0, to =  8, size =  1.0, usedSlots = 1, maxBarrels=2},
    {from =  9, to = 16, size =  2.0, usedSlots = 1, maxBarrels=2},
    {from = 17, to = 24, size =  3.0, usedSlots = 1, maxBarrels=3},
    {from = 25, to = 32, size =  4.0, usedSlots = 1, maxBarrels=3},
    {from = 33, to = 40, size =  5.0, usedSlots = 1, maxBarrels=3},
    {from = 41, to = 52, size =  5.0, usedSlots = 1, maxBarrels=4},
}

scales[WeaponType.XCannon] = {
    {from =  0, to =  8, size =  2.0, usedSlots = 4, maxBarrels=2},
    {from =  9, to = 16, size =  3.0, usedSlots = 4, maxBarrels=2},
    {from = 17, to = 24, size =  4.0, usedSlots = 4, maxBarrels=3},
    {from = 25, to = 32, size =  6.0, usedSlots = 4, maxBarrels=3},
    {from = 33, to = 40, size =  8.0, usedSlots = 4, maxBarrels=4},
    {from = 41, to = 52, size = 10.0, usedSlots = 4, maxBarrels=5},
}

scales[WeaponType.XMissile] = {
    {from =  0, to = 16, size =  2.0, usedSlots = 2, silos={2, 3, 4}},
    {from = 17, to = 32, size =  4.0, usedSlots = 2, silos={4, 6, 8}},
    {from = 33, to = 52, size =  6.0, usedSlots = 2, silos={8, 12, 16}},
}

function TurretGenerator.scale(rand, turret, type, tech, turnSpeedFactor, coaxialPossible)
    if coaxialPossible == nil then coaxialPossible = true end -- avoid coaxialPossible = coaxialPossible or true, as it will set it to true if "false" is passed

    local scale, lvl = TurretGenerator.getScale(type, tech)

    turret.coaxial = coaxialPossible

    turret.size = scale.size
    turret.slots = scale.usedSlots
    turret.turningSpeed = lerp(turret.size, 0.5, 10.0, 1.0, 0.5) * turnSpeedFactor
    
    local weapons = {turret:getWeapons()}
    for _, weapon in pairs(weapons) do
        weapon.localPosition = weapon.localPosition * (2.0 * scale.size)
    end

    turret:clearWeapons()
    for _, weapon in pairs(weapons) do
        turret:addWeapon(weapon)
    end

    return lvl
end

function TurretGenerator.generateXGun(rand, dps, tech, material, rarity, coaxialAllowed)
    local wtype = WeaponType.XGun
    local result = TurretTemplate()
    local scale, lvl = TurretGenerator.getScale(wtype, tech)
    local r = rarity.value + 1 -- 0 to 6
    local m = material.value
    local barrels = rand:getInt(1, scale.maxBarrels)
    
    -- generate turret
    local requiredCrew = math.ceil(0.5 * scale.size * barrels)
    local crew = Crew()
    crew:add(requiredCrew, CrewMan(CrewProfessionType.Gunner))
    result.crew = crew

    -- generate weapons
    -- local numWeapons = rand:getInt(1, math.floor(((scale.size-2)/2) + 0.5))
    local weapon = WeaponGenerator.generateXGun(rand, dps, tech, material, rarity)
    WeaponGenerator.XAdaptGunSize(weapon, dps, barrels, scale.size, tech, material, rarity)
    
    -- attach weapons to turret
    TurretGenerator.attachWeapons(rand, result, weapon, barrels)
    
    local shootingTime = (3.0 + (r * 0.25) + (m * 0.125))  * math.pow(0.9, barrels - 1)
    local coolingTime = scale.size * math.pow(1.2, barrels - 1)
    TurretGenerator.createStandardCooling(result, coolingTime, shootingTime)
    
    TurretGenerator.scale(1.0, result, wtype, tech, 1.0, true)

    result.slotType = TurretSlotType.Armed
    result:updateStaticStats()

    local name = xGunCaliberAdjectives[scale.size] .. " " .. "Autocannon  /* weapon name */"%_T
    result.title = xMakeTitle(result, wtype, scale.size, tech, name)
    return result
end

function TurretGenerator.generateXCannon(rand, dps, tech, material, rarity, coaxialAllowed)
    local wtype = WeaponType.XCannon
    local result = TurretTemplate()
    local scale, lvl = TurretGenerator.getScale(wtype, tech)
    local r = rarity.value + 1 -- 0 to 6
    local m = material.value
    local barrels = rand:getInt(1, scale.maxBarrels)
    
    -- generate turret
    local requiredCrew = (2 * scale.size * barrels)
    local crew = Crew()
    crew:add(requiredCrew, CrewMan(CrewProfessionType.Gunner))
    result.crew = crew

    -- generate weapons
    local weapon = WeaponGenerator.generateXCannon(rand, dps, tech, material, rarity)
    WeaponGenerator.XAdaptCannonSize(weapon, dps, barrels, scale.size, tech, material, rarity)
    
    -- attach weapons to turret
    TurretGenerator.attachWeapons(rand, result, weapon, barrels)
    
    local shootingTime = (weapon.fireDelay / barrels) - 0.01 -- needs -0.01 to prevent unwanted additional shot
    local coolingTime = 0.5 + (0.5 * scale.size * math.pow(1.5, barrels - 1)) -- * 1, * 1.5, 2.25, 3.375
    TurretGenerator.createStandardCooling(result, coolingTime, shootingTime)

    local turnspeed = (0.25 + (r * 0.02)) * math.pow(0.9, barrels - 1)
    TurretGenerator.scale(1.0, result, wtype, tech, turnspeed, false)

    result.slotType = TurretSlotType.Armed
    result:updateStaticStats()

    local name = xCannonCaliberAdjectives[scale.size] .. " " .. "Artillery  /* weapon name */"%_T
    result.title = xMakeTitle(result, wtype, scale.size, tech, name)
    return result
end


function TurretGenerator.generateXMissile(rand, dps, tech, material, rarity, coaxialAllowed)
    local wtype = WeaponType.XMissile
    local result = TurretTemplate()
    local scale, lvl = TurretGenerator.getScale(wtype, tech)
    local r = rarity.value + 1 -- 0 to 6
    local m = material.value
    local barrels = scale.silos[rand:getInt(1, #scale.silos)]
    
    -- generate turret
    local requiredCrew = 1 + barrels
    local crew = Crew()
    crew:add(requiredCrew, CrewMan(CrewProfessionType.Gunner))
    result.crew = crew

    -- generate weapons
    local weapon = WeaponGenerator.generateXMissile(rand, dps, tech, material, rarity)
    WeaponGenerator.XAdaptMissileSize(weapon, dps, barrels, scale.size, tech, material, rarity)
    
    -- attach weapons to turret
    TurretGenerator.attachWeapons(rand, result, weapon, 1)
    
    local shootingTime = weapon.fireDelay * barrels
    local coolingTime = 5.0 + (0.5 * scale.size * math.pow(1.1, barrels))
    TurretGenerator.createStandardCooling(result, coolingTime, shootingTime)
    
    TurretGenerator.scale(1.0, result, wtype, tech, 1.0, true)

    result.slotType = TurretSlotType.Armed
    result:updateStaticStats()

    local name = xMissileAdjectives[barrels] .. " " .. "Micro-Missile Launcher  /* weapon name */"%_T
    result.title = xMakeTitle(result, wtype, scale.size, tech, name)
    return result
end


generatorFunction[WeaponType.XGun]    = TurretGenerator.generateXGun
generatorFunction[WeaponType.XCannon] = TurretGenerator.generateXCannon
generatorFunction[WeaponType.XMissile] = TurretGenerator.generateXMissile

