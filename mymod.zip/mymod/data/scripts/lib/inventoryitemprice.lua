
function ArmedObjectPrice(object)
    if object == nil then return 1 end
    if WeaponTypes == nil then return 1 end
    if WeaponTypes.getTypeOfItem == nil then return 1 end
    local type = WeaponTypes.getTypeOfItem(object)
    if type == nil then return 1 end

    local r = object.rarity.value + 1 -- 0 to 6
    
    local value = 1 * (1 + object.material.value) * object.size
    
    value = value * math.pow(10, r)
    
    return value
end


