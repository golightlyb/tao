
function ArmedObjectPrice(object)
    -- local type = WeaponTypes.getTypeOfItem(object) or WeaponType.XGun

    local dps = object.dps * (1.0 + object.shieldDamageMultiplier) * (1.0 + object.hullDamageMultiplier)
    dps = dps + object.hullRepairRate + object.shieldRepairRate
    -- dps = dps + object.holdingForce / 10000
    
    local r = object.rarity.value + 1 -- 0 to 6
    local m = object.material.value -- 0 to 6
    
    local value = 1000 * math.pow(4, (r+m+m)/3.0) * object.slots
    value = value + (1000.0 * dps)
    
    if object.seeker then
        value = value * 2
    end
    
    return value
end


