
function WeaponGenerator.generateWeapon(rand, type, dps, tech, material, rarity)
    local gen = generatorFunction[type]
    if gen == nil then return nil end
    return generatorFunction[type](rand, dps, tech, material, rarity)
end

function WeaponGenerator.generateXGun(rand, dps, tech, material, rarity)
    local r = rarity.value + 1 -- 0 to 6
    local m = material.value
    local weapon = Weapon()
    weapon:setProjectile()

    local fireDelay = 0.3 - (r * 0.01) - (m * 0.005)
    local fireRate = 1.0 / fireDelay

    weapon.fireDelay = fireDelay
    weapon.fireRate = fireRate
    weapon.appearanceSeed = rand:getInt()
    weapon.appearance = WeaponAppearance.ChainGun
    weapon.name = "XGun /* Weapon Name*/"%_T
    weapon.prefix = "XGun /* Weapon Prefix*/"%_T
    weapon.icon = "data/textures/icons/chaingun.png" -- previously minigun.png
    weapon.sound = "chaingun"

    weapon.damageType = DamageType.Physical
    weapon.impactParticles = ImpactParticles.Physical
    weapon.impactSound = 1
    weapon.impactExplosion = false
    WeaponGenerator.XSetDamage(weapon, DamageType.Physical, 1, 2, 1, 0)

    weapon.pvelocity = speed
    weapon.pcolor = ColorHSV(200, 0.26, 1)

    -- base values adjusted by number of barrels and size later
    weapon.psize = 0.05
    weapon.shotsFired = 1
    weapon.recoil = 100.0 - (5.0 * r) - (2.5 * m)
    weapon.accuracy = 0.975

    -- base values calculated by number of barrels and size later
    weapon.reach = 600.0
    weapon.pvelocity = 600.0
    weapon.pmaximumTime = 1.0
    
    WeaponGenerator.adaptWeapon(rand, weapon, tech, material, rarity)

    return weapon
end

function WeaponGenerator.generateXCannon(rand, dps, tech, material, rarity)
    local r = rarity.value + 1 -- 0 to 6
    local m = material.value
    local weapon = Weapon()
    weapon:setProjectile()

    local fireDelay = 1.0 -- controlled by cooling, not ROF
    local fireRate = 1.0 -- controlled by cooling, not ROF
    
    weapon.fireDelay = fireDelay
    weapon.fireRate = fireRate
    weapon.appearanceSeed = rand:getInt()
    weapon.appearance = WeaponAppearance.Cannon
    weapon.name = "XCannon /* Weapon Name*/"%_T
    weapon.prefix = "XCannon /* Weapon Prefix*/"%_T
    weapon.icon = "data/textures/icons/cannon.png"
    weapon.sound = "cannon"

    weapon.impactParticles = ImpactParticles.Explosion
    weapon.impactSound = 1
    weapon.impactExplosion = true
    WeaponGenerator.XSetDamage(weapon, DamageType.Physical, 1, 2, 1, 0)

    weapon.pcolor = ColorHSV(60, 0.7, 1)
    
    -- base values adjusted by number of barrels and size later
    weapon.psize = 0.5
    weapon.shotsFired = 1
    weapon.recoil = 1000.0 - (50.0 * r) - (25.0 * m)
    weapon.accuracy = 0.99
    
    -- base values calculated by number of barrels and size later
    weapon.reach = 1000.0
    weapon.pvelocity = 1000.0
    weapon.pmaximumTime = 1.0
    
    local explosionRadiusMetres = 10.0 + (3.0 * r) + (2.0 * m)
    weapon.explosionRadius = explosionRadiusMetres * 0.1 -- to units

    WeaponGenerator.adaptWeapon(rand, weapon, tech, material, rarity)
    
    return weapon
end

function WeaponGenerator.generateXMissile(rand, dps, tech, material, rarity)
    local r = rarity.value + 1 -- 0 to 6
    local m = material.value
    local weapon = Weapon()
    weapon:setProjectile()

    local fireDelay = 0.2 - (r * 0.005) - (m * 0.0025)
    local fireRate = 1.0 / fireDelay

    weapon.fireDelay = fireDelay
    weapon.fireRate = fireRate
    weapon.appearanceSeed = rand:getInt()
    weapon.appearance = WeaponAppearance.RocketLauncher
    weapon.name = "XGun /* Weapon Name*/"%_T
    weapon.prefix = "XGun /* Weapon Prefix*/"%_T
    weapon.icon = "data/textures/icons/rocket-launcher.png" -- previously minigun.png
    weapon.sound = "launcher"

    weapon.damageType = DamageType.Physical
    weapon.impactParticles = ImpactParticles.Explosion
    weapon.impactSound = 1
    weapon.impactExplosion = true
    WeaponGenerator.XSetDamage(weapon, DamageType.Physical, 0.5, 1, 0.5, 0)
    weapon.seeker = true

    weapon.pvelocity = speed
    weapon.pcolor = ColorHSV(239, 0.6, 1)

    -- base values adjusted by number of barrels and size later
    weapon.psize = 0.2
    weapon.shotsFired = 1
    weapon.recoil = 500.0 - (5.0 * r) - (2.5 * m)
    weapon.accuracy = 0.8 -- seeker, but high to break up when coming out of silo

    -- base values calculated by number of barrels and size later
    weapon.reach = 1000.0
    weapon.pvelocity = 200.0
    weapon.pmaximumTime = 1.0
    
    local explosionRadiusMetres = 1.0 + (0.3 * r) + (0.2 * m)
    weapon.explosionRadius = explosionRadiusMetres * 0.1 -- to units
    
    WeaponGenerator.adaptWeapon(rand, weapon, tech, material, rarity)

    return weapon
end

generatorFunction[WeaponType.XGun]    = WeaponGenerator.generateXGun
generatorFunction[WeaponType.XCannon] = WeaponGenerator.generateXCannon
generatorFunction[WeaponType.XMissile] = WeaponGenerator.generateXMissile

function WeaponGenerator.adaptWeapon(rand, weapon, tech, material, rarity)
    local m = material.value
    local r = rarity.value + 1 -- 0 to 6
    local dpsFactor = 1 + (r * 0.3) + (m * 0.2)

    weapon.tech = tech
    weapon.material = material
    weapon.rarity = rarity

    if weapon.damage ~= 0 then weapon.damage = weapon.damage * dpsFactor end
    if weapon.shieldRepair ~= 0 then weapon.shieldRepair = weapon.shieldRepair * dpsFactor end
    if weapon.hullRepair ~= 0 then weapon.hullRepair = weapon.hullRepair * dpsFactor end
end

function WeaponGenerator.adaptMiningLaser(rand, weapon, tech, material, rarity)
    local m = material.value
    local r = rarity.value + 1 -- 0 to 6
    local dpsFactor = 1 + (r * 0.3) + (m * 0.2)

    weapon.tech = tech
    weapon.material = material
    weapon.rarity = rarity

    if weapon.damage ~= 0 then weapon.damage = weapon.damage * dpsFactor end
end

function WeaponGenerator.XAdaptGunSize(weapon, dps, barrels, size, tech, material, rarity)
    local m = material.value
    local r = rarity.value + 1 -- 0 to 6
    local factor = 1.0 + (0.25 * size)
    local initialFireDelay = weapon.fireDelay

    -- rarer guns are more accurate
    weapon.accuracy = weapon.accuracy * math.pow(0.995, 6-r)
    
    -- a bigger gun is more accurate
    weapon.accuracy = weapon.accuracy * math.pow(0.995, 5-size)
    
    -- but gun with more barrels is slightly less accurate
    weapon.accuracy = weapon.accuracy * math.pow(0.995, (barrels - 1)) -- x1, x0.995, x0.990025
    
    -- a gun with more barrels shoots a bit faster
    weapon.fireDelay       = weapon.fireDelay * barrels -- instead of * barrel times faster
     -- delay x1.0, x0.7, x0.49, 0.2401 instead of x0.5, 0.25, 0.125
    weapon.fireDelay       = weapon.fireDelay * (math.pow(0.7, barrels - 1))
    weapon.fireRate        = 1.0 / weapon.fireDelay
    
    -- a bigger gun shots a little bit slower
    weapon.fireDelay       = weapon.fireDelay * math.pow(1.1, size-1)
    weapon.fireRate        = 1.0 / weapon.fireDelay

    -- a bigger gun has bigger projectiles and recoil
    weapon.psize           = weapon.psize  * factor
    weapon.recoil          = weapon.recoil * size
    
    -- a bigger gun reaches slightly further and shoots slightly faster
    local reach = 600.0 + (size * 100) + (r * 30) + (m * 20)
    local speed = reach
    
    -- a gun with more barrels has a penalty to reach and speed
    reach = reach * math.pow(0.9, barrels-1) -- x1.0, x0.9, x0.81...
    speed = speed * math.pow(0.9, barrels-1) -- x1.0, x0.9, x0.81...
    
    -- recalculate reach / speed
    weapon.reach = reach
    weapon.pvelocity = speed
    weapon.pmaximumTime = reach / speed
    
    -- recalculate weapon damage
    weapon.damage          = dps * initialFireDelay
    weapon.damage          = weapon.damage * math.pow(size, 1.15)
    weapon.damage          = weapon.damage * 2.0 -- adjust for slow ROF and cooldown
end

function WeaponGenerator.XAdaptCannonSize(weapon, dps, barrels, size, tech, material, rarity)
    local m = material.value
    local r = rarity.value + 1 -- 0 to 6
    local factor = 1.0 + (0.25 * size)
    
    -- a cannon with more barrels shoots multiple shots at once
    weapon.shotsFired      = weapon.shotsFired * barrels
    
    -- rarer cannons are more accurate
    weapon.accuracy = weapon.accuracy * math.pow(0.995, 6-r)
    
    -- a bigger cannon is more accurate
    weapon.accuracy = weapon.accuracy * math.pow(0.995, 10-size)
    
    -- but a cannon with more barrels is slightly less accurate
    weapon.accuracy = weapon.accuracy * math.pow(0.995, (barrels - 1))
    
    -- change the ROF for stats balancing (true ROF is controlled by cooling)
    weapon.fireRate  = 1.0 / barrels
    weapon.fireDelay = 1.0 / weapon.fireRate
    
    -- a bigger gun has bigger projectiles and recoil
    weapon.psize           = weapon.psize  * factor
    weapon.recoil          = weapon.recoil * size -- TODO does this count multishot or should we scale by barrels too?
    weapon.explosionRadius = weapon.explosionRadius * size

    -- a bigger gun reaches slightly further
    local reach = 3000.0 + (size * 500) + (r * 300) + (m * 20)
    local speed = 600.0
    
    -- a gun with more barrels has a slight penalty to reach and speed
    reach = reach * math.pow(0.9, barrels-1) -- x1.0, x0.9, x0.81, x0.729
    speed = speed * math.pow(0.9, barrels-1) -- x1.0, x0.9, x0.81, x0.729
    
    -- recalculate reach / speed
    weapon.reach = reach
    weapon.pvelocity = speed
    weapon.pmaximumTime = reach / speed
    
    -- recalculate weapon damage
    weapon.damage          = dps
    weapon.damage          = weapon.damage * math.pow(size, 1.15)
    weapon.damage          = weapon.damage * 10.0 -- adjust for slow ROF and cooldown
end

function WeaponGenerator.XAdaptMissileSize(weapon, dps, barrels, size, tech, material, rarity)
    local m = material.value
    local r = rarity.value + 1 -- 0 to 6
    local factor = 1.0 + (0.25 * size)
    local initialFireDelay = weapon.fireDelay
    
    -- a launcher with more silos shoots multiple shots at once
    weapon.shotsFired = 1
    
    -- change the ROF for stats balancing (true ROF is controlled by cooling)
    weapon.fireDelay = weapon.fireDelay
    weapon.fireRate = 1.0 / weapon.fireDelay
    
    -- a bigger/rarer launcher reaches slightly further and shoots slightly faster
    local reach = 3000.0 + (size * 100) + (r * 30) + (m * 20)
    
    -- recalculate reach / speed
    weapon.reach = reach
    -- weapon.pvelocity unchanged
    weapon.pmaximumTime = weapon.reach / weapon.pvelocity
    
    -- recalculate weapon damage
    weapon.damage          = dps * initialFireDelay
    weapon.damage          = weapon.damage * math.pow(size, 1.15)
    weapon.damage          = weapon.damage * 5.0 -- adjust for long cooldown
end

function WeaponGenerator.XSetDamage(weapon, damageType, shield, hull, stone, shieldPenetration)
    -- special damagetype for all point defense weapons
    -- add DamageType
    weapon.damageType = damageType
    weapon.shieldDamageMultiplier = shield
    weapon.hullDamageMultiplier = hull
    weapon.stoneDamageMultiplier = stone
    weapon.shieldPenetration = shieldPenetration
end



