if onServer() then
    function TeleporterGenerator.createTeleporters()
        return
    end
end
