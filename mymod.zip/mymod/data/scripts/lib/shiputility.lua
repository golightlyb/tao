
function ShipUtility.xArm(entity, arms)
    if arms then
        for i = 1,#arms do
            local turret = arms[i].turret
            local num = arms[i].num
            local limit = (arms[i].limit or num)
            ShipUtility.xAddTurretsToCraft(entity, turret, num, limit)
        end
    end
end

function ShipUtility.xAddTurretsToCraft(entity, turret, numTurrets, maxNumTurrets)

    -- TODO if we make all the lines of sight one one side, this could
    --      work for coaxial weapons too. Currently coaxial weapons just get
    --      added all over the place.

    local maxNumTurrets = maxNumTurrets or numTurrets
    if maxNumTurrets == 0 then return end

    turret = copy(turret)
    -- allow coaxial
    
    -- MODIFIED TO ALLOW
    -- turret.coaxial = false -- this can lead to the turret's name still containing "Coax", so make sure to only pass non-coaxial turrets!

    local wantedTurrets = math.max(1, round(numTurrets / turret.slots))

    local values = {entity:getTurretPositionsLineOfSight(turret, numTurrets)}
    while #values == 0 and turret.size > 0.5 do
        turret.size = turret.size - 0.5
        values = {entity:getTurretPositionsLineOfSight(turret, numTurrets)}
    end

    local c = 1;
    numTurrets = tablelength(values) / 2 -- divide by 2 since getTurretPositions returns 2 values per turret

    -- limit the turrets of the ships to maxNumTurrets
    numTurrets = math.min(numTurrets, maxNumTurrets)

    local strengthFactor = wantedTurrets / numTurrets
    if numTurrets > 0 and strengthFactor > 1.0 then
        entity.damageMultiplier = math.max(entity.damageMultiplier, strengthFactor)
    end

    for i = 1, numTurrets do
        local position = values[c]; c = c + 1;
        local part = values[c]; c = c + 1;

        if part ~= nil then
            entity:addTurret(turret, position, part)
        else
            -- print("no turrets added, no place for turret found")
        end
    end

end




