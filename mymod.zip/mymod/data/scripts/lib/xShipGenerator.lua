package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include ("galaxy")
include ("utility")
include ("defaultscripts")
include ("goods")
local PlanGenerator = include ("plangenerator")
local ShipUtility = include ("shiputility")

-- namespace XShipGenerator
local XShipGenerator = {}


include ("xUtil")

function XShipGenerator.createShip(faction, planType, mat, volume, styleName, material)
    local galaxy = Galaxy()
    local sector = Sector()
    
    position = mat or Matrix()
    volume = volume or Balancing_GetSectorShipVolume(sector:getCoordinates()) * Balancing_GetShipVolumeDeviation()
    material = material or PlanGenerator.selectMaterial(faction)

    local plan = xPlanCache_Generated(galaxy, planType, faction, volume, nil, material)
    if not plan then
        eprint("XShipGenerator nil plan")
        return
    end
    
    local ship = sector():createShip(faction, "", plan, position)
    if not ship then
        eprint("XShipGenerator error")
        return
    end
    if not valid(ship) then
        eprint("XShipGenerator error: invalid ship")
        return
    end

    ship.crew = ship.idealCrew
    ship.shieldDurability = ship.shieldMaxDurability
    ship:setDropsLoot(false)

    AddDefaultShipScripts(ship)
    SetBoardingDefenseLevel(ship)

    return ship
end

function XShipGenerator.createDefender(faction, position, arms, scale, title)
    if not title then title = "Garrison" end

    -- defenders should be a lot beefier than the normal ships
    if not scale then scale = 7.5 end
    
    -- optimisation: vanilla Avorion always balanced defenders by home sector
    --   strength, and that really helps out the plan cache!!!
    
    local volume = Balancing_GetSectorShipVolume(faction:getHomeSectorCoordinates()) * scale

    local ship = XShipGenerator.createShip(faction, "Ship", position, volume)
    if not ship then return end
    ShipUtility.xArm(ship, arms)
    
    ship.crew = ship.idealCrew
    ship.title = title .. " " .. ShipUtility.getMilitaryNameByVolume(ship.volume)
    ship.damageMultiplier = ship.damageMultiplier * 4

    ship:addScript("ai/patrol.lua")
    ship:addScript("antismuggle.lua")
    ship:setValue("is_armed", true)
    ship:setValue("is_defender", true)
    ship:setValue("npc_chatter", true)
    
    ship:addScript("icon.lua", "data/textures/icons/pixel/shield.png")

    return ship
end

function XShipGenerator.createMiner(faction, position, arms, scale)

    -- miners should be huge
    if not scale then scale = 12.0 end
    
    -- local volume =  Balancing_GetSectorShipVolume(Sector():getCoordinates()) * Balancing_GetShipVolumeDeviation()
    
    -- optimisation: balance miners by home sector to help out the plan cache
    local volume = Balancing_GetSectorShipVolume(faction:getHomeSectorCoordinates()) * scale

    local ship = XShipGenerator.createShip(faction, "Miner", position, volume)
    if not ship then return end
    ShipUtility.xArm(ship, arms)
    
    ship.crew = ship.idealCrew
    ship.title = ShipUtility.getMinerNameByVolume(ship.volume)

    ship:addScript("ai/mine.lua")
    ship:addScript("civilship.lua")
    ship:setValue("is_civil", true)
    ship:setValue("is_miner", true)
    ship:setValue("npc_chatter", true)
    
    ship:addScript("icon.lua", "data/textures/icons/pixel/mining.png")

    return ship
end

function XShipGenerator.createAttacker(faction, position, arms, scale, title, icon)
    if not title then title = "Assault" end

    if not scale then scale = 1.0 end
    
    -- optimisation: vanilla Avorion always balanced defenders by home sector
    --   strength, and that really helps out the plan cache!!!
    
    local volume = Balancing_GetSectorShipVolume(faction:getHomeSectorCoordinates()) * scale

    local ship = XShipGenerator.createShip(faction, "Ship", position, volume)
    ShipUtility.xArm(ship, arms)
    
    ship.crew = ship.idealCrew
    ship.title = title .. " " .. ShipUtility.getMilitaryNameByVolume(ship.volume)
    ship.shieldDurability = ship.shieldMaxDurability

    ship:addScript("ai/patrol.lua")
    ship:setValue("is_armed", true)
    ship:addScript("icon.lua", "data/textures/icons/pixel/"..(icon or "attack")..".png")
    
    return ship
end

function XShipGenerator.createPirate(faction, position, arms, scale)
    if not scale then scale = 1.0 end
    local ship = XShipGenerator.createAttacker(faction, position, arms, scale, "Pirate", "skull-detailed")

    ship:setValue("is_pirate", true)
    ship:addScriptOnce("utility/fleeondamaged.lua")
    
    return ship
end

function XShipGenerator.createAntipirate(faction, position, arms, scale)
    if not scale then scale = 5.0 end
    
    local ship = XShipGenerator.createAttacker(faction, position, arms, scale, "Hunter")
    
    return ship
end

return XShipGenerator