
function ShipFounding.getCosts(ships)
    return math.ceil(500 * math.pow(1.2, ships))
end

function ShipFounding.xNumShips(faction)
    local ships = 0
    for _, name in pairs({faction:getShipNames()}) do
        if faction:getShipType(name) == EntityType.Ship then
            ships = ships + 1
        end
    end
    return ships
end

function ShipFounding.getNextShipCosts(faction)

    if faction.isAlliance then
        faction = Alliance(faction.index)
    elseif faction.isPlayer then
        faction = Player(faction.index)
    end

    return ShipFounding.getCosts(ShipFounding.xNumShips(faction))
end
