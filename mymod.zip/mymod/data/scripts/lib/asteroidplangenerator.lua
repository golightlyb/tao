function AsteroidPlanGenerator:makeDefaultAsteroidPlan(size, material, flags)

    -- optimised compared to original

    material = material or Material(0)
    flags = flags or {}

    local plan = BlockPlan()

    local color = material.blockColor

    local from = flags.from or 0.1
    local to = flags.to or 0.5

    local center = flags.center or self.Stone
    local border = flags.border or self.Stone
    local edge = flags.edge or self.StoneEdge
    local corner = flags.corner or self.StoneCorner

    local ls = vec3(getFloat(from, to), getFloat(from, to), getFloat(from, to))
    local us = vec3(getFloat(from, to), getFloat(from, to), getFloat(from, to))
    local s = vec3(1, 1, 1) - ls - us

    local hls = ls * 0.5
    local hus = us * 0.5
    local hs = s * 0.5

    local m = Matrix() -- cache frequently used
    
    local ci = plan:addBlock(vec3(0, 0, 0), s, -1, -1, color, material, m, center)

    -- top bottom
    plan:addBlock(vec3(0,  hs.y + hus.y, 0), vec3(s.x, us.y, s.z), ci, -1, color, material, m, border)
    plan:addBlock(vec3(0, -hs.y - hls.y, 0), vec3(s.x, ls.y, s.z), ci, -1, color, material, m, border)

    -- left right
    plan:addBlock(vec3( hs.x + hus.x, 0, 0), vec3(us.x, s.y, s.z), ci, -1, color, material, m, border)
    plan:addBlock(vec3(-hs.x - hls.x, 0, 0), vec3(ls.x, s.y, s.z), ci, -1, color, material, m, border)

    -- front back
    plan:addBlock(vec3(0, 0,  hs.z + hus.z), vec3(s.x, s.y, us.z), ci, -1, color, material, m, border)
    plan:addBlock(vec3(0, 0, -hs.z - hls.z), vec3(s.x, s.y, ls.z), ci, -1, color, material, m, border)



    local vM00 = vec3(-1,  0,  0)
    local vP00 = vec3( 1,  0,  0)
    local v0P0 = vec3( 0,  1,  0) -- cache frequently used
    local v0M0 = vec3( 0, -1,  0) -- cache frequently used
    local v00P = vec3( 0,  0,  1)
    local v00M = vec3( 0,  0, -1)
    local m_vM00_v0P0 = MatrixLookUp(vM00, v0P0)
    local m_vP00_v0P0 = MatrixLookUp(vP00, v0P0)
    local m_vM00_v0M0 = MatrixLookUp(vM00, v0M0)
    local m_v00M_v0M0 = MatrixLookUp(v00M, v0M0)
    local m_v00P_v0M0 = MatrixLookUp(v00P, v0M0)
    local m_vM00_v00P = MatrixLookUp(vM00, v00P)
    local m_vP00_v00M = MatrixLookUp(vP00, v00M)
    local m_vP00_v0M0 = MatrixLookUp(vP00, v0M0)
    
    -- TODO still more optimisations...
    
    -- top left right
    plan:addBlock(vec3( hs.x + hus.x, hs.y + hus.y, 0), vec3(us.x, us.y, s.z), ci, -1, color, material, m_vM00_v0P0, edge)
    plan:addBlock(vec3(-hs.x - hls.x, hs.y + hus.y, 0), vec3(ls.x, us.y, s.z), ci, -1, color, material, m_vP00_v0P0, edge)

    -- top front back
    plan:addBlock(vec3(0, hs.y + hus.y, hs.z + hus.z),  vec3(s.x, us.y, us.z), ci, -1, color, material, MatrixLookUp(v00M, v0P0), edge)
    plan:addBlock(vec3(0, hs.y + hus.y, -hs.z - hls.z), vec3(s.x, us.y, ls.z), ci, -1, color, material, MatrixLookUp(v00P, v0P0), edge)

    -- bottom left right
    plan:addBlock(vec3( hs.x + hus.x, -hs.y - hls.y, 0), vec3(us.x, ls.y, s.z), ci, -1, color, material, m_vM00_v0M0, edge)
    plan:addBlock(vec3(-hs.x - hls.x, -hs.y - hls.y, 0), vec3(ls.x, ls.y, s.z), ci, -1, color, material,  m_vP00_v0M0, edge)

    -- bottom front back
    plan:addBlock(vec3(0, -hs.y - hls.y,  hs.z + hus.z), vec3(s.x, ls.y, us.z), ci, -1, color, material, m_v00M_v0M0, edge)
    plan:addBlock(vec3(0, -hs.y - hls.y, -hs.z - hls.z), vec3(s.x, ls.y, ls.z), ci, -1, color, material, m_v00P_v0M0, edge)

    -- middle left right
    plan:addBlock(vec3( hs.x + hus.x, 0, -hs.z - hls.z), vec3(us.x, s.y, ls.z), ci, -1, color, material, MatrixLookUp(vM00, v00M), edge)
    plan:addBlock(vec3(-hs.x - hls.x, 0, -hs.z - hls.z), vec3(ls.x, s.y, ls.z), ci, -1, color, material, m_vP00_v00M, edge)

    -- middle front back
    plan:addBlock(vec3( hs.x + hus.x, 0, hs.z + hus.z), vec3(us.x, s.y, us.z), ci, -1, color, material, m_vM00_v00P, edge)
    plan:addBlock(vec3(-hs.x - hls.x, 0, hs.z + hus.z), vec3(ls.x, s.y, us.z), ci, -1, color, material, MatrixLookUp(vP00, v00P), edge)


    -- top edges
    -- left right
    plan:addBlock(vec3( hs.x + hus.x, hs.y + hus.y, -hs.z - hls.z), vec3(us.x, us.y, ls.z), ci, -1, color, material, m_vM00_v0P0, corner)
    plan:addBlock(vec3(-hs.x - hls.x, hs.y + hus.y, -hs.z - hls.z), vec3(ls.x, us.y, ls.z), ci, -1, color, material, m_vP00_v00M, corner)

    -- front back
    plan:addBlock(vec3( hs.x + hus.x, hs.y + hus.y, hs.z + hus.z), vec3(us.x, us.y, us.z), ci, -1, color, material, m_vM00_v00P, corner)
    plan:addBlock(vec3(-hs.x - hls.x, hs.y + hus.y, hs.z + hus.z), vec3(ls.x, us.y, us.z), ci, -1, color, material, m_vP00_v0P0, corner)

    -- bottom edges
    -- left right
    plan:addBlock(vec3( hs.x + hus.x, -hs.y - hls.y, -hs.z - hls.z), vec3(us.x, ls.y, ls.z), ci, -1, color, material, m_v00P_v0M0, corner)
    plan:addBlock(vec3(-hs.x - hls.x, -hs.y - hls.y, -hs.z - hls.z), vec3(ls.x, ls.y, ls.z), ci, -1, color, material,  m_vP00_v0M0, corner)

    -- front back
    plan:addBlock(vec3( hs.x + hus.x, -hs.y - hls.y, hs.z + hus.z), vec3(us.x, ls.y, us.z), ci, -1, color, material, m_vM00_v0M0, corner)
    plan:addBlock(vec3(-hs.x - hls.x, -hs.y - hls.y, hs.z + hus.z), vec3(ls.x, ls.y, us.z), ci, -1, color, material, m_v00M_v0M0, corner)

    local scaleFromX = flags.scaleFromX or 0.3
    local scaleFromY = flags.scaleFromY or 0.3
    local scaleFromZ = flags.scaleFromZ or 0.3

    local scaleToX = flags.scaleToX or 1.5
    local scaleToY = flags.scaleToY or 1.5
    local scaleToZ = flags.scaleToZ or 1.5

    plan:scale(vec3(getFloat(scaleFromX, scaleToX), getFloat(scaleFromY, scaleToY), getFloat(scaleFromZ, scaleToZ)))

    local r = size * 2.0 / plan.radius
    plan:scale(vec3(r, r, r))

    plan.convex = true

    return plan
end