local v111 = vec3(1, 1, 1)
local _mat = Matrix()

local function __magSquared(v)
    return (v.x*v.x) + (v.y*v.y) + (v.z*v.z)
end

local function xCustom__sphere(plan, material, xyz, ijk)
    -- xyz is in avorion units, ijk goes from -1.0 to 1.0
    local i, j, k = ijk.x, ijk.y, ijk.z
    local magSquared = (i*i) + (j*j) + (k*k)
    local limitSquared = 0.99 -- approx 1^2
    if magSquared > limitSquared then return end
    
    local color = material.blockColor
    local blockType = BlockType.RichStone
    
    plan:addBlock(xyz, v111, 0, -1, color, material, _mat, blockType)
end

local function __sphereWithCrustMinusBites(plan, material, xyz, ijk)
    -- xyz is in avorion units, ijk goes from -1.0 to 1.0

    -- sphere
    local magSquared = __magSquared(ijk)
    local limitSquared = 0.99 -- approx 1^2
    if magSquared > limitSquared then return end
    
    -- second sphere takes a bite out
    local biteRadius = 0.7
    local biteOffset = vec3(0.5, 0.5, 0.5) - ijk
    local biteOffsetMagSquared = __magSquared(biteOffset)
    if biteOffsetMagSquared < (biteRadius*biteRadius) then return end
    
    local biteRadius = 0.7
    local biteOffset = vec3(-0.6, -0.1, -0.6) - ijk
    local biteOffsetMagSquared = __magSquared(biteOffset)
    if biteOffsetMagSquared < (biteRadius*biteRadius) then return end
    
    local color = material.blockColor
    local blockType = BlockType.RichStone
    
    -- crust
    if magSquared > (0.5 * 0.5) then blockType = BlockType.Stone end
    
    plan:addBlock(xyz, v111, 0, -1, color, material, _mat, blockType)
end

function AsteroidPlanGenerator.xShatteredPlanet(material)
    -- TODO either randomised variants, or use plan cache
    local f = __sphereWithCrustMinusBites
    return AsteroidPlanGenerator.xCustom(material, vec3(15, 15, 15), 19, f)
end

function AsteroidPlanGenerator.xCustom(material, scale, diameter, func)

    -- diameter in number of blocks
    -- scale vec3

    local plan = BlockPlan()
    local invdiameter = 1.0 / diameter

    for z = 1, diameter do
        for y = 1, diameter do
            for x = 1, diameter do
                local i = 2.0 * ((z * invdiameter) - 0.5) -- -1 to 1
                local j = 2.0 * ((y * invdiameter) - 0.5) -- -1 to 1
                local k = 2.0 * ((x * invdiameter) - 0.5) -- -1 to 1
                func(plan, material, vec3(x, y, z), vec3(i, j, k))
            end
        end
    end
    
    plan:center()
    plan:scale(scale)
    return plan
end
