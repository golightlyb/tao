include ("xSectorUtil")

function FactoryMap:initialize()
    self.seed = GameSeed()

    self.productionScripts = {
        "data/scripts/entity/merchants/factory.lua"
    }
    self.consumerScripts = {
        "data/scripts/entity/merchants/consumer.lua",
    }
    self.sellerScripts = {
        "data/scripts/entity/merchants/seller.lua",
    }
end

function FactoryMap:predictConsumptions(x, y, contents)

    local consumptions = {}

    local counts = xSectorUtil_CountsFromContent(contents)
    
    for i = 1, (counts.fortress or 0) do
        table.insert(consumptions, {goods = ConsumerGoods.XFortress()})
    end
    for i = 1, (counts.spacedock or 0) do
        table.insert(consumptions, {goods = ConsumerGoods.XSpacedock()})
    end
    for i = 1, (counts.refinery or 0) do
        table.insert(consumptions, {goods = ConsumerGoods.XRefinery()})
    end
    for i = 1, (counts.oreProcessor or 0) do
        table.insert(consumptions, {goods = ConsumerGoods.XOreProcessor()})
    end
    for i = 1, (counts.terrestrial or 0) do
        table.insert(consumptions, {goods = ConsumerGoods.XTerrestrial()})
    end
    for i = 1, (counts.mines or 0) do
        table.insert(consumptions, {goods = ConsumerGoods.XAnyMine()})
    end
    for i = 1, (counts.factories or 0) do
        table.insert(consumptions, {goods = ConsumerGoods.XAnyFactory()})
    end
    for i = 1, (counts.recycler or 0) do
        table.insert(consumptions, {goods = ConsumerGoods.XRecycler()})
    end
    for i = 1, (counts.miningColony or 0) do
        table.insert(consumptions, {goods = ConsumerGoods.XMiningColony()})
    end
    
    if #consumptions == 0 then return nil end

    return consumptions
end

function FactoryMap:predictSellers(x, y, contents)
    -- vanilla Avorion didn't implement this
    return nil
end

function FactoryMap:predictProductions(x, y, contents)
    local counts = xSectorUtil_CountsFromContent(contents)

    local factories = counts.factories or 0
    local mines = counts.mines or 0
    local oreProcessors = counts.oreProcessor or 0
    local terrestrial = counts.terrestrial or 0
    local miningColony = counts.miningColony or 0
    
    local totalProductions = {}
    if oreProcessors then
        for i = 0, oreProcessors do
            local production = productions[productionIndexOreProcessor]
            table.insert(totalProductions, production)
        end
    end
    if terrestrial then
        for i = 0, terrestrial do
            local production = productions[productionIndexTerrestrial]
            table.insert(totalProductions, production)
        end
    end
    if miningColony then
        for i = 0, miningColony do
            local production = productions[productionIndexMiningColony]
            table.insert(totalProductions, production)
        end
    end
    
    if factories > 0 then
        local productions = FactoryPredictor.generateFactoryProductions(x, y, factories)
        if productions ~= nil then
            for _, p in pairs(productions) do
                table.insert(totalProductions, p)
            end
        end
    end

    if mines > 0 then
        local productions = FactoryPredictor.generateMineProductions(x, y, mines)
        if productions ~= nil then
            for _, p in pairs(productions) do
                table.insert(totalProductions, p)
            end
        end
    end

    if #totalProductions == 0 then return nil end

    return totalProductions
end


