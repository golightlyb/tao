
function FighterGenerator.addWeapons(rand, type, dps, rarity, fighter, tech, material)
    if type ~= WeaponType.AntiFighter then
        local weapon = WeaponGenerator.generateWeapon(rand, type, dps, tech, material, rarity)
	if weapon == nil then return end

        if weapon.holdingForce ~= 0 then weapon.holdingForce = weapon.holdingForce * 0.4 end

        fighter:addWeapon(weapon)
    end

    -- adjust fire rate of fighters so they don't slow down the simulation too much
    local weapons = {fighter:getWeapons()}
    fighter:clearWeapons()

    local baseVariation = rand:getFloat(1.0, 1.15)

    for _, weapon in pairs(weapons) do
        if weapon.isProjectile and weapon.fireRate > 1 then
            local old  = weapon.fireRate
            weapon.fireRate = 1.0
            weapon.damage = weapon.damage * old / weapon.fireRate
            weapon.damage = weapon.damage * baseVariation
        end

        weapon.reach = math.min(weapon.reach, 350)

        fighter:addWeapon(weapon)
    end

    fighter:updateStaticStats()
end
