
ConsumerGoods = {}

function ConsumerGoods.XSpacedock()
    return {
        "XCarbs",
        "XProtein",
        "XAmmunition",
        "XArmor",
        "XUraniumEnriched",
        "XMetal",
        "XPrisoner",
        "XRobot",
        "XSoldier",
        "XSystem",
        "XWarhead",
        "XWorker",
    }
end

function ConsumerGoods.XRecycler()
    return {
        "XCarbs",
        "XProtein",
        "XScrapMetal",
        "XWasteToxic",
        "XWasteRadioactive",
        "XPrisoner",
        "XRobot",
        "XSoldier",
        "XWorker",
    }
end

function ConsumerGoods.XOreProcessor()
    return ConsumerGoods.XAnyMine()
end

function ConsumerGoods.XRefinery()
    return ConsumerGoods.XAnyMine()
end

function ConsumerGoods.XAnyMine()
    return {
        "XCarbs",
        "XChemicals",
        "XProtein",
        "XPrisoner",
        "XRobot",
        "XSoldier",
        "XWorker",
    }
end

function ConsumerGoods.XAnyFactory()
    return {
        "XCarbs",
        "XProtein",
        "XPrisoner",
        "XRobot",
        "XSoldier",
        "XWorker",
    }
end

function ConsumerGoods.XTerrestrial()
    return {
        "XCivilNormal",
        "XCivilLuxury",
        "XMetal",
        "XMetalPrecious",
        "XProtein",
        "XRefugee",
        "XRobot",
        "XVehicle",
    }
end

function ConsumerGoods.Habitat()
    return {"XError",} -- placeholder
end

function ConsumerGoods.Biotope()
    return {"XError",} -- placeholder
end

function ConsumerGoods.Casino()
    return {"XError",} -- placeholder
end

function ConsumerGoods.EquipmentDock()
    return {"XError",} -- placeholder
end

function ConsumerGoods.Shipyard()
    return {"XError",} -- placeholder
end

function ConsumerGoods.RepairDock()
    return {"XError",} -- placeholder
end

function ConsumerGoods.MilitaryOutpost()
    return {"XError",} -- placeholder
end

function ConsumerGoods.ResearchStation()
    return {"XError",} -- placeholder
end

function ConsumerGoods.RiftResearchStation()
    return {"XError",} -- placeholder
end

function ConsumerGoods.TravelHub()
    return {"XError",} -- placeholder
end

function ConsumerGoods.Mine()
    return {"XCarbs",} -- placeholder
end

function ConsumerGoods.TurretFactory()
    return {"XCarbs",} -- placeholder
end

-- TODO add more

