package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"

include ("randomext")
include ("xUtil")

-- Arc describes a thick line along the circumference of a circle, or a slice
-- thereof. The slice is centered at the top of the circle.

-- namespace Arc
Arc={}
Arc.__index = Arc

function Arc.newFromParams(p)

    local a = Arc.new(p.radius, p.span, p.thickness, p.depth)
    
    -- if true, the distribution of points around the radius thickness is not
    -- even on each side, but instead goes from the outside and out only.
    if p.thickenOut then a.thickenOut = true end
    
    -- if true, distribute along the circumference with a gaussian distribution,
    -- otherwise distribute uniformly. For an arc, true is better. For a ring,
    -- false is better. Defaults to true, unless it's a ring.
    if p.gaussian then
        a.gaussian = true
    elseif p.gaussian == nil then
        if p.span < 0.99 then a.gaussian = true end
    end
    
    return a
end

function Arc.new(
    -- radius of the circle; defaults to 20,000 avorion units (200km)
    radius,
    
    -- span (0 to 1) - how much of the circumference; defaults to 0.25 (a quadrant)
    span,
    
    -- thickness of the line at the circumference; defaults to radius/25 (8km)
    thickness,
    
    -- depth of the line perpendicular in 3D space to the circumference;
    -- defaults to thickness / 2.6 (approx 3km)
    depth
)
    if radius    == nil then radius    = 20000 end
    if span      == nil then span      = 0.25 end
    if thickness == nil then thickness = radius / 25 end
    if depth     == nil then depth     = thickness / 2.6 end
    
    local instance = {
        span      = span,
        radius    = radius,
        thickness = thickness,
        depth     = depth
    }
    
    return setmetatable(instance, Arc)
end

function Arc.ring(radius, thickness, depth)
    return Arc.new(radius, 1.0, thickness, depth)
end

function Arc:position(offset, genAngle)
    --genAngle -1 to 1 in either position
    offset = offset or vec3(0, 0, 0)
    
    local o = 1.0
    local thickness = self.thickness
    if self.thickenOut then
        o = 0.0
        thickness = thickness * 2
    end
    
    local f = genAngle()
    local theta = f * self.span * 0.5 -- in either direction
    local fade = xUtilGaussian(0.0, 0.1)
    local radius = self.radius + ((fade + 0.5) * getFloat(-thickness * o, thickness))
    
    local x = math.sin(theta) * radius
    local y = 0.5 * getFloat(-self.depth, self.depth) * xUtilGaussian(1.0, 0.1)
    local z = math.cos(theta) * radius
    
    return vec3(x, y, z) + offset
end

local function genAngleGaussian()
    return xUtilGaussian(0.0, 1.0) * 2.0 * math.pi
end

local function genAngleUniform()
    return getFloat(-1.0, 1.0) * 2.0 * math.pi
end

function Arc:points(mat, number)
    points = {}
    
    local genAngle = genAngleUniform
    if self.gaussian then
        genAngle = genAngleGaussian
    end
    
    local offset = mat.position -- TODO rotations
    for i = 1, number do
        points[i] = self:position(offset, genAngle)
    end
    
    return points
end

return Arc














