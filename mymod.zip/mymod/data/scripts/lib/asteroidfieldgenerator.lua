
include "xUtil"

-- custom asteroid field generation. Note that asteroid maxSize is rebalanced
-- compared to createAsteroidFieldEx, which only used 0.4 of the maxSize except
-- for rare larger barren asteroids. We'd rather generate that twice instead.
function AsteroidFieldGenerator:xCreateAsteroidField(field, points)
    
    --[[ example:
    return {
        minSize
        maxSize
        probability (0.0 to 1.0)
    }
    --]]
    
    local sector = Sector()
    -- local points = AsteroidFieldGenerator:xGenerateDisc(disc, position)
    local probabilities = Balancing_GetMaterialProbability(self.coordX, self.coordY)
    for i = 1, #points do
        local resources = false

        local resources = math.random() < field.probability
        local size = lerp(math.random(), 0, 1.0, field.minSize, field.maxSize)
        -- local size = xUtilGaussian(field.minSize, field.minSize * 0.1)

        if i % 50 == 0 then
            hiddenTreasure = true
        end

        local asteroidPosition = points[i]
        local material = Material(getValueFromDistribution(probabilities))

        local asteroid = nil
        if hiddenTreasure then
            asteroid = self:createHiddenTreasureAsteroid(asteroidPosition, size, material)
        else
            asteroid = self:createSmallAsteroid(asteroidPosition, size, resources, material)
        end
    end
    return mat
end
