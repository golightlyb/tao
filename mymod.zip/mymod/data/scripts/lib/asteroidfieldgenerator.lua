
-- edited to not make the random large barren asteroids
function AsteroidFieldGenerator:createAsteroidFieldEx(numAsteroids, fieldSize, minAsteroidSize, maxAsteroidSize, hasResources, probability)

    fieldSize = fieldSize or 2000
    minAsteroidSize = minAsteroidSize or 5.0
    maxAsteroidSize = maxAsteroidSize or 25.0
    if hasResources == false then probability = 0 end

    local asteroidsWithResources = numAsteroids * (probability or 0.05)

    asteroidsWithResources = asteroidsWithResources * GameSettings().resourceAsteroidFactor

    local asteroidFieldPosition = self:getFieldPosition()
    local asteroids = {}

    -- if no specific asteroid positions were set, create an organic cloud of asteroids
    if not self.asteroidPositions then
        local points = self:generateOrganicCloud(numAsteroids)

        self.asteroidPositions = {}
        for _, point in pairs(points) do
            table.insert(self.asteroidPositions, asteroidFieldPosition:transformCoord(point))
        end
    end

    for i = 1, numAsteroids do
        local resources = false
        if asteroidsWithResources > 0 then
            resources = true
            asteroidsWithResources = asteroidsWithResources - 1
        end

        -- create asteroid size from those min/max values and the actual value
        local size
        local hiddenTreasure = false

        --if math.random() < 0.15 then
            -- create a bigger asteroid, but without resources
            --size = lerp(math.random(), 0, 1.0, minAsteroidSize, maxAsteroidSize);
            --if resources then
            --    resources = false
            --    asteroidsWithResources = asteroidsWithResources + 1
            --end
        --else
            -- normal asteroid
            size = lerp(math.random(), 0, 2.5, minAsteroidSize, maxAsteroidSize);
        --end

        if math.random() < (1 / 50) then
            hiddenTreasure = true
        end

        local asteroidPosition = self:getNextAsteroidPosition(asteroidFieldPosition, fieldSize)
        local material = self:getAsteroidType()

        local asteroid = nil
        if hiddenTreasure then
            asteroid = self:createHiddenTreasureAsteroid(asteroidPosition, size, material)
        else
            asteroid = self:createSmallAsteroid(asteroidPosition, size, resources, material)
        end
        table.insert(asteroids, asteroid)
    end

    -- clear the asteroid positions once they're empty
    if self.asteroidPositions and #self.asteroidPositions == 0 then
        self.asteroidPositions = nil
    end

    return asteroidFieldPosition, asteroids
end

