
-- disable all vanilla buffs
function SpawnUtility.addEnemyBuffs(ships)
    -- apply Resistances
    -- SpawnUtility.applyResistanceBuffs(ships)
    -- then weaknesses - checks to not have same type of resistance and weakness on one ship
    -- SpawnUtility.applyWeaknessBuffs(ships)
    -- now apply toughness buffs, resi factors are increased if necessary
    -- SpawnUtility.applyToughnessBuffs(ships)
end
