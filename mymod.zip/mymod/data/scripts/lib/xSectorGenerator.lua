
package.path = package.path .. ";data/scripts/lib/?.lua"
package.path = package.path .. ";data/scripts/?.lua"
include ("randomext")
include ("galaxy")
include ("utility")
include ("stringutility")
include ("defaultscripts")
include ("goods")
include ("merchantutility")

local PlanGenerator = include ("plangenerator")
local AsteroidPlanGenerator = include ("asteroidplangenerator")
local AsteroidFieldGenerator = include ("asteroidfieldgenerator")
local ShipUtility = include ("shiputility")
local ConsumerGoods = include ("consumergoods")
local FactoryPredictor = include("factorypredictor")
local SectorTurretGenerator = include("sectorturretgenerator")
local Placer = include("placer")
local XShipGenerator = include("xShipGenerator")
local VanillaSectorGenerator = include("SectorGenerator")

include ("galaxy/xPlanCache") -- syntax check

local Shape = include ("xShapes/shape")
include ("xUtil")
include ("xSectorUtil")

local assert = assert

-- namespace XSectorGenerator
local XSectorGenerator = {}
XSectorGenerator.__index = XSectorGenerator

local function new(x, y, sector, faction, offGrid, random)
    assert(type(x) == "number" and type(y) == "number", "New XSectorGenerator expects 2 numbers")
    if offGrid == nil then offGrid = false end
    local instance = {
        x = x,
        y = y,
        sector = (sector or Sector()),
        galaxy = Galaxy(),
        faction = faction,
        offGrid = offGrid,
        asteroidFieldGenerator = AsteroidFieldGenerator(x, y),
        pWormhole = 1/60, -- vanilla
        random = random,
    }
    return setmetatable(instance, XSectorGenerator)
end

function XSectorGenerator:LocalArms()
    if self.arms ~= nil then return self.arms end
    
    local x, y = self.x, self.y
    local turretGenerator = SectorTurretGenerator()
    self.arms = {
        gun     = turretGenerator:generate(x, y, 0, Rarity(RarityType.Exceptional), WeaponType.XGun),
        missile = turretGenerator:generate(x, y, 0, Rarity(RarityType.Exceptional), WeaponType.XMissile),
        cannon  = turretGenerator:generate(x, y, 0, Rarity(RarityType.Exceptional), WeaponType.XCannon),
        
        -- AI background ships need a vanilla mining laser. They're broken anyway...
        mining  = turretGenerator:generate(x, y, 0, Rarity(RarityType.Exceptional), WeaponType.RawMiningLaser),
    }
    return self.arms
end

function XSectorGenerator:addAmbientEvents(cfg)
    if self.offGrid then
        self:addOffgridAmbientEvents(cfg)
    else
        self:addOnGridAmbientEvents(cfg)
    end
end

function XSectorGenerator:addOnGridAmbientEvents(cfg)
    cfg = cfg or {}
    if not cfg.noTraffic then
        self.sector:addScriptOnce("sector/passingships.lua")
        self.sector:addScriptOnce("sector/traders.lua")
    end
    if not cfg.noFactionWar then
        self.sector:addScriptOnce("sector/factionwar/initfactionwar.lua")
    end
end

function XSectorGenerator:addOffgridAmbientEvents(cfg)
end

function XSectorGenerator:addStationScripts(station, cfg)
    cfg = cfg or {}

    if not cfg.noBackup then
        station:addScriptOnce("data/scripts/entity/backup.lua")
    end
    if not cfg.noDocks then
        station:addScriptOnce("data/scripts/entity/regrowdocks.lua")
    end
    if not cfg.noCrewBoard then
        station:addScriptOnce("data/scripts/entity/crewboard.lua")
    end
    if not cfg.noBuilding then
        station:addScriptOnce("data/scripts/entity/startbuilding.lua")
    end
    if not cfg.noEnter then
        station:addScriptOnce("data/scripts/entity/entercraft.lua")
        station:addScriptOnce("data/scripts/entity/exitcraft.lua")
    end
    if not cfg.noInventory then
        station:addScriptOnce("data/scripts/entity/transfercrewgoods.lua")
    end
    if not cfg.noTransport then
        station:addScriptOnce("data/scripts/entity/utility/transportmode.lua")
    end
    
    if cfg.noDocks then
        station.dockable = false
    end
    if cfg.noBoarding then
        Boarding(station).boardable = false
    else
        SetBoardingDefenseLevel(station)
    end
    
    station.crew = station.idealCrew
    station.shieldDurability = station.shieldMaxDurability
    Physics(station).driftDecrease = 0.2
    station:setDropsLoot(false)
end

function XSectorGenerator:createMineTrap(position)
    local desc = EntityDescriptor()

    desc:addComponents(
        ComponentType.Plan,
        ComponentType.BspTree,
        ComponentType.Intersection,
        ComponentType.Asleep,
        ComponentType.DamageContributors,
        ComponentType.BoundingSphere,
        ComponentType.BoundingBox,
        ComponentType.Velocity,
        ComponentType.Physics,
        ComponentType.Scripts,
        ComponentType.ScriptCallback,
        ComponentType.Title,
        ComponentType.InteractionText,
        ComponentType.Owner,                -- needed for onDamage?
        ComponentType.FactionNotifier,      -- needed for onDamage?
        ComponentType.Durability,
        ComponentType.PlanMaxDurability
    )
       
    local plan = xPlanCache_FromFile(self.galaxy, "data/plans/MineTrap.xml")
    desc.position = xUtilRandomAxisAlignedMatrixFromCoordinates(position)
    desc:setMovePlan(plan)
    
    local e = self.sector:createEntity(desc)
    e:addScript("data/scripts/entity/xMineTrap.lua")
    return e
end

local containerPlan = PlanGenerator.makeContainerPlan()
function XSectorGenerator:createStash(position)
    local desc = EntityDescriptor()
    desc.type = EntityType.Container
    desc:addComponents(
       ComponentType.Plan,
       ComponentType.BspTree,
       ComponentType.Intersection,
       ComponentType.Asleep,
       ComponentType.DamageContributors,
       ComponentType.BoundingSphere,
       ComponentType.BoundingBox,
       ComponentType.Velocity,
       ComponentType.Physics,
       ComponentType.Scripts,
       ComponentType.ScriptCallback,
       ComponentType.Title,
       ComponentType.Owner,
       ComponentType.FactionNotifier,
       ComponentType.WreckageCreator,
       ComponentType.InteractionText,
       ComponentType.Loot
    )
    desc.position = xUtilRandomAxisAlignedMatrixFromCoordinates(position)
    desc:setPlan(containerPlan)
    
    local e = self.sector:createEntity(desc)
    e:addScript("stash.lua")
    e.title = "Lost Cargo"%_t
    return e
end

function XSectorGenerator:createStationFromPlan(plan, position, faction, arms, styleName, scriptCfg, scriptPath, ...)

    -- local styleName = PlanGenerator.determineStationStyleFromScriptArguments(scriptPath, ...)

    if plan == nil then
        -- balancing volume by home sector helps out the cache
        local volume = Balancing_GetSectorStationVolume(faction:getHomeSectorCoordinates())
        local material = PlanGenerator.selectMaterial(faction)
        plan = xPlanCache_GeneratedStation(self.galaxy, faction, volume, styleName, material)
    end
    if plan == nil then
        printlog("XSectorGenerator: error while obtaining a station plan")
        return
    end

    local position = xUtilRandomAxisAlignedMatrixFromCoordinates(position)
    local station
    
    -- has to be done like this, passing nil for a string doesn't work
    if scriptPath then
        station = Sector():createStation(faction, plan, position, scriptPath, ...)
    else
        station = Sector():createStation(faction, plan, position)
    end

    if arms then
        local turrets = {}
        local choices = self:LocalArms()
        for i = 1, #arms do
            local arm = arms[i]
            table.insert(turrets, {turret=choices[arm.variant], num=arm.num, limit=arm.limit})
        end
        ShipUtility.xArm(station, turrets)
        station:addScript("ai/patrol.lua")
        station:setValue("is_armed", true)
    end
    
    self:addStationScripts(station, scriptCfg)
    return station
end

function XSectorGenerator:createCustomStation(position, faction, arms, cfg, planFile, scale, planScript)
    local plan = xPlanCache_FromFile(self.galaxy, planFile)
    if plan == nil then return end
    
    local material = Material(Balancing_GetHighestAvailableMaterial(self.x, self.y))
    plan:setMaterial(material)
    if scale then plan:scale(scale) end
    
    local station = self:createStationFromPlan(plan, position, faction, arms, "", cfg, planScript)
    station:setValue("npc_chatter", true)
    return station
end

function XSectorGenerator:createDefensePlatform(position, faction, arms)
    local scale = vec3(4.0, 4.0, 4.0)
    local cfg   = {
        noDocks     = true,
        noCrewBoard = true,
        noBoarding  = true,
        noBuilding  = true,
        noEnter     = true,
        noInventory = true,
        noTransport = true,
    }
    return self:createCustomStation(position, faction, arms, cfg, "data/plans/DefensePlatform.xml", scale, "data/scripts/entity/xDefensePlatform.lua")
end

function XSectorGenerator:createFortress(position, faction, arms)
    local scale = vec3(4.0, 4.0, 4.0)
    local cfg   = {
        noBuilding  = true,
        noEnter     = true,
        noTransport = true,
    }
    return self:createStationFromPlan(nil, position, faction, arms, StationSubType.MilitaryOutpost, cfg, "data/scripts/entity/merchants/xFortress.lua")
end

function XSectorGenerator:createMiningColony(position, faction)
    local scale = vec3(1.0, 1.0, 1.0)
    return self:createCustomStation(position, faction, nil, nil, "data/plans/MiningColony.xml", scale, "data/scripts/entity/merchants/xMiningColony.lua")
end

local stationArms = {
    spacedock = {
        {variant="cannon", num=6, limit=12},
    },
    fortress = {
        {variant="cannon", num=12, limit=16},
    },
    defensePlatform = {
        {variant="cannon", num=2, limit=2},
    },
}

local basicStationVariants = {
    spacedock    = {subtype=StationSubType.RepairDock,      script="data/scripts/entity/merchants/xSpacedock.lua"},
    refinery     = {subtype=StationSubType.ResourceDepot,   script="data/scripts/entity/merchants/xRefinery.lua"},
    oreProcessor = {subtype=StationSubType.ResourceDepot,   script="data/scripts/entity/merchants/xOreProcessor.lua"},
    tradingPost  = {subtype=StationSubType.TradingPost,     script="data/scripts/entity/merchants/tradingpost.lua"},
    terrestrial  = {subtype=StationSubType.TradingPost,     script="data/scripts/entity/merchants/xTerrestrial.lua"},
    recycler     = {subtype=StationSubType.ResourceDepot,   script="data/scripts/entity/merchants/xRecycler.lua"},
}

local otherStationVariants = {
    fortress        = {createFunc=XSectorGenerator.createFortress},
    defensePlatform = {createFunc=XSectorGenerator.createDefensePlatform},
    miningColony    = {createFunc=XSectorGenerator.createMiningColony},
}

function XSectorGenerator:createStationsFromPoints(points, stations)
    local pointOffset = 1
    local function nextPoint(offset)
        if pointOffset > #points then
            eprint("XSectorGenerator: out of points")
            return vec3(0, 0, 0)
        end
        local point = points[pointOffset] + offset
        pointOffset = pointOffset + 1
        return point
    end
    
    for i = 1, #stations do
        local station = stations[i]
        local offset = station.offset or vec3(0, 0, 0)
        local variant = station.variant or ""
        local faction = self.faction or station.faction
        
        local basicStation = basicStationVariants[variant]
        if basicStation then
            local arms = stationArms[variant]
            local faction = station.faction or self.faction
            self:createStationFromPlan(nil, nextPoint(offset), faction, arms, basicStation.subtype, nil, basicStation.script)
            goto continue
        end
        
        local getPlan = nil
        local generateProductions = nil
        if variant == "factories" then
            generateProductions = FactoryPredictor.generateFactoryProductions
        elseif variant == "mines" then
            generateProductions = FactoryPredictor.generateMineProductions
            getPlan = function() return xPlanCache_FromFile(self.galaxy, "data/plans/MineTemplate.xml") end
        end
        if generateProductions then
            local number = (station.number or 1)
            local productions = generateProductions(self.x, self.y, number)
            if productions then
                for j, production in pairs(productions) do
                    local plan = nil
                    if getPlan then plan = getPlan() end
                    self:createStationFromPlan(plan, nextPoint(offset), self.faction, nil, production.factoryStyle, nil, "data/scripts/entity/merchants/factory.lua", production)
                end
            else
                print("XSectorGenerator: no "..variant.." productions for "..x..", "..y)
            end
            
            goto continue
        end
        
        local otherStation = otherStationVariants[variant]
        if otherStation then
            local arms = stationArms[variant]
            local fn = otherStation.createFunc
            fn(self, nextPoint(offset), faction, arms)
            goto continue
        end
        
        eprint("unknown station type: "..variant)
        
        ::continue::
    end
end

local shipArms = {
    garrison = {
        {variant="cannon", num=3, limit=6},
    },
    pirate = {
        {variant="cannon", num=1, limit=2},
    },
    miner = {
        {variant="mining", num=1, limit=1},
    },
    antipirate = {
        {variant="cannon", num=3, limit=6},
    },
}

local shipCreator = {
    garrison   = XShipGenerator.createDefender,
    miner      = XShipGenerator.createMiner,
    pirate     = XShipGenerator.createPirate,
    antipirate = XShipGenerator.createAntipirate,
}

function XSectorGenerator:createShipsFromPoints(points, ships)
    local pointOffset = 1
    local function nextPoint(offset)
        if pointOffset > #points then
            eprint("XSectorGenerator: out of points")
            return vec3(0, 0, 0)
        end
        local point = points[pointOffset] + offset
        pointOffset = pointOffset + 1
        return point
    end

    for i = 1, #ships do
        local ship = ships[i]
        local offset = ship.offset or vec3(0, 0, 0)
        local faction = ship.faction or self.faction
        local variant = ship.variant or ""
        local arms = shipArms[variant]

        local turrets = nil
        if arms then
            turrets = {}
            local choices = self:LocalArms()
            for i = 1, #arms do
                local arm = arms[i]
                table.insert(turrets, {turret=choices[arm.variant], num=arm.num, limit=arm.limit})
            end
        end
        
        local createFunc = shipCreator[variant]
        if createFunc == nil then
            eprint("invalid ship variant "..variant)
            return
        end
        for j = 1, (ship.number or 1) do
            local mat = xUtilRandomAxisAlignedMatrixFromCoordinates(nextPoint(offset))
            local created = createFunc(faction, mat, turrets, ship.scale)
            if not created then
                print("xSectorGenerator: error creating a ship with createFunc: "..variant)
            end
            if ship.defender then created:setValue("is_defender", true) end
            if ship.post then ship.post(created) end
        end
    end
end

function XSectorGenerator:createAsteroidsFromPoints(points, field)
    field = field or {}
    field = {
        number      = field.number or 1000,
        minSize     = field.minSize or  3,
        maxSize     = field.maxSize or 22,
        probability = field.probability,
    }
    if field.probability == nil then field.probability = 0.05 end

    self.asteroidFieldGenerator:xCreateAsteroidField(points, field)
end

function XSectorGenerator:createContentsFromShape(mat, shape)
    -- shape {variant="...", params={...}, asteroids={...}, stations={...} }
    mat = translate(mat, shape.offset or vec3(0, 0, 0))
    local pointGenerator = Shape.new(shape.variant, shape.params)
    
    if shape.asteroids then
        local points = pointGenerator:points(mat, shape.asteroids.number)
        self:createAsteroidsFromPoints(points, shape.asteroids)
    end
    if shape.stations then
        local points = pointGenerator:points(mat, xSectorUtil_CountTotal(shape.stations))
        self:createStationsFromPoints(points, shape.stations)
    end
    if shape.ships then
        local points = pointGenerator:points(mat, xSectorUtil_CountTotal(shape.ships))
        self:createShipsFromPoints(points, shape.ships)
    end
    if shape.mineTraps then
        local points = pointGenerator:points(mat, shape.mineTraps)
        for i = 1, shape.mineTraps do
            self:createMineTrap(points[i])
        end
    end
    if shape.stashes then
        local points = pointGenerator:points(mat, shape.stashes)
        for i = 1, shape.stashes do
            self:createStash(points[i])
        end
    end
    
    if shape.features then
        for i = 1, #shape.features do
            self:createContentsFromFeature(shape.features[i])
        end
    end
    
    points = nil
end

local featureVariants = {
    ignore = {
        createFunc=(function(xsg, mat); end)
    },
    shatteredPlanet = {
        createFunc=(function(xsg, mat)
            local plan = AsteroidPlanGenerator().xShatteredPlanet(Material(0)) -- iron core
            xsg.sector:createAsteroid(plan, true, mat)
        end)
    },
}

function XSectorGenerator:createContentsFromFeature(mat, feature)
    -- arc { params={...}, asteroids={...}, stations={...} }
    mat = translate(mat, feature.offset or vec3(0, 0, 0))
    
    local variant = featureVariants[feature.variant or ""]
    if variant then
        local fn = variant.createFunc
        fn(self, mat)
    else
        eprint("unknown feature variant "..(feature.variant or ""))
    end
    
    local shapes = feature.shapes or {}
    for i = 1, #shapes do
        self:createContentsFromShape(mat, shapes[i])
    end
end

local eventFuncs = {
    pirateAttack=(function(xsg, event)
        xsg:scheduleEvent("events/xpirateattack.lua", 30 * 60) -- 30 mins
    end),
}

function XSectorGenerator:scheduleEvent(script, frequency)
    self.sector:addScriptOnce("data/scripts/sector/eventscheduler.lua")
    local ok, _ = self.sector:invokeFunction("data/scripts/sector/eventscheduler.lua", "addEvent", script, frequency)
    if not ok then
        eprint("failed to schedule event: "..script)
        return nil
    end
end

function XSectorGenerator:initEvent(event)
    local eventFunc = eventFuncs[event.variant or ""]
    if eventFunc then
        eventFunc(self, event)
    else
        eprint("unknown event variant "..(event.variant or ""))
    end
end

function XSectorGenerator:createContents(contents)
    local x = contents.x or {}
    
    local shapes = x.shapes or {}
    for i = 1, #shapes do
        self:createContentsFromShape(Matrix(), shapes[i])
    end
    
    local features = x.features or {}
    for i = 1, #features do
        self:createContentsFromFeature(Matrix(), features[i])
    end
    
    local events = x.events or {}
    for i = 1, #events do
        self:initEvent(events[i])
    end
    
    if not x.noSector then
        local vsg = VanillaSectorGenerator(self.x, self.y)
        if x.hasGates then vsg:createGates() end
        if self.random:test(vsg:getWormHoleProbability()) then vsg:createRandomWormHole() end
        self:addAmbientEvents()
        Placer.resolveIntersections()
    end
end

return setmetatable({new = new}, {__call = function(_, ...) return new(...) end})
