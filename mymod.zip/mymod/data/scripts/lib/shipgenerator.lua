include ("xUtil")

function ShipGenerator.xCreateShip(faction, planType, position, volume, styleName, material)
    local galaxy = Galaxy()
    local sector = Sector()
    
    position = position or Matrix()
    volume = volume or Balancing_GetSectorShipVolume(sector:getCoordinates()) * Balancing_GetShipVolumeDeviation()
    material = material or PlanGenerator.selectMaterial(faction)

    local plan = xPlanCache_Generated(galaxy, planType, faction, volume, nil, material)
    local ship = sector():createShip(faction, "", plan, position)
    if not ship then
        eprint("ShipGenerator error")
        return
    end

    ship.crew = ship.idealCrew
    ship.shieldDurability = ship.shieldMaxDurability

    AddDefaultShipScripts(ship)
    SetBoardingDefenseLevel(ship)

    return ship
end

function ShipGenerator.xCreateDefender(faction, position, arms, title)
    if not title then title = "Garrison" end

    -- defenders should be a lot beefier than the normal ships
    
    -- optimisation: vanilla Avorion always balanced defenders by home sector
    --   strength, and that really helps out the plan cache!!!
    
    local volume = Balancing_GetSectorShipVolume(faction:getHomeSectorCoordinates()) * 7.5

    local ship = ShipGenerator.xCreateShip(faction, "Ship", position, volume)
    if not ship then return end
    ShipUtility.xArm(ship, arms)
    
    ship.crew = ship.idealCrew
    ship.title = title .. " " .. ShipUtility.getMilitaryNameByVolume(ship.volume)
    ship.shieldDurability = ship.shieldMaxDurability
    ship.damageMultiplier = ship.damageMultiplier * 4

    ship:addScript("ai/patrol.lua")
    ship:addScript("antismuggle.lua")
    ship:setValue("is_armed", true)
    ship:setValue("is_defender", true)
    ship:setValue("npc_chatter", true)
    
    -- dont drop
    ship:setDropsLoot(false)
    ship:addScript("icon.lua", "data/textures/icons/pixel/shield.png")

    return ship
end

function ShipGenerator.xCreateMiner(faction, position, arms)

    -- miners should be quite big
    
    -- local volume =  Balancing_GetSectorShipVolume(Sector():getCoordinates()) * Balancing_GetShipVolumeDeviation()
    
    -- optimisation: balance miners by home sector to help out the plan cache
    local volume = Balancing_GetSectorShipVolume(faction:getHomeSectorCoordinates()) * 7.5

    local ship = ShipGenerator.xCreateShip(faction, "Miner", position, volume)
    if not ship then return end
    ShipUtility.xArm(ship, arms)
    
    ship.crew = ship.idealCrew
    ship.title = ShipUtility.getMinerNameByVolume(ship.volume)
    ship.shieldDurability = ship.shieldMaxDurability

    ship:addScript("ai/mine.lua")
    ship:addScript("civilship.lua")
    ship:setValue("is_civil", true)
    ship:setValue("is_miner", true)
    ship:setValue("npc_chatter", true)
    
    -- dont drop
    ship:setDropsLoot(false)
    ship:addScript("icon.lua", "data/textures/icons/pixel/mining.png")

    return ship
end