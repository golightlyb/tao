
function ShipGenerator.createCarrier(faction, position, fighters)
    return ShipGenerator.createDefender(faction, position)
end

local old_ShipGenerator_createDefender = ShipGenerator.createDefender
function ShipGenerator.createDefender(faction, position)
    local ship = old_ShipGenerator_createDefender(faction, position)
    ship:setDropsLoot(false)
    return ship
end