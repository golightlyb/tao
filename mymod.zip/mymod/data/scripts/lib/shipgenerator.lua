include ("xUtil")

function ShipGenerator.xCreateShip(faction, planType, position, volume, styleName, material)
    local galaxy = Galaxy()
    local sector = Sector()
    
    position = position or Matrix()
    volume = volume or Balancing_GetSectorShipVolume(sector:getCoordinates()) * Balancing_GetShipVolumeDeviation()
    material = material or PlanGenerator.selectMaterial(faction)

    local plan = xPlanCache_Generated(galaxy, planType, faction, volume, nil, material)
    local ship = sector():createShip(faction, "", plan, position)
    if not ship then
        eprint("ShipGenerator error")
        return
    end

    ship.crew = ship.idealCrew
    ship.shieldDurability = ship.shieldMaxDurability

    AddDefaultShipScripts(ship)
    SetBoardingDefenseLevel(ship)

    return ship
end

function ShipGenerator.xCreateDefender(faction, position, arms)

    -- defenders should be a lot beefier than the normal ships
    local volume = Balancing_GetSectorShipVolume(faction:getHomeSectorCoordinates()) * 7.5

    local ship = ShipGenerator.xCreateShip(faction, "Ship", position, volume)
    if not ship then return end
    ShipUtility.xArm(ship, arms)
    
    ship.crew = ship.idealCrew
    ship.title = "Garrison " .. ShipUtility.getMilitaryNameByVolume(ship.volume)
    ship.shieldDurability = ship.shieldMaxDurability
    ship.damageMultiplier = ship.damageMultiplier * 4

    ship:addScript("ai/patrol.lua")
    ship:addScript("antismuggle.lua")
    ship:setValue("is_armed", true)
    ship:setValue("is_defender", true)
    ship:setValue("npc_chatter", true)
    
    -- dont drop
    ship:setDropsLoot(false)
    ship:addScript("icon.lua", "data/textures/icons/pixel/shield.png")

    return ship
end