

include("xUtil")
local FactoryPredictor = include("factorypredictor")
local SectorTurretGenerator = include("sectorturretgenerator")
local Placer = include("placer")
local ShipGenerator = include("shipgenerator")

function SectorGenerator:createStash(worldMatrix, title)
    local plan = PlanGenerator.makeContainerPlan()
    local container = self:createContainer(plan, worldMatrix, 0)
    container.title = ""
    container:addScript("stash.lua")
    container.title = title or "Secret Stash"%_t
    return container
end

function SectorGenerator:wormHoleAllowed(from, to)

    self.passageMap = self.passageMap or PassageMap(Server().seed)

    -- a wormhole can't be inside an unpassable sector
    if not self.passageMap:passable(from.x, from.y) or not self.passageMap:passable(to.x, to.y) then
        return false
    end

    -- in our overhaul, we allow wormholes across the ring!!!
    
    -- if they're not either both inside or both outside, then the wormhole crosses the ring -> illegal
    -- if self.passageMap:insideRing(from.x, from.y) ~= self.passageMap:insideRing(to.x, to.y) then
    --    return false
    -- end

    return true
end

function SectorGenerator:createWreckage(faction, plan, breaks, position)
    local wreckages = {SectorGenerator:createUnstrippedWreckage(faction, plan, breaks, position)}

    for _, wreckage in pairs(wreckages) do
        --if random():test(self.chanceForCaptainLogWreckage) then
        --    wreckage:addScriptOnce("data/scripts/entity/story/captainslogs.lua")
        --end
        if random():test(1 - self.chanceForUnstrippedWreckage) then
            ShipUtility.stripWreckage(wreckage)
        end

        local deletionTimer = DeletionTimer(wreckage)
        if valid(deletionTimer) then
            deletionTimer:disable()
        end
    end

    return unpack(wreckages)
end



