
include("music")
local FactoryPredictor = include("factorypredictor")
local SectorTurretGenerator = include("sectorturretgenerator")
local Placer = include("placer")
local ShipGenerator = include("shipgenerator")

function SectorGenerator:createStash(worldMatrix, title)
    local plan = PlanGenerator.makeContainerPlan()
    local container = self:createContainer(plan, worldMatrix, 0)
    container.title = ""
    container:addScript("stash.lua")
    container.title = title or "Secret Stash"%_t
    return container
end

function SectorGenerator:createBeacon(position, faction, text, args)
end

function SectorGenerator:createContainerField(sizeX, sizeY, circular, position, factionIndex, hackables)
end

function SectorGenerator:generateStationContainers(station, sizeX, sizeY, circular)
end

function SectorGenerator:createWreckage(faction, plan, breaks, position)
    local wreckages = {SectorGenerator:createUnstrippedWreckage(faction, plan, breaks, position)}

    for _, wreckage in pairs(wreckages) do
        --if random():test(self.chanceForCaptainLogWreckage) then
        --    wreckage:addScriptOnce("data/scripts/entity/story/captainslogs.lua")
        --end
        if random():test(1 - self.chanceForUnstrippedWreckage) then
            ShipUtility.stripWreckage(wreckage)
        end

        local deletionTimer = DeletionTimer(wreckage)
        if valid(deletionTimer) then
            deletionTimer:disable()
        end
    end

    return unpack(wreckages)
end

local function removeBulletinBoard(station)
    station:removeScript("bulletinboard.lua")
    station:removeScript("missionbulletins.lua")
    station:removeScript("story/bulletins.lua")
end

function SectorGenerator:xCreateSpacedock(faction) -- legacy
    return SectorGenerator:xSpacedock(faction)
end

function SectorGenerator:xSpacedock(faction)
    local station = self:xCreateStation(faction, StationSubType.RepairDock, "data/scripts/entity/merchants/xSpacedock.lua")
    ShipUtility.addArmedTurretsToCraft(station)
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xRefinery(faction)
    local station = self:xCreateStation(faction, StationSubType.ResourceDepot, "data/scripts/entity/merchants/xRefinery.lua")
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xOreProcessor(faction)
    local station = self:xCreateStation(faction, StationSubType.ResourceDepot, "data/scripts/entity/merchants/xOreProcessor.lua")
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xTradingpost(faction)
    local station = self:xCreateStation(faction, StationSubType.TradingPost, "data/scripts/entity/merchants/tradingpost.lua")
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xTerrestrial(faction)
    local station = self:xCreateStation(faction, StationSubType.TradingPost, "data/scripts/entity/merchants/xTerrestrial.lua")
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xRecycler(faction)
    local station = self:xCreateStation(faction, StationSubType.ResourceDepot, "data/scripts/entity/merchants/xRecycler.lua")
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xFactory(faction, production)
    local station = self:xCreateStation(faction, production.factoryStyle, "data/scripts/entity/merchants/factory.lua", production)
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xFactories(faction, x, y, num)
    if num then
        local productions = FactoryPredictor.generateFactoryProductions(x, y, num)
        if productions then
            for _, production in pairs(productions) do
                self:xFactory(faction, production)
            end
        else
            print("SectorGenerator: no factory productions for "..x..", "..y)
        end
    end
end

function SectorGenerator:xMines(faction, x, y, num)
    if num then
        local productions = FactoryPredictor.generateMineProductions(x, y, num)
        if productions then
            for _, production in pairs(productions) do
                self:xFactory(faction, production)
            end
        else
            print("SectorGenerator: no mine productions for "..x..", "..y)
        end
    end
end

function SectorGenerator:xDefaultMusicTracks()
    local good = {
        primary = TrackCollection.HappyNeutral(),
        secondary = combine(TrackCollection.Happy(), TrackCollection.Neutral()),
    }

    local neutral = {
        primary = TrackCollection.Neutral(),
        secondary = TrackCollection.All(),
    }

    local bad = {
        primary = combine(TrackCollection.Middle(), TrackCollection.Desolate()),
        secondary = TrackCollection.Neutral(),
    }

    return good, neutral, bad
end

function SectorGenerator:xFromContents(player, contents, random, faction, otherFaction)
    local x = self.coordX
    local y = self.coordY

    for i = 1, (contents.xSpacedock or 0) do
        self:xSpacedock(faction)
    end
    for i = 1, (contents.xRefinery or 0) do
        self:xRefinery(faction)
    end
    for i = 1, (contents.xOreProcessor or 0) do
        self:xOreProcessor(faction)
    end
    for i = 1, (contents.xRecycler or 0) do
        self:xRecycler(faction)
    end
    for i = 1, (contents.xDefensePlatforms or 0) do
        self:xDefensePlatform(faction)
    end
    for i = 1, (contents.xTrader or 0) do
        self:xTradingpost(faction)
    end
    for i = 1, (contents.xTerrestrial or 0) do
        self:xTerrestrial(faction)
    end
    
    self:xMines(faction, x, y, (contents.xMines or 0))
    self:xFactories(faction, x, y, (contents.xFactories or 0))
    
    for i = 1, (contents.xNormalFields or 0) do
        local position = self:createAsteroidField(0.075);
        if random:test(0.35) then self:createBigAsteroid(position) end
    end

    for i = 1, (contents.xSmallFields or 0) do
        local mat = self:createSmallAsteroidField()
        if random:test(0.2) then self:createStash(mat) end
    end

    for i = 1, (contents.xClaimableAsteroids or 0) do
        local mat = self:createAsteroidField()
        local asteroid = self:createClaimableAsteroid()
        asteroid.position = mat
    end
    
    for i = 1, (contents.defenders or 0) do
        ShipGenerator.createDefender(faction, self:getPositionInSector())
    end
    
    if contents.xHasGates then self:createGates() end
    if random:test(self:getWormHoleProbability()) then generator:createRandomWormHole() end
    
    if contents.xHasPirateAttacks then
        -- TODO allow multiple events scheduled
        Sector():addScriptOnce("data/scripts/sector/eventscheduler.lua", "events/pirateattack.lua")
    end
    
    self:addAmbientEvents()
    Placer.resolveIntersections()
end



-- TODO move this cache into the galaxy entity instead

local _cachedPlans = {}
local _cachedHits  = 0
function SectorGenerator.xPlanFromFile(path)
    local plan = _cachedPlans[path]
    
    if plan == nil then
        plan = LoadPlanFromFile(path)
        if plan == nil then
            _cachedPlans[path] = "error"
            eprint("SectorGenerator: error loading plan: "..path)
            return nil
        end
        _cachedPlans[path] = plan
    elseif plan == "error" then
        eprint("SectorGenerator: ignoring plan due to previous error: "..path)
        return nil
    else
        _cachedHits = _cachedHits + 1
    end
    
    return copy(plan)
end

function SectorGenerator.xClearCache()
    local total = _cachedHits
    _cachedPlans = {}
    _cachedHits  = {}
    if total > 0 then
        local x, y = Sector():getCoordinates()
        print("SectorGenerator at "..x..", "..y..": plan cache had "..total.." hits.")
    end
end

function SectorGenerator:xDefensePlatform(faction, material, scale)
    local plan = SectorGenerator.xPlanFromFile("data/plans/DefensePlatform.xml")
    
    -- TODO could cache these
    local armed = {}
    
    local turretGenerator = SectorTurretGenerator()
    local cannon = turretGenerator:generate(self.coordX, self.coordY, 0, Rarity(RarityType.Exceptional), WeaponType.XCannon)
    
    table.insert(armed, {turret=cannon, num=2})
    
    local station = self:xCreateBasicStationFromPlan(faction, plan, material, scale, armed, "data/scripts/entity/xDefensePlatform.lua")
    Boarding(station).boardable = false
    station.dockable = false
    return station
end

function SectorGenerator:xCreateBasicStationFromPlan(faction, plan, material, scale, armed, scriptPath, ...)
    if material == nil then
        material = Material(Balancing_GetHighestAvailableMaterial(self.coordX, self.coordY))
    end
    if not scale then
        scale = vec3(1.0, 1.0, 1.0)
    end
    
    -- its a very small plan
    scale = scale * 4.0
    
    if plan == nil then
        eprint("SectorGenerator: nil plan")
        return nil
    end
    plan:setMaterial(material)
    plan:scale(scale)
    local position = self:findStationPositionInSector(plan.radius)
    local station
    
        -- has to be done like this, passing nil for a string doesn't work
    if scriptPath then
        station = Sector():createStation(faction, plan, position, scriptPath, ...)
    else
        station = Sector():createStation(faction, plan, position)
    end
    if station == nil then
        eprint("SectorGenerator: error creating station")
        return nil
    end
    
    if armed then
        for i = 1,#armed do
            local turret = armed[i].turret
            local num = armed[i].num
            ShipUtility.addTurretsToCraft(station, turret, num, num)
        end
    end
        
    self:xPostBasicStationCreation(station)
    station:setDropsLoot(false)
    return station
end

function SectorGenerator:xPostBasicStationCreation(station)
    station:addScriptOnce("data/scripts/entity/backup.lua")
    SetBoardingDefenseLevel(station)
    station.crew = station.idealCrew
    station.shieldDurability = station.shieldMaxDurability
    Physics(station).driftDecrease = 0.2
end

function SectorGenerator:addAmbientEvents()
    Sector():addScriptOnce("sector/passingships.lua")
    Sector():addScriptOnce("sector/traders.lua")
    Sector():addScriptOnce("sector/factionwar/initfactionwar.lua")
    -- TODO extras
end

function SectorGenerator:estimateAsteroidNumbers(normal, small, dense)
    normal = normal or 0
    small = small or 0
    dense = dense or 0

    -- we tweaked the generators to generate fewer asteroids but generally richer
    return math.ceil(normal * self.normalFieldAsteroids * 0.2 + small * self.smallFieldAsteroids * 0.2 + dense * self.denseFieldAsteroids * 0.2)
end

function SectorGenerator:xCreateStation(faction, styleName, scriptPath, ...)

    -- local styleName = PlanGenerator.determineStationStyleFromScriptArguments(scriptPath, ...)

    local plan = PlanGenerator.makeStationPlan(faction, styleName)
    if plan == nil then
        printlog("Error while generating a station plan for faction ".. faction.name .. ".")
        return
    end

    local position = self:findStationPositionInSector(plan.radius);
    local station
    -- has to be done like this, passing nil for a string doesn't work
    if scriptPath then
        station = Sector():createStation(faction, plan, position, scriptPath, ...)
    else
        station = Sector():createStation(faction, plan, position)
    end

    self:postStationCreation(station)
    removeBulletinBoard(station)
    station:setDropsLoot(false)
    
    return station
end


--[[
local old_new = new
local cache
new = function(x, y)
    if cache == nil then
        cache = "TODO"
        print("init SectorGenerator cache; we have " .. #_cachedPlans ..)
    end
    return old_new(x, y)
end
--]]

