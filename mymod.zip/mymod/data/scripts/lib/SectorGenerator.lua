

include("xUtil")
local FactoryPredictor = include("factorypredictor")
local SectorTurretGenerator = include("sectorturretgenerator")
local Placer = include("placer")
local ShipGenerator = include("shipgenerator")

function SectorGenerator:createStash(worldMatrix, title)
    local plan = PlanGenerator.makeContainerPlan()
    local container = self:createContainer(plan, worldMatrix, 0)
    container.title = ""
    container:addScript("stash.lua")
    container.title = title or "Secret Stash"%_t
    return container
end

function SectorGenerator:createBeacon(position, faction, text, args)
end

function SectorGenerator:createContainerField(sizeX, sizeY, circular, position, factionIndex, hackables)
end

function SectorGenerator:generateStationContainers(station, sizeX, sizeY, circular)
end

function SectorGenerator:wormHoleAllowed(from, to)

    self.passageMap = self.passageMap or PassageMap(Server().seed)

    -- a wormhole can't be inside an unpassable sector
    if not self.passageMap:passable(from.x, from.y) or not self.passageMap:passable(to.x, to.y) then
        return false
    end

    -- in our overhaul, we allow wormholes across the ring!!!
    
    -- if they're not either both inside or both outside, then the wormhole crosses the ring -> illegal
    -- if self.passageMap:insideRing(from.x, from.y) ~= self.passageMap:insideRing(to.x, to.y) then
    --    return false
    -- end

    return true
end

function SectorGenerator:createWreckage(faction, plan, breaks, position)
    local wreckages = {SectorGenerator:createUnstrippedWreckage(faction, plan, breaks, position)}

    for _, wreckage in pairs(wreckages) do
        --if random():test(self.chanceForCaptainLogWreckage) then
        --    wreckage:addScriptOnce("data/scripts/entity/story/captainslogs.lua")
        --end
        if random():test(1 - self.chanceForUnstrippedWreckage) then
            ShipUtility.stripWreckage(wreckage)
        end

        local deletionTimer = DeletionTimer(wreckage)
        if valid(deletionTimer) then
            deletionTimer:disable()
        end
    end

    return unpack(wreckages)
end

function SectorGenerator:xMineTrap(position)

    local desc = self:xMineTrapDescriptor(position)

    local e = Sector():createEntity(desc)
    e:addScript("data/scripts/entity/xMineTrap.lua")
    e.dockable = false
    return e
end

function SectorGenerator:xMineTrapDescriptor(position)
    local desc = EntityDescriptor()
    -- desc.type = EntityType.Container
    desc:addComponents(
        ComponentType.Plan,
        ComponentType.BspTree,
        ComponentType.Intersection,
        ComponentType.Asleep,
        ComponentType.DamageContributors,
        ComponentType.BoundingSphere,
        ComponentType.BoundingBox,
        ComponentType.Velocity,
        ComponentType.Physics,
        ComponentType.Scripts,
        ComponentType.ScriptCallback,
        ComponentType.Title,
        ComponentType.InteractionText,
        ComponentType.Owner,                -- needed for onDamage?
        ComponentType.FactionNotifier,      -- needed for onDamage?
        ComponentType.Durability,
        ComponentType.PlanMaxDurability
    )
       
    local plan = xPlanCache_FromFile(Galaxy(), "data/plans/MineTrap.xml")
    desc.position = position or self:getPositionInSector()
    desc:setMovePlan(plan)
    
   return desc
end

function SectorGenerator:xCreateSpacedock(faction) -- legacy
    return SectorGenerator:xSpacedock(faction)
end

function SectorGenerator:xSpacedock(faction, arms)
    local station = self:xCreateStation(faction, arms, StationSubType.RepairDock, "data/scripts/entity/merchants/xSpacedock.lua")
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xFortress(faction, arms)
    local station = self:xCreateStation(faction, arms, StationSubType.MilitaryOutpost, "data/scripts/entity/merchants/xFortress.lua")
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xRefinery(faction)
    local station = self:xCreateStation(faction, nil, StationSubType.ResourceDepot, "data/scripts/entity/merchants/xRefinery.lua")
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xOreProcessor(faction)
    local station = self:xCreateStation(faction, nil, StationSubType.ResourceDepot, "data/scripts/entity/merchants/xOreProcessor.lua")
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xTradingpost(faction)
    local station = self:xCreateStation(faction, nil, StationSubType.TradingPost, "data/scripts/entity/merchants/tradingpost.lua")
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xTerrestrial(faction)
    local station = self:xCreateStation(faction, nil, StationSubType.TradingPost, "data/scripts/entity/merchants/xTerrestrial.lua")
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xRecycler(faction)
    local station = self:xCreateStation(faction, nil, StationSubType.ResourceDepot, "data/scripts/entity/merchants/xRecycler.lua")
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xFactory(faction, production)
    local station = self:xCreateStation(faction, nil, production.factoryStyle, "data/scripts/entity/merchants/factory.lua", production)
    station.crew = station.idealCrew
    return station
end

function SectorGenerator:xFactories(faction, x, y, num)
    if num then
        local productions = FactoryPredictor.generateFactoryProductions(x, y, num)
        if productions then
            for _, production in pairs(productions) do
                self:xFactory(faction, production)
            end
        else
            print("SectorGenerator: no factory productions for "..x..", "..y)
        end
    end
end

function SectorGenerator:xMines(faction, x, y, num)
    if num then
        local productions = FactoryPredictor.generateMineProductions(x, y, num)
        if productions then
            for _, production in pairs(productions) do
                self:xFactory(faction, production)
            end
        else
            print("SectorGenerator: no mine productions for "..x..", "..y)
        end
    end
end

function SectorGenerator:xDefensePlatform(faction, material, scale, arms)
    -- local plan = LoadPlanFromFile("data/plans/DefensePlatform.xml") -- TODO
    local plan = xPlanCache_FromFile(Galaxy(), "data/plans/DefensePlatform.xml")
    
    -- its a very small plan
    if not scale then
        scale = vec3(1.0, 1.0, 1.0)
    end
    scale = scale * 4.0
    
    local station = self:xCreateBasicStationFromPlan(faction, plan, material, scale, arms, "data/scripts/entity/xDefensePlatform.lua")
    Boarding(station).boardable = false
    station.dockable = false
    
    station:setValue("is_defense_platform", true) -- TODO add to respawn defenders
    station:setValue("npc_chatter", true)
    return station
end

function SectorGenerator:xFromContents(player, contents, random, faction, otherFaction)
    print("Generating sector %i,%i: %s", self.coordX, self.coordY, (contents.xSectorType or "unknown"))

    local x = self.coordX
    local y = self.coordY

    self:xCreateAsteroidFields(contents)
    
    local turretGenerator = SectorTurretGenerator()
    local gun = turretGenerator:generate(self.coordX, self.coordY, 0, Rarity(RarityType.Exceptional), WeaponType.XGun)
    local missile = turretGenerator:generate(self.coordX, self.coordY, 0, Rarity(RarityType.Exceptional), WeaponType.XMissile)
    local cannon = turretGenerator:generate(self.coordX, self.coordY, 0, Rarity(RarityType.Exceptional), WeaponType.XCannon)
    local mining = turretGenerator:generate(self.coordX, self.coordY, 0, Rarity(RarityType.Exceptional), WeaponType.XMining)
    
    local spaceDockArms = {
        {turret=cannon, num=6, limit=12},
    }
    local fortressArms = {
        {turret=cannon, num=12, limit=16},
    }
    local defenderArms = {
        --{turret=gun,     num=4, limit=8},
        --{turret=missile, num=1, limit=2},
        {turret=cannon,  num=3, limit=6},
    }
    local defensePlatformArms = {
        {turret=cannon,  num=2, limit=2},
    }
    
    for i = 1, (contents.xFortress or 0) do
        self:xFortress(faction, fortressArms)
    end
    for i = 1, (contents.xSpacedock or 0) do
        self:xSpacedock(faction, spaceDockArms)
    end
    for i = 1, (contents.xRefinery or 0) do
        self:xRefinery(faction)
    end
    for i = 1, (contents.xOreProcessor or 0) do
        self:xOreProcessor(faction)
    end
    for i = 1, (contents.xRecycler or 0) do
        self:xRecycler(faction)
    end
    for i = 1, (contents.xDefensePlatforms or 0) do
        self:xDefensePlatform(faction, nil, nil, defensePlatformArms)
    end
    for i = 1, (contents.xTraders or 0) do
        self:xTradingpost(faction)
    end
    for i = 1, (contents.xTerrestrial or 0) do
        self:xTerrestrial(faction)
    end
    for i = 1, (contents.xMineTraps or 0) do
        self:xMineTrap()
    end
    
    self:xMines(faction, x, y, (contents.xMines or 0))
    self:xFactories(faction, x, y, (contents.xFactories or 0))
    
    for i = 1, (contents.defenders or 0) do
        ShipGenerator.xCreateDefender(faction, self:getPositionInSector(2000), defenderArms)
    end
    
    for i = 1, (contents.xMiningShips or 0) do
        ShipGenerator.xCreateMiner(faction, self:getPositionInSector(5000), minerArms)
    end
    
    if contents.xHasGates then self:createGates() end
    if random:test(self:getWormHoleProbability()) then self:createRandomWormHole() end
    
    if contents.xHasPirateAttacks then
        -- TODO allow multiple events scheduled
        -- TODO haven't integrated this with the new plan generator
        -- Sector():addScriptOnce("data/scripts/sector/eventscheduler.lua", "events/pirateattack.lua")
    end
    
    if contents.xOffGrid then
        self:addOffgridAmbientEvents()
    else
        self:addAmbientEvents()
    end
    Placer.resolveIntersections()
end

function SectorGenerator:xCreateAsteroidFields(contents)
    local generator = AsteroidFieldGenerator(self.coordX, self.coordY)
    if contents.xAsteroidFields then
        --printTable(contents.xAsteroidFields)
        for i = 1, #contents.xAsteroidFields do
            local field = contents.xAsteroidFields[i]
            local at = generator:createAsteroidFieldEx(field.number, field.radius, field.minSize, field.maxSize, (field.probability > 0), field.probability)
            if math.random() < (field.stash or 0) then
                SectorGenerator:createStash(at)
            end
            if math.random() < (field.claim or 0) then
                generator:createClaimableAsteroid(at)
            end
            for j = 1, (field.mineTraps or 0) do
                local x = (math.random() - 0.5) * field.radius * 0.5
                local y = (math.random() - 0.5) * field.radius * 0.5
                local z = (math.random() - 0.5) * field.radius * 0.5
                local offset = vec3(x, y, z)
                -- print("Mines offset in field: "..x..","..y..","..z.." (radius "..field.radius..")")
                -- SectorGenerator:xMineTrap(translate(at, offset))
                local xat = at
                xat.position = xat.position + offset
                SectorGenerator:xMineTrap(xat)
            end
        end
    end
end

function SectorGenerator:xCreateBasicStationFromPlan(faction, plan, material, scale, arms, scriptPath, ...)
    if material == nil then
        material = Material(Balancing_GetHighestAvailableMaterial(self.coordX, self.coordY))
    end
    if not scale then
        scale = vec3(1.0, 1.0, 1.0)
    end
    
    if plan == nil then
        eprint("SectorGenerator: nil plan")
        return nil
    end
    plan:setMaterial(material)
    plan:scale(scale)
    local position = self:findStationPositionInSector(plan.radius)
    local station
    
        -- has to be done like this, passing nil for a string doesn't work
    if scriptPath then
        station = Sector():createStation(faction, plan, position, scriptPath, ...)
    else
        station = Sector():createStation(faction, plan, position)
    end
    if station == nil then
        eprint("SectorGenerator: error creating station")
        return nil
    end
    
    if arms then
        ShipUtility.xArm(station, arms)
        station:addScript("ai/patrol.lua")
        station:setValue("is_armed", true)
    end
        
    self:xPostBasicStationCreation(station)
    return station
end

function SectorGenerator:xCreateStation(faction, arms, styleName, scriptPath, ...)

    -- local styleName = PlanGenerator.determineStationStyleFromScriptArguments(scriptPath, ...)

    local plan = PlanGenerator.makeStationPlan(faction, styleName)
    if plan == nil then
        printlog("Error while generating a station plan for faction ".. faction.name .. ".")
        return
    end

    local position = self:findStationPositionInSector(plan.radius);
    local station
    -- has to be done like this, passing nil for a string doesn't work
    if scriptPath then
        station = Sector():createStation(faction, plan, position, scriptPath, ...)
    else
        station = Sector():createStation(faction, plan, position)
    end

    if arms then
        ShipUtility.xArm(station, arms)
        station:addScript("ai/patrol.lua")
        station:setValue("is_armed", true)
    end
    
    self:xPostStationCreation(station)
    return station
end

function SectorGenerator:xPostBasicStationCreation(station)
    station:addScriptOnce("data/scripts/entity/startbuilding.lua")
    station:addScriptOnce("data/scripts/entity/entercraft.lua")
    station:addScriptOnce("data/scripts/entity/exitcraft.lua")
    station:addScriptOnce("data/scripts/entity/transfercrewgoods.lua")
    station:addScriptOnce("data/scripts/entity/utility/transportmode.lua")
    
    SetBoardingDefenseLevel(station)
    station.crew = station.idealCrew
    station.shieldDurability = station.shieldMaxDurability
    Physics(station).driftDecrease = 0.2
    station:setDropsLoot(false)
end

function SectorGenerator:xPostStationCreation(station)
    station:addScriptOnce("data/scripts/entity/backup.lua")
    station:addScriptOnce("data/scripts/entity/startbuilding.lua")
    station:addScriptOnce("data/scripts/entity/entercraft.lua")
    station:addScriptOnce("data/scripts/entity/exitcraft.lua")
    station:addScriptOnce("data/scripts/entity/crewboard.lua")
    station:addScriptOnce("data/scripts/entity/regrowdocks.lua")
    station:addScriptOnce("data/scripts/entity/transfercrewgoods.lua")
    station:addScriptOnce("data/scripts/entity/utility/transportmode.lua")
    
    SetBoardingDefenseLevel(station)
    station.crew = station.idealCrew
    station.shieldDurability = station.shieldMaxDurability
    Physics(station).driftDecrease = 0.2
    station:setDropsLoot(false)
end

function SectorGenerator:addAmbientEvents()
    Sector():addScriptOnce("sector/passingships.lua")
    Sector():addScriptOnce("sector/traders.lua")
    Sector():addScriptOnce("sector/factionwar/initfactionwar.lua")
    -- TODO extras
end



