

turretsInCenter = 10 -- we have fewer, but bigger guns

weaponProbabilities[WeaponType.ChainGun] =             {p = 0.0}
weaponProbabilities[WeaponType.PointDefenseChainGun] = {p = 0.0}
weaponProbabilities[WeaponType.MiningLaser] =          {p = 0.0}
weaponProbabilities[WeaponType.RawMiningLaser] =       {p = 0.0}
weaponProbabilities[WeaponType.SalvagingLaser] =       {p = 0.0}
weaponProbabilities[WeaponType.RawSalvagingLaser] =    {p = 0.0}
weaponProbabilities[WeaponType.Bolter] =               {p = 0.0}
weaponProbabilities[WeaponType.ForceGun] =             {p = 0.0}
weaponProbabilities[WeaponType.Laser] =                {p = 0.0}
weaponProbabilities[WeaponType.PointDefenseLaser] =    {p = 0.0}
weaponProbabilities[WeaponType.PlasmaGun] =            {p = 0.0}
weaponProbabilities[WeaponType.PulseCannon] =          {p = 0.0}
weaponProbabilities[WeaponType.AntiFighter] =          {p = 0.0}
weaponProbabilities[WeaponType.Cannon] =               {p = 0.0}
weaponProbabilities[WeaponType.RepairBeam] =           {p = 0.0}
weaponProbabilities[WeaponType.RocketLauncher] =       {p = 0.0}
weaponProbabilities[WeaponType.RailGun] =              {p = 0.0}
weaponProbabilities[WeaponType.LightningGun] =         {p = 0.0}
weaponProbabilities[WeaponType.TeslaGun] =             {p = 0.0}


weaponProbabilities[WeaponType.XMining] =              {p = 1.0}

weaponProbabilities[WeaponType.XGun] =                 {p = 1.0}
weaponProbabilities[WeaponType.XCannon] =              {p = 1.0}
weaponProbabilities[WeaponType.XMissile] =             {p = 1.0}
weaponProbabilities[WeaponType.XDisruptor] =           {p = 1.0}

--weaponProbabilities[WeaponType.XLaser] =               {p = 1.0}
--weaponProbabilities[WeaponType.XPDLaser] =             {p = 1.0}
--weaponProbabilities[WeaponType.XPDFlak] =              {p = 1.0}



