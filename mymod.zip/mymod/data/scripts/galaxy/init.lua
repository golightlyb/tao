
Galaxy():removeScript("internal/dlc/blackmarket/galaxy/convoyevent.lua")
