
include ("xSectorUtil")

function SectorSpecifics:addBaseTemplates()
    -- first position is reserved, it's used for faction's home sectors. don't change this
    self:addTemplate("sectors/xColony")
    self:addTemplate("sectors/xShatteredPlanet")
    self:addTemplate("sectors/xAsteroidRing")
    self:addTemplate("sectors/xPirateStation")

    self:addTemplate("sectors/lonewormhole")
    self:addTemplate("sectors/gates")
end

-- returns all regular sector templates that will have stations
function SectorSpecifics.getRegularStationSectors()
    local destinations = {}

    destinations["sectors/xColony"]          = true -- always
    destinations["sectors/xShatteredPlanet"] = true -- maybe
    destinations["sectors/xAsteroidRing"]    = true -- maybe
    destinations["sectors/xPirateStation"]   = true -- maybe

    return destinations
end

local function title(titles, n, single, plural)
    n = (n or 0)
    
    if n == 1 then
        table.insert(titles, single)
    elseif n > 1 then
        table.insert(titles, ""..n.." "..plural)
    end
    
    return n
end

function SectorSpecifics:fillSectorView(view, gatesMap, withContent)

    local x, y = self.coordinates.x, self.coordinates.y
    local contents = self.generationTemplate.contents(x, y)

    view:setCoordinates(x, y)

    if self.gates and gatesMap then
        local connections = gatesMap:getConnectedSectors(self.coordinates)

        local gateDestinations = {}
        for _, connection in pairs(connections) do
            table.insert(gateDestinations, ivec2(connection.x, connection.y))
        end

        view:setGateDestinations(unpack(gateDestinations))
    end

    if not self.offgrid then
        view.factionIndex = self.factionIndex
    end

    if withContent then
        -- this should be perfectly safe and avoids loading the predictor at entry level, causing potential slowdowns
        local FactoryPredictor = include ("factorypredictor")

        local stations = contents.stations
        view.influence = view:calculateInfluence(stations)
        view.numStations = contents.stations
        view.numShips = contents.ships
        if contents.asteroidEstimation then
            view.numAsteroids = contents.asteroidEstimation
        end
        if contents.wreckageEstimation then
            view.numWrecks = contents.wreckageEstimation
        end

        local titles = {}
        local seen = 0
        
        if contents.x and contents.x.style then
            table.insert(titles, "--- "..contents.x.style.." ---")
        end
        
        local counts, total = xSectorUtil_CountsFromContent(contents, "stations")
        
        seen = seen + title(titles, counts.fortress,         "Fortress",             "Fortresses")
        seen = seen + title(titles, counts.spacedock,        "Spacedock",            "Spacedocks")
        seen = seen + title(titles, counts.trader,           "Trading Post",         "Trading Posts")
        seen = seen + title(titles, counts.terrestrial,      "Terrestrial Trader",   "Terrestrial Traders")
        seen = seen + title(titles, counts.refinery,         "Refinery",             "Refineries")
        seen = seen + title(titles, counts.oreProcessor,     "Ore Processor",        "Ore Processors")
        seen = seen + title(titles, counts.recycler,         "Recycler",             "Recyclers")
        seen = seen + title(titles, counts.defensePlatform,  "Defense Platform",     "Defense Platforms")
        
        local factories = counts.factories or 0
        if factories > 0 then
            table.insert(titles, "--- "..factories.." Factories ---")
            local productions = FactoryPredictor.generateFactoryProductions(x, y, factories)
            if productions then
                for i = 1, factories do
                    local production = productions[i]
                    local str, args = formatFactoryName(production)

                    table.insert(titles, NamedFormat(str, args))
                    seen = seen + 1
                end
            else
                eprint("sectorspecifics: no factory productions generated")
            end
        end

        local mines = counts.mines or 0
        if mines > 0 then
            table.insert(titles, "--- "..mines.." Mines ---")
            local productions = FactoryPredictor.generateMineProductions(x, y, mines)
            if productions then
                for i = 1, mines do
                    local production = productions[i]
                    local str, args = formatFactoryName(production)

                    table.insert(titles, NamedFormat(str, args))
                    seen = seen + 1
                end
            else
                eprint("sectorspecifics: no mine productions generated")
            end
        end

        if (seen ~= contents.stations) or (seen ~= total) then
            eprint ("mismatch: %i %i; contains stations unaccounted for (seen %i, expected %i or %i)", x, y, seen, contents.stations, total)
            printTable(contents)
        end

        view:setStationTitles(unpack(titles))
    end
end


