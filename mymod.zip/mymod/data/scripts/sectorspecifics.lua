

function SectorSpecifics:addBaseTemplates()
    -- first position is reserved, it's used for faction's home sectors. don't change this
    self:addTemplate("sectors/xColony")
    --self:addTemplate("sectors/asteroidfieldminer")
    --self:addTemplate("sectors/loneconsumer")
    --self:addTemplate("sectors/lonescrapyard")
    --self:addTemplate("sectors/loneshipyard")
    --self:addTemplate("sectors/lonetrader")
    --self:addTemplate("sectors/lonetradingpost")
    --self:addTemplate("sectors/lonewormhole")
    --self:addTemplate("sectors/factoryfield")
    --self:addTemplate("sectors/miningfield")
    --self:addTemplate("sectors/gates")
    --self:addTemplate("sectors/ancientgates")
    --self:addTemplate("sectors/neutralzone")

    --self:addTemplate("sectors/pirateasteroidfield")
    --self:addTemplate("sectors/piratefight")
    --self:addTemplate("sectors/piratestation")

    --self:addTemplate("sectors/asteroidfield")
    --self:addTemplate("sectors/smallasteroidfield")
    --self:addTemplate("sectors/defenderasteroidfield")
    --self:addTemplate("sectors/wreckagefield")
    --self:addTemplate("sectors/smugglerhideout")
    --self:addTemplate("sectors/wreckageasteroidfield")

    --self:addTemplate("sectors/xsotanasteroids")
end

function SectorSpecifics:addMoreTemplates()
end


local function title(titles, n, single, plural)
    n = (n or 0)
    
    if n == 1 then
        table.insert(titles, single)
    elseif n > 1 then
        table.insert(titles, ""..n.." "..plural)
    end
    
    return n
end

function SectorSpecifics:fillSectorView(view, gatesMap, withContent)

    local x, y = self.coordinates.x, self.coordinates.y
    local contents = self.generationTemplate.contents(x, y)

    view:setCoordinates(x, y)

    if self.gates and gatesMap then
        local connections = gatesMap:getConnectedSectors(self.coordinates)

        local gateDestinations = {}
        for _, connection in pairs(connections) do
            table.insert(gateDestinations, ivec2(connection.x, connection.y))
        end

        view:setGateDestinations(unpack(gateDestinations))
    end

    if not self.offgrid then
        view.factionIndex = self.factionIndex
    end

    if withContent then
        -- this should be perfectly safe and avoids loading the predictor at entry level, causing potential slowdowns
        local FactoryPredictor = include ("factorypredictor")

        local stations = contents.stations
        view.influence = view:calculateInfluence(stations)
        view.numStations = contents.stations
        view.numShips = contents.ships
        if contents.asteroidEstimation then
            view.numAsteroids = contents.asteroidEstimation
        end
        if contents.wreckageEstimation then
            view.numWrecks = contents.wreckageEstimation
        end

        local titles = {}
        local seen = 0
        
        seen = seen + title(titles, contents.xSpacedock,        "Spacedock",            "Spacedocks")
        seen = seen + title(titles, (contents.xTraders or 0) + (contents.xNeighbourTraders or 0),          "Trading Post",         "Trading Posts")
        seen = seen + title(titles, contents.xTerrestrial,      "Terrestrial Trader",   "Terrestrial Traders")
        seen = seen + title(titles, contents.xRefinery,         "Refinery",             "Refineries")
        seen = seen + title(titles, contents.xOreProcessor,     "Ore Processor",        "Ore Processors")
        seen = seen + title(titles, contents.xRecycler,         "Recycler",             "Recyclers")
        seen = seen + title(titles, contents.xDefensePlatforms, "Defense Platform",     "Defense Platforms")
        
        local factories = contents.xFactories or 0
        if factories > 0 then
            table.insert(titles, "--- "..factories.." Factories ---")
            local productions = FactoryPredictor.generateFactoryProductions(x, y, factories)
            if productions then
                for i = 1, factories do
                    local production = productions[i]
                    local str, args = formatFactoryName(production)

                    table.insert(titles, NamedFormat(str, args))
                    seen = seen + 1
                end
            else
                eprint("sectorspecifics: no factory productions generated")
            end
        end

        local mines = contents.xMines or 0
        if mines > 0 then
            table.insert(titles, "--- "..mines.." Mines ---")
            local productions = FactoryPredictor.generateMineProductions(x, y, mines)
            if productions then
                for i = 1, mines do
                    local production = productions[i]
                    local str, args = formatFactoryName(production)

                    table.insert(titles, NamedFormat(str, args))
                    seen = seen + 1
                end
            else
                eprint("sectorspecifics: no mine productions generated")
            end
        end

        if seen ~= contents.stations then
            eprint ("mismatch: %i %i; contains stations unaccounted for (seen %i, expected %i)", x, y, seen, contents.stations)
            printTable(contents)
        end

        view:setStationTitles(unpack(titles))
    end
end

-- returns all regular sector templates that will have stations
function SectorSpecifics.getRegularStationSectors()
    local destinations = {}

    destinations["sectors/xColony"] = true
    --destinations["sectors/loneconsumer"] = true
    --destinations["sectors/loneshipyard"] = true
    --destinations["sectors/lonetrader"] = true
    --destinations["sectors/lonetradingpost"] = true
    --destinations["sectors/factoryfield"] = true
    --destinations["sectors/miningfield"] = true
    --destinations["sectors/neutralzone"] = true

    return destinations
end
