package.path = package.path .. ";data/scripts/?.lua"
package.path = package.path .. ";data/scripts/lib/?.lua"

include ("utility")
include ("productions")
include ("xSectorUtil")

-- namespace XStationFounder
XStationFounder = {}
XStationFounder.__index = XStationFounder
XStationFounder.titleLabel = nil

if onClient() then
    local productions      = productions -- from include lib/productions.lua
    local serviceStations  = xUtil_serviceStations  -- from xSectorUtil
    local militaryStations = xUtil_militaryStations -- from xSectorUtil
    local specialProducers = xUtil_specialProducers -- from xSectorUtil

    local self
    local titleLabel
    local selectedStationType
    local selectStationButton_MapIndexToVariant = {}
    
    function XStationFounder._createStationTypeButtons(tab, lister, variants)
        for i = 1, #variants do
            local variant = variants[i]
            local button = tab:createButton(lister:nextRect(20), variant.shorttitle%_t, "_onSelectedStationType")
            button.tooltip = variant.tooltip
            selectStationButton_MapIndexToVariant[button.index] = variant
        end
    end

    function XStationFounder._onSelectedStationType(button)
        local variant = selectStationButton_MapIndexToVariant[button.index]
        selectedStationType = variant
        XStationFounder._refreshGUI()
    end

    function XStationFounder:initialize()
        local tab = PlayerWindow():createTab("Station Founding"%_t, "data/textures/icons/station.png", "Found a New Station"%_t)
        tab.onShowFunction = "_onShowTab"

        local lister = UIVerticalLister(Rect(tab.size), 10, 0)
        titleLabel = tab:createLabel(lister:nextRect(30), "..."%_t, 28)
        titleLabel:setLeftAligned()

        local splitter = UIVerticalMultiSplitter(lister.rect, 10, 0, 3)

        ---[LEFT]-------------------------------------------------------------------
        local leftSplitter = UIHorizontalSplitter(splitter:partition(0), 10, 0, 0.5)

        local lister = UIVerticalLister(leftSplitter.top, 10, 10)

        tab:createLabel(lister:nextRect(20), "Service Stations"%_t, 20):setLeftAligned()
        XStationFounder._createStationTypeButtons(tab, lister, serviceStations)
        
        tab:createLabel(lister:nextRect(40), "Mines & Factories"%_t, 20):setLeftAligned()
        XStationFounder._createStationTypeButtons(tab, lister, specialProducers)
        
        tab:createLabel(lister:nextRect(40), "Military"%_t, 20):setLeftAligned()
        XStationFounder._createStationTypeButtons(tab, lister, militaryStations)
        
        ---[RIGHT]------------------------------------------------------------------
        local rightRect = Rect(splitter:partition(1).lower, splitter:partition(3).upper)

        ---[SECTOR MAP]-------------------------------------------------------------
        local rect = Rect(rightRect.lower, rightRect.upper - 60)
        tab:createFrame(rect)
        local lister = UIVerticalLister(rect, 10, 10)
        local split = UIVerticalSplitter(lister:nextRect(20), 10, 0, 0.7)
        tab:createLabel(split.left, "Sector"%_t, 20):setLeftAligned()
    end

    function XStationFounder._refreshGUI()
        local variant = selectedStationType
        if variant == nil then
            titleLabel.caption = "Found a new station"
        else
            titleLabel.caption = "Found a new "..variant.title
        end
    end

    function XStationFounder:_onShowTab()
        XStationFounder._refreshGUI()
    end
end



--[[
e.g.
function CreativeMode.onRSalvagingFightersPressed()
    if onClient() then
        invokeServerFunction("onRSalvagingFightersPressed")
        return
    end

    CreativeMode.addFighterSquad(WeaponType.RawSalvagingLaser, "R-Salvaging Squad")
end
callable(CreativeMode, "onRSalvagingFightersPressed")
--]]

