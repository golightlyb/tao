package.path = package.path .. ";data/scripts/lib/?.lua"

include ("stringutility")

-- kick the player out of certain craft they aren't supposed to be able to
-- enter. Note: the player will still have a few milliseconds when they're in
-- the craft where they can hit B and exploit this.

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XNoEnter
XNoEnter = {}

local warned = false

function XNoEnter.initialize()
    if onClient() then
        local player = Player()
        player:registerCallback("onShipChanged", "onShipChanged")
    end
end

local function tryEvict(player, craft, toDestroy)
    if craft and craft:getValue("noEnter") then
        ShipWindow():hide()
        PlayerWindow():hide()
        if player and (not warned) and player.state == PlayerStateType.BuildCraft then
            displayChatMessage("WARNING: do not edit this object. It may crash, and it's cheating.", "", 1)
            warned = true
        end
        player.craftIndex = Uuid()
    end
end

function XNoEnter.updateClient()
    local player = Player()
    local craft = player.craft
    tryEvict(player, craft)
end

function XNoEnter.onShipChanged(playerId, craftId)    
    local player = Player(playerId)
    local craft = Sector():getEntity(craftId)
    warned = false
    tryEvict(player, craft)
end

