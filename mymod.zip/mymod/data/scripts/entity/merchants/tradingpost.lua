

TradingPost.trader.supplyDemandInfluence = 1.0 -- original 0.5
TradingPost.trader.stockInfluence = 1.0 -- original 1.0

-- modified to optionally allow initialization with custom goods
function TradingPost.initialize(gds, gdb) -- goods sold, bought

    local station = Entity()
    if station.title == "" then
        station.title = "Trading Post"%_t
    end

    if onServer() then
        Sector():addScriptOnce("sector/traders.lua")

        -- for large stations it's possible that the generator sacrifices cargo bay for generators etc.
        local cargoBay = CargoBay()
        if TradingPost.trader.minimumCargoBay and station.aiOwned then
            if cargoBay.cargoHold < TradingPost.trader.minimumCargoBay then
                cargoBay.fixedSize = true
                cargoBay.cargoHold = TradingPost.trader.minimumCargoBay
            end
        else
            cargoBay.fixedSize = false
        end

        local faction = Faction()
        if not _restoring then
            sector = Sector()
            math.randomseed(sector.seed + sector.numEntities);

            -- make lists of all items that will be sold/bought
            x, y = sector:getCoordinates()
            local bought, sold = TradingPost.generateGoods(x, y, gds, gdb)

            TradingPost.trader.buyPriceFactor = 0.8
            TradingPost.trader.sellPriceFactor = 1.1

            TradingPost.initializeTrading(bought, sold, nil, "trader")

            if faction and (faction.isAlliance or faction.isPlayer) then
                TradingPost.trader.buyFromOthers = false
            end

            math.randomseed(appTimeMs())
        end

        if faction and faction.isAIFaction then
            Sector():registerCallback("onRestoredFromDisk", "onRestoredFromDisk")
        end
    else
        TradingPost.requestGoods()
        if EntityIcon().icon == "" then
            EntityIcon().icon = "data/textures/icons/pixel/trade.png"
            InteractionText(station.index).text = Dialog.generateStationInteractionText(station, random())
        end

    end

    if onServer() then
    -- station:addScriptOnce("data/scripts/entity/merchants/cargotransportlicensemerchant.lua")
        station:addScriptOnce("data/scripts/entity/merchants/customs.lua")
    end
end

function TradingPost.initUI()
    local station = Entity()
    local tabbedWindow = TradingAPI.CreateTabbedWindow(station.translatedTitle)

    -- create buy tab
    local buyTab = tabbedWindow:createTab("Buy"%_t, "data/textures/icons/shaking-hands-buy.png", "Buy from trader"%_t)
    TradingPost.buildBuyGui(buyTab)

    -- create sell tab
    local sellTab = tabbedWindow:createTab("Sell"%_t, "data/textures/icons/shaking-hands-sell.png", "Sell to trader"%_t)
    TradingPost.buildSellGui(sellTab)

    TradingPost.toggleBuyButton = sellTab:createButton(Rect(sellTab.size.x - 30, -5, sellTab.size.x, 25), "", "onToggleBuyPressed")
    TradingPost.toggleBuyButton.icon = "data/textures/icons/sell.png"

    TradingPost.trader.guiInitialized = true

    TradingPost.requestGoods()
end

function TradingPost.generateGoods(x, y, gds, gdb)
    if gds or gdb then
        local bought = {}
        local sold = {}
        
        if gds then
            for i = 1,#gds do
                local g = goods[gds[i]]:good()
                sold[#sold + 1] = g
            end
        end
        
        if gdb then
            for i = 1,#gdb do
                local g = goods[gdb[i]]:good()
                bought[#bought + 1] = g
            end
        end
        
        return bought, sold
    end

    if not x or not y then
        x, y = Sector():getCoordinates()
    end

    local map = FactoryMap()
    local supply, demand, sum = map:getSupplyAndDemand(x, y)

    local accumulated = {}

    for good, value in pairs(supply) do
        accumulated[good] = value
    end
    for good, value in pairs(demand) do
        accumulated[good] = (accumulated[good] or 0) + value
    end

    local existingGoods = {}
    local bought = {}
    local sold = {}

    local byWeight = {}
    for good, value in pairs(accumulated) do
        byWeight[good] = value + 10
    end

    for i = 1, 15 do
        local good = selectByWeight(byWeight)
        
        if not GoodIsTradableByID(good) then goto continue end

        -- don't list illegal (miltary) goods, even if there's demand for them
        if good and not existingGoods[good] and not goods[good].illegal then
            if goods[good] then
                local g = goods[good]:good()
                bought[#bought + 1] = g
                sold[#sold + 1] = g

                existingGoods[good] = true
            else
                eprint("entity/merchants/tradingpost: invalid good "..good)
            end
        end
        
        ::continue::
    end

    return bought, sold
end







