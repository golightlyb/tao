
function ResourceDepotBuildingKnowledgeMerchant.initialize()
end

function ResourceDepotBuildingKnowledgeMerchant.shop:onSold(item, buyer, player)
end

function ResourceDepotBuildingKnowledgeMerchant.shop:addItems()
end

function ResourceDepotBuildingKnowledgeMerchant.initUI()
end
