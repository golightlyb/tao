
function SmugglerBuildingKnowledgeMerchant.initialize()
end

function SmugglerBuildingKnowledgeMerchant.shop:onSold(item, buyer, player)
end

function SmugglerBuildingKnowledgeMerchant.shop:addItems()
end

function SmugglerBuildingKnowledgeMerchant.initUI()
end
