package.path = package.path .. ";data/scripts/lib/?.lua"
include ("utility")
include ("randomext")
include ("faction")
include ("goods")
include ("productions")
local ConsumerGoods = include ("consumergoods")
-- local ShopAPI = include ("shop")
local Dialog = include("dialogutility")
--local BuildingKnowledgeUT = include("buildingknowledgeutility")

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace XRecycler
XRecycler = {}

function XRecycler.interactionPossible(playerIndex, option)
    return true
end

function XRecycler.initialize()
    local station = Entity()
    if station.title == "" then
        station.title = "Recycling Plant"%_t
    end

    if onServer() then
        station:addScriptOnce("data/scripts/entity/merchants/consumer.lua", "Recycling Plant"%_t, unpack(ConsumerGoods.XRecycler()))
    end

    if onClient() and EntityIcon().icon == "" then
        EntityIcon().icon = "data/textures/icons/pixel/scrapyard_fat.png"
        InteractionText(station.index).text = Dialog.generateStationInteractionText(station, random())
    end
end

