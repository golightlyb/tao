include("xUtil")

function SectorTemplate.contents(x, y)
    local seed = Seed(string.join({GameSeed(), x, y, "startsector"}, "-"))
    math.randomseed(seed);

    local random = random()
    local contents = {
        xSectorType="Start Sector",
        xHasGates = true,
        seed = tostring(seed),
    }

    if onServer() then
        faction = Galaxy():getLocalFaction(x, y) or Galaxy():getNearestFaction(x, y)
    end
    
    --contents.xSpacedock        = 1
    --contents.xTraders          = 1
    --contents.xTerrestrial      = 1
    --contents.xRefinery         = 1
    --contents.xOreProcessor     = 1
    --contents.xRecycler         = 1
    --contents.xDefensePlatforms = 2
    contents.defenders         = 2
    
    contents.xArc = {
        asteroids = {number=1000},
        mineTraps = 200,
        stashes   = 3
    }
    
    contents.asteroidEstimation = contents.xArc.Asteroids
    contents.stations           = xUtilCountStations(contents)
    contents.ships              = contents.defenders
    
    return contents, random, faction, nil
end


-- player is the player who triggered the creation of the sector (only set in start sector, otherwise nil)
function SectorTemplate.generate(player, seed, x, y)
    local contents, random, faction, otherFaction = SectorTemplate.contents(x, y)
    SectorGenerator(x, y):xFromContents(player, contents, random, faction, otherFaction)
    
    local sector = Sector()
    sector:removeScript("factionwar/initfactionwar.lua")
    sector:addScript("data/scripts/sector/neutralzone.lua")

    return {defenders = contents.defenders}
end


